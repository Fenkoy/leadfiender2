import { useState } from "react";
import { Plan, UserStatus, PLAN_CONFIG, STATUS_CONFIG } from "@/lib/admin-types";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Copy, Eye, EyeOff } from "lucide-react";

type Props = {
  open: boolean;
  onClose: () => void;
  onCreate: (data: {
    email: string;
    password: string;
    full_name: string;
    plan: Plan;
    status: UserStatus;
  }) => void;
};

function generatePassword(length = 12): string {
  const chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$";
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

export default function CreateUserModal({ open, onClose, onCreate }: Props) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState(() => generatePassword());
  const [showPass, setShowPass] = useState(false);
  const [plan, setPlan] = useState<Plan>("basic");
  const [status, setStatus] = useState<UserStatus>("active");
  const [forceReset, setForceReset] = useState(true);
  const [saving, setSaving] = useState(false);

  const reset = () => {
    setName("");
    setEmail("");
    setPassword(generatePassword());
    setPlan("basic");
    setStatus("active");
    setForceReset(true);
    setSaving(false);
  };

  const handleCreate = async () => {
    if (!email || !password) return;
    setSaving(true);
    await onCreate({ email, password, full_name: name, plan, status });
    setSaving(false);
    reset();
    onClose();
  };

  const copyPassword = () => {
    navigator.clipboard.writeText(password);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) { onClose(); reset(); } }}>
      <DialogContent className="max-w-md border-border bg-card">
        <DialogHeader>
          <DialogTitle className="text-lg">Criar Usuário</DialogTitle>
          <p className="text-xs text-muted-foreground">Adicionar um novo usuário ao sistema</p>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Name */}
          <div className="space-y-1.5">
            <Label htmlFor="create-name" className="text-xs">Nome</Label>
            <Input id="create-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome completo" />
          </div>

          {/* Email */}
          <div className="space-y-1.5">
            <Label htmlFor="create-email" className="text-xs">Email *</Label>
            <Input id="create-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="usuario@exemplo.com" required />
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="create-pass" className="text-xs">Senha *</Label>
              <button
                type="button"
                onClick={() => setPassword(generatePassword())}
                className="text-[10px] text-primary hover:text-primary/80 font-medium"
              >
                Gerar nova
              </button>
            </div>
            <div className="relative flex items-center gap-1.5">
              <Input
                id="create-pass"
                type={showPass ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pr-16 font-mono text-xs"
                required
                minLength={6}
              />
              <div className="absolute right-2 flex items-center gap-1">
                <button onClick={() => setShowPass(!showPass)} className="text-muted-foreground hover:text-foreground p-0.5">
                  {showPass ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
                <button onClick={copyPassword} className="text-muted-foreground hover:text-foreground p-0.5" title="Copiar senha">
                  <Copy className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Plan */}
          <div className="space-y-1.5">
            <Label className="text-xs">Plano</Label>
            <div className="flex gap-2">
              {(Object.keys(PLAN_CONFIG) as Plan[]).map((p) => (
                <button
                  key={p}
                  onClick={() => setPlan(p)}
                  className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium transition-all ${
                    plan === p ? PLAN_CONFIG[p].bgClass + " shadow-md" : "border-border text-muted-foreground hover:border-border/80"
                  }`}
                >
                  {PLAN_CONFIG[p].label}
                </button>
              ))}
            </div>
          </div>

          {/* Status */}
          <div className="space-y-1.5">
            <Label className="text-xs">Status</Label>
            <div className="flex gap-2">
              {(Object.keys(STATUS_CONFIG) as UserStatus[]).map((s) => (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  className={`flex-1 rounded-lg border px-2 py-2 text-xs font-medium transition-all ${
                    status === s ? STATUS_CONFIG[s].bgClass + " shadow-md" : "border-border text-muted-foreground hover:border-border/80"
                  }`}
                >
                  {STATUS_CONFIG[s].label}
                </button>
              ))}
            </div>
          </div>

          {/* Force reset checkbox */}
          <div className="flex items-center gap-2">
            <Checkbox
              id="force-reset"
              checked={forceReset}
              onCheckedChange={(v) => setForceReset(v === true)}
            />
            <Label htmlFor="force-reset" className="text-xs text-muted-foreground cursor-pointer">
              Forçar redefinição de senha no primeiro login
            </Label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => { onClose(); reset(); }} disabled={saving}>
            Cancelar
          </Button>
          <Button onClick={handleCreate} disabled={saving || !email || !password}>
            {saving ? "Criando..." : "Criar Usuário"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
