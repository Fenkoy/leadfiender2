export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      founder_slots: {
        Row: {
          claimed: number
          id: number
          total_slots: number
          updated_at: string
        }
        Insert: {
          claimed?: number
          id?: number
          total_slots?: number
          updated_at?: string
        }
        Update: {
          claimed?: number
          id?: number
          total_slots?: number
          updated_at?: string
        }
        Relationships: []
      }
      lead_usage: {
        Row: {
          last_reset_date: string
          leads_used_today: number
          updated_at: string
          user_id: string
        }
        Insert: {
          last_reset_date?: string
          leads_used_today?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          last_reset_date?: string
          leads_used_today?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          experience: string | null
          full_name: string | null
          goal: string | null
          id: string
          is_admin: boolean
          niche: string | null
          onboarding_completed: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          experience?: string | null
          full_name?: string | null
          goal?: string | null
          id: string
          is_admin?: boolean
          niche?: string | null
          onboarding_completed?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          experience?: string | null
          full_name?: string | null
          goal?: string | null
          id?: string
          is_admin?: boolean
          niche?: string | null
          onboarding_completed?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      upgrade_events: {
        Row: {
          created_at: string
          event_type: string
          feature: string | null
          from_plan: Database["public"]["Enums"]["plan_type"] | null
          id: string
          metadata: Json | null
          to_plan: Database["public"]["Enums"]["plan_type"] | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          event_type: string
          feature?: string | null
          from_plan?: Database["public"]["Enums"]["plan_type"] | null
          id?: string
          metadata?: Json | null
          to_plan?: Database["public"]["Enums"]["plan_type"] | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          event_type?: string
          feature?: string | null
          from_plan?: Database["public"]["Enums"]["plan_type"] | null
          id?: string
          metadata?: Json | null
          to_plan?: Database["public"]["Enums"]["plan_type"] | null
          user_id?: string | null
        }
        Relationships: []
      }
      user_plans: {
        Row: {
          created_at: string
          current_period_end: string | null
          plan: Database["public"]["Enums"]["plan_type"]
          status: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          current_period_end?: string | null
          plan?: Database["public"]["Enums"]["plan_type"]
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          current_period_end?: string | null
          plan?: Database["public"]["Enums"]["plan_type"]
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_delete_user: { Args: { _user_id: string }; Returns: boolean }
      admin_list_users: {
        Args: never
        Returns: {
          created_at: string
          email: string
          full_name: string
          is_admin: boolean
          last_reset_date: string
          leads_used_today: number
          plan: Database["public"]["Enums"]["plan_type"]
          user_id: string
        }[]
      }
      admin_reset_leads: { Args: { _user_id: string }; Returns: boolean }
      admin_set_plan: {
        Args: {
          _plan: Database["public"]["Enums"]["plan_type"]
          _user_id: string
        }
        Returns: boolean
      }
      can_use_lead: { Args: never; Returns: boolean }
      claim_founder: { Args: never; Returns: boolean }
      consume_lead: { Args: never; Returns: boolean }
      current_plan: {
        Args: never
        Returns: Database["public"]["Enums"]["plan_type"]
      }
      has_feature: { Args: { _feature: string }; Returns: boolean }
      is_admin: { Args: { _uid?: string }; Returns: boolean }
    }
    Enums: {
      plan_type: "founder" | "basic" | "pro"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      plan_type: ["founder", "basic", "pro"],
    },
  },
} as const
