// Single source of truth for plan rules, limits and gating UX.
// Server enforces the same rules in SQL (current_plan, has_feature, can_use_lead).

import { supabase } from "@/integrations/supabase/client";

export type Plan = "founder" | "basic" | "pro";

export type Feature =
  | "leads"
  | "workbench"
  | "scripts"
  | "cronograma"
  | "prompts_avancados"
  | "gerador_prompts"
  | "venda_online";

export const PLAN_LIMITS: Record<Plan, { leadsPerDay: number; scriptsPerDay: number }> = {
  founder: { leadsPerDay: Infinity, scriptsPerDay: Infinity },
  pro: { leadsPerDay: 100, scriptsPerDay: Infinity },
  basic: { leadsPerDay: 30, scriptsPerDay: 1 },
};

const ACCESS: Record<Plan, Feature[]> = {
  founder: ["leads", "workbench", "scripts", "cronograma", "prompts_avancados", "gerador_prompts", "venda_online"],
  pro: ["leads", "workbench", "scripts", "cronograma", "prompts_avancados", "gerador_prompts", "venda_online"],
  // Basic: leads e workbench básico apenas. Bloqueado: gerador_prompts, cronograma, prompts_avancados. Liberado: venda_online (com limite local)
  basic: ["leads", "workbench", "venda_online"],
};

export function hasAccess(plan: Plan | null | undefined, feature: Feature): boolean {
  if (!plan) return false;
  return ACCESS[plan].includes(feature);
}

export function canUseLead(plan: Plan, leadsUsedToday: number): boolean {
  const limit = PLAN_LIMITS[plan].leadsPerDay;
  return leadsUsedToday < limit;
}

export function getUpgradeMessage(plan: Plan, feature: Feature): { title: string; body: string; cta: string } {
  const target: Plan = plan === "basic" ? "pro" : "pro";
  const map: Record<Feature, { title: string; body: string }> = {
    cronograma: {
      title: "🔥 Cronograma de conteúdo é PRO",
      body: "30 dias de posts prontos (Autoridade, Conexão e Venda) que geram clientes em piloto automático. Disponível no plano PRO.",
    },
    prompts_avancados: {
      title: "⚡ Prompts avançados são PRO",
      body: "Os prompts de tráfego, script e cronograma com método AIDA e canal específico ficam liberados no PRO.",
    },
    scripts: {
      title: "🔒 Mais scripts no PRO",
      body: "No Basic você gera 1 script por dia. PRO libera todos os tons e canais sem limite.",
    },
    leads: {
      title: "🚫 Limite diário atingido",
      body: `Você usou todos os ${PLAN_LIMITS[plan].leadsPerDay} leads de hoje. Usuários PRO capturam até 100 por dia.`,
    },
    workbench: {
      title: "🔒 Recurso bloqueado",
      body: "Esse recurso é exclusivo PRO.",
    },
    gerador_prompts: {
      title: "⚡ Mais Prompts Liberados no PRO",
      body: "Desbloqueie o gerador de VSL, Identidade Visual, Scripts com método AIDA, Tráfego e Cronograma! Gere abordagens de alta conversão sem limites.",
    },
    venda_online: {
      title: "🚫 Limite diário atingido",
      body: "Você já gerou 5 prompts de Venda Online hoje. Faça o upgrade para o PRO para gerar de forma ilimitada e liberar outras categorias incríveis!",
    },
  };
  const m = map[feature];
  return { ...m, cta: target === "pro" ? "Fazer upgrade para PRO" : "Ver planos" };
}

export function getLimitMessage(plan: Plan): string {
  const limit = PLAN_LIMITS[plan].leadsPerDay;
  return `🚫 Você atingiu o limite de ${limit} leads de hoje. Usuários PRO conseguem até 100 leads por dia.`;
}

// ---------- Tracking ----------
export async function trackEvent(
  eventType: "blocked_access" | "limit_reached" | "upgrade_clicked" | "checkout_started",
  feature?: Feature,
  metadata: Record<string, unknown> = {},
) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;
  await supabase.from("upgrade_events").insert([
    {
      user_id: user.id,
      event_type: eventType,
      feature: feature ?? null,
      metadata: metadata as never,
    } as never,
  ]);
}
