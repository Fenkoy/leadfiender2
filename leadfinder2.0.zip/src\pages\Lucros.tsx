import { useEffect, useMemo, useState } from "react";
import { DollarSign, TrendingUp, Target, Trophy, Sparkles } from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { AppShell } from "@/components/AppShell";
import type { Lead } from "@/components/LeadWorkbench";
import { SERVICES } from "@/components/LeadWorkbench";

const STORAGE_KEY = "lc_leads_v1";

// Neon palette aligned to site tokens
const NEON_COLORS = [
  "hsl(var(--primary))",
  "#22d3ee",
  "#a78bfa",
  "#f59e0b",
  "#f472b6",
  "#34d399",
];

function useLeads(): Lead[] {
  const [leads, setLeads] = useState<Lead[]>([]);
  useEffect(() => {
    const load = () => {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) setLeads(JSON.parse(raw));
        else setLeads([]);
      } catch {
        setLeads([]);
      }
    };
    load();
    // Re-read when storage changes (cross-tab) or window regains focus
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) load();
    };
    window.addEventListener("storage", onStorage);
    window.addEventListener("focus", load);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("focus", load);
    };
  }, []);
  return leads;
}

function fmtBRL(n: number) {
  return n.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
    maximumFractionDigits: 0,
  });
}

export default function Lucros() {
  const leads = useLeads();

  const closedLeads = useMemo(
    () => leads.filter((l) => l.status === "fechado"),
    [leads]
  );

  const faturamento = useMemo(
    () => closedLeads.reduce((acc, l) => acc + (l.contractValue ?? 0), 0),
    [closedLeads]
  );

  const taxaConversao =
    leads.length > 0 ? (closedLeads.length / leads.length) * 100 : 0;

  const roiTempo =
    leads.length > 0 ? faturamento / leads.length : 0;

  const ticketMedio =
    closedLeads.length > 0 ? faturamento / closedLeads.length : 0;

  const negotiatingLeads = useMemo(
    () => leads.filter((l) => l.status === "negociacao"),
    [leads]
  );

  const pipelineValue = useMemo(
    () => negotiatingLeads.reduce((acc, l) => acc + (l.contractValue ?? 0), 0),
    [negotiatingLeads]
  );

  // Funnel data
  const funnelData = useMemo(() => {
    const total = leads.length;
    const abordados = leads.filter(l => ["abordado", "negociacao", "fechado"].includes(l.status)).length;
    const negociacao = leads.filter(l => ["negociacao", "fechado"].includes(l.status)).length;
    const fechados = closedLeads.length;

    return [
      { name: "Total", value: total, fill: "hsl(var(--muted-foreground))" },
      { name: "Abordados", value: abordados, fill: "#3b82f6" },
      { name: "Em Negociação", value: negociacao, fill: "#f59e0b" },
      { name: "Fechados", value: fechados, fill: "#10b981" },
    ];
  }, [leads, closedLeads]);

  // Bump the value when faturamento changes — drives the "$ rising" animation
  const [pulseKey, setPulseKey] = useState(0);
  useEffect(() => {
    setPulseKey((k) => k + 1);
  }, [faturamento]);

  // Pie data per service
  const pieData = useMemo(() => {
    const map = new Map<string, number>();
    SERVICES.forEach((s) => map.set(s, 0));
    closedLeads.forEach((l) => {
      const k = l.contractService || "Outros";
      map.set(k, (map.get(k) ?? 0) + (l.contractValue ?? 0));
    });
    return Array.from(map.entries())
      .filter(([, v]) => v > 0)
      .map(([name, value]) => ({ name, value }));
  }, [closedLeads]);

  const totalPie = pieData.reduce((a, b) => a + b.value, 0);

  return (
    <AppShell>
      <main className="relative z-10 mx-auto max-w-5xl space-y-6 px-4 py-8">
        <header className="flex items-center gap-3">
          <span className="relative flex h-10 w-10 items-center justify-center rounded-md border border-primary/50 bg-background/80 shadow-[0_0_12px_hsl(var(--primary)/0.4)]">
            <DollarSign className="h-5 w-5 text-primary" />
            <span className="absolute inset-0 -z-10 animate-pulse rounded-md bg-primary/10 blur-sm" />
          </span>
          <div>
            <h1
              className="text-base font-extrabold uppercase tracking-[0.18em] text-foreground"
              style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
            >
              LUCROS <span className="text-primary">& BI</span>
            </h1>
            <p className="text-[11px] text-muted-foreground">
              Telemetria financeira em tempo real — alimentada pelos contratos fechados no Workbench.
            </p>
          </div>
        </header>

        {/* KPI cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <KPI
            icon={<DollarSign className="h-4 w-4 text-primary" />}
            label="Faturamento Total"
            value={fmtBRL(faturamento)}
            sub={`${closedLeads.length} contrato(s) fechado(s)`}
            highlight
            pulseKey={pulseKey}
          />
          <KPI
            icon={<Target className="h-4 w-4 text-primary" />}
            label="Receita em Pipeline"
            value={fmtBRL(pipelineValue)}
            sub={`${negotiatingLeads.length} negócio(s) em andamento`}
          />
          <KPI
            icon={<TrendingUp className="h-4 w-4 text-primary" />}
            label="Ticket Médio"
            value={fmtBRL(ticketMedio)}
            sub="Valor médio por contrato"
          />
          <KPI
            icon={<Trophy className="h-4 w-4 text-primary" />}
            label="Taxa de Conversão"
            value={`${taxaConversao.toFixed(1).replace(".", ",")}%`}
            sub={`${closedLeads.length} de ${leads.length} leads convertidos`}
          />
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {/* Donut chart */}
          <section className="hud-chamber rounded-lg border border-primary/30 bg-card/60 p-5 backdrop-blur-md">
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <h2
                className="text-sm font-bold uppercase tracking-wider text-foreground"
                style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
              >
                Mix de Produtos
              </h2>
            </div>

            {pieData.length === 0 ? (
              <p className="rounded border border-dashed border-border/60 bg-background/40 px-4 py-10 text-center text-xs text-muted-foreground">
                Nenhum contrato fechado ainda.
              </p>
            ) : (
              <div className="flex flex-col gap-4">
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={3}
                        stroke="hsl(var(--background))"
                        strokeWidth={2}
                      >
                        {pieData.map((_, i) => (
                          <Cell
                            key={i}
                            fill={NEON_COLORS[i % NEON_COLORS.length]}
                            style={{
                              filter: `drop-shadow(0 0 6px ${NEON_COLORS[i % NEON_COLORS.length]})`,
                            }}
                          />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          background: "hsl(var(--background))",
                          border: "1px solid hsl(var(--primary) / 0.5)",
                          borderRadius: 6,
                          fontSize: 12,
                        }}
                        formatter={(v: number) => fmtBRL(v)}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <ul className="space-y-1.5 text-xs">
                  {pieData
                    .slice()
                    .sort((a, b) => b.value - a.value)
                    .map((d, i) => {
                      const pct = totalPie > 0 ? (d.value / totalPie) * 100 : 0;
                      return (
                        <li
                          key={d.name}
                          className="flex items-center justify-between gap-2 rounded border border-border/40 bg-background/40 px-2 py-1.5"
                        >
                          <span className="flex items-center gap-2 truncate">
                            <span
                              className="h-2 w-2 shrink-0 rounded-full"
                              style={{
                                background: NEON_COLORS[i % NEON_COLORS.length],
                                boxShadow: `0 0 6px ${NEON_COLORS[i % NEON_COLORS.length]}`,
                              }}
                            />
                            <span className="truncate">{d.name}</span>
                          </span>
                          <span className="shrink-0 font-mono text-[10px] text-muted-foreground">
                            {pct.toFixed(0)}%
                          </span>
                        </li>
                      );
                    })}
                </ul>
              </div>
            )}
          </section>

          {/* Funnel chart */}
          <section className="hud-chamber rounded-lg border border-primary/30 bg-card/60 p-5 backdrop-blur-md">
            <div className="mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              <h2
                className="text-sm font-bold uppercase tracking-wider text-foreground"
                style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
              >
                Funil de Vendas
              </h2>
            </div>
            {leads.length === 0 ? (
              <p className="rounded border border-dashed border-border/60 bg-background/40 px-4 py-10 text-center text-xs text-muted-foreground">
                Nenhum lead encontrado.
              </p>
            ) : (
              <div className="h-64 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={funnelData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(var(--border))" />
                    <XAxis type="number" hide />
                    <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fill: "hsl(var(--foreground))", fontSize: 11 }} width={90} />
                    <Tooltip
                      cursor={{ fill: "hsl(var(--muted))", opacity: 0.2 }}
                      contentStyle={{
                        background: "hsl(var(--background))",
                        border: "1px solid hsl(var(--primary) / 0.5)",
                        borderRadius: 6,
                        fontSize: 12,
                      }}
                    />
                    <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                      {funnelData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </section>
        </div>



        {/* Top contratos */}
        <section className="hud-chamber rounded-lg border border-primary/30 bg-card/60 p-5 backdrop-blur-md">
          <div className="mb-3 flex items-center gap-2">
            <Trophy className="h-4 w-4 text-primary" />
            <h2
              className="text-sm font-bold uppercase tracking-wider text-foreground"
              style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
            >
              Contratos Fechados
            </h2>
          </div>
          {closedLeads.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              Sem contratos registrados ainda.
            </p>
          ) : (
            <ul className="divide-y divide-border/40">
              {closedLeads
                .slice()
                .sort((a, b) => (b.contractValue ?? 0) - (a.contractValue ?? 0))
                .map((l) => (
                  <li
                    key={l.id}
                    className="flex items-center justify-between gap-3 py-2 text-xs"
                  >
                    <span className="flex min-w-0 flex-1 items-center gap-2">
                      <span className="truncate font-semibold text-foreground">
                        {l.name || "(sem nome)"}
                      </span>
                      <span className="rounded border border-primary/30 bg-primary/10 px-1.5 py-0.5 text-[10px] text-primary">
                        {l.contractService ?? "—"}
                      </span>
                    </span>
                    <span className="font-mono text-sm font-bold text-primary">
                      {fmtBRL(l.contractValue ?? 0)}
                    </span>
                  </li>
                ))}
            </ul>
          )}
        </section>
      </main>
    </AppShell>
  );
}

function KPI({
  icon,
  label,
  value,
  sub,
  highlight,
  pulseKey,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  highlight?: boolean;
  pulseKey?: number;
}) {
  return (
    <div
      className={`hud-chamber rounded-lg border bg-card/50 p-4 backdrop-blur-md transition ${
        highlight
          ? "border-primary/50 shadow-[0_0_18px_hsl(var(--primary)/0.25)]"
          : "border-border/60"
      }`}
    >
      <div className="mb-2 flex items-center gap-2">
        {icon}
        <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
      </div>
      <div
        key={pulseKey}
        className={`text-2xl font-extrabold tracking-tight ${
          highlight ? "text-primary money-rise" : "text-foreground"
        }`}
        style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
      >
        {value}
      </div>
      {sub && (
        <div className="mt-1 text-[10px] text-muted-foreground">{sub}</div>
      )}
    </div>
  );
}
