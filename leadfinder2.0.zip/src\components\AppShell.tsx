import { ArrowLeft, Briefcase, Crown, DollarSign, LogOut, Sparkles, Target, Zap } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { NavLink } from "@/components/NavLink";
import { useAuth } from "@/hooks/useAuth";
import { PLAN_LIMITS } from "@/lib/plans";

function PlanBadge() {
  const { plan, leadsUsedToday, signOut, user } = useAuth();
  if (!user) return null;
  const limit = plan ? PLAN_LIMITS[plan].leadsPerDay : 0;
  const limitLabel = plan === "founder" ? "∞" : limit;
  const Icon = plan === "founder" ? Crown : plan === "pro" ? Sparkles : Zap;
  const tone =
    plan === "founder"
      ? "border-yellow-500/50 text-yellow-500 bg-yellow-500/10"
      : plan === "pro"
        ? "border-primary/50 text-primary bg-primary/10"
        : "border-border text-muted-foreground bg-background";
  return (
    <div className="flex items-center gap-1.5">
      <Link
        to="/pricing"
        className={`inline-flex items-center gap-1 rounded border px-2 py-1 font-mono text-[10px] font-bold uppercase tracking-wider ${tone}`}
        title={`Plano ${plan} · ${leadsUsedToday}/${limitLabel} leads hoje`}
      >
        <Icon className="h-3 w-3" />
        {plan}
        <span className="ml-1 opacity-70">
          {leadsUsedToday}/{limitLabel}
        </span>
      </Link>
      <button
        onClick={signOut}
        className="inline-flex items-center justify-center rounded border border-border bg-background p-1 text-muted-foreground transition hover:border-destructive hover:text-destructive"
        title="Sair"
      >
        <LogOut className="h-3 w-3" />
      </button>
    </div>
  );
}

function BackButton() {
  const location = useLocation();
  const navigate = useNavigate();
  if (location.pathname === "/") return null;
  return (
    <button
      onClick={() => navigate(-1)}
      className="inline-flex items-center gap-1 rounded-md border border-border bg-background/60 px-2.5 py-1.5 text-[11px] font-medium text-muted-foreground transition hover:text-foreground hover:border-primary/30"
      title="Voltar"
    >
      <ArrowLeft className="h-3.5 w-3.5" />
      Voltar
    </button>
  );
}

/**
 * Wraps every page with the shared neural background, header (with section
 * tabs) and footer. Pages render their own <main>.
 */
export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative min-h-screen text-foreground">
      <div aria-hidden className="neural-bg" />
      <div aria-hidden className="neural-vignette" />

      <header className="relative z-10 border-b border-primary/20 bg-background/60 backdrop-blur-md">
        <div className="mx-auto flex max-w-5xl flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
          <NavLink to="/" className="group inline-flex items-center gap-2.5">
            <span className="relative flex h-8 w-8 items-center justify-center rounded-md border border-primary/50 bg-background/80 shadow-[0_0_12px_hsl(var(--primary)/0.35)] transition-all group-hover:shadow-[0_0_18px_hsl(var(--primary)/0.6)]">
              <Target className="h-4 w-4 text-primary" strokeWidth={2.2} />
              <span className="absolute inset-0 -z-10 animate-pulse rounded-md bg-primary/10 blur-sm" />
            </span>
            <span className="flex flex-col leading-none">
              <span
                className="text-[15px] font-extrabold tracking-[0.18em] text-foreground"
                style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
              >
                LEAD<span className="text-primary">FINDER</span>
              </span>
              <span className="mt-0.5 text-[9px] uppercase tracking-[0.32em] text-muted-foreground">
                by Gabriel Leite
              </span>
            </span>
          </NavLink>

          <BackButton />
          <nav className="flex items-center gap-1 overflow-x-auto rounded-md border border-border bg-background/60 p-0.5 backdrop-blur">
            <NavLink
              to="/"
              end
              className="inline-flex items-center gap-1.5 whitespace-nowrap rounded px-3 py-1.5 font-mono text-[11px] font-semibold uppercase tracking-wider text-muted-foreground transition hover:text-foreground"
              activeClassName="bg-primary text-primary-foreground shadow-[0_0_10px_hsl(var(--primary)/0.5)] !text-primary-foreground"
            >
              <Briefcase className="h-3.5 w-3.5" />
              Workbench
            </NavLink>
            <NavLink
              to="/lucros"
              className="inline-flex items-center gap-1.5 whitespace-nowrap rounded px-3 py-1.5 font-mono text-[11px] font-semibold uppercase tracking-wider text-muted-foreground transition hover:text-foreground"
              activeClassName="bg-primary text-primary-foreground shadow-[0_0_10px_hsl(var(--primary)/0.5)] !text-primary-foreground"
            >
              <DollarSign className="h-3.5 w-3.5" />
              Lucros & BI
            </NavLink>
            <span className="ml-1 hidden font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground sm:inline">
              ◉ ativo
            </span>
          </nav>

          <PlanBadge />
        </div>
      </header>

      {children}

      <footer className="relative z-10 mt-8 border-t border-primary/15 bg-background/50 backdrop-blur-md">
        <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-2 px-4 py-5 text-center sm:flex-row sm:text-left">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary shadow-[0_0_6px_hsl(var(--primary))]" />
            <span
              className="text-[11px] tracking-[0.18em] text-muted-foreground"
              style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
            >
              LEAD<span className="text-primary">FINDER</span> · {new Date().getFullYear()}
            </span>
          </div>
          <div className="flex flex-col items-center gap-0.5 sm:items-end">
            <span
              className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground"
              style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
            >
              crafted &amp; thinked by{" "}
              <span className="text-primary">Gabriel Leite</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
