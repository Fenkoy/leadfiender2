import { useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { hasAccess, canUseLead, getLimitMessage, getUpgradeMessage, trackEvent, type Feature, type Plan } from "@/lib/plans";
import { useToast } from "@/hooks/use-toast";

/**
 * Central gating hook. ALL feature checks and lead consumption MUST go through here.
 * Backend (RLS + RPCs) re-validates everything; the UI only shortcuts the obvious cases.
 */
export function useGate() {
  const { profile, plan, leadsUsedToday, refresh } = useAuth();
  const { toast } = useToast();

  // Admins têm passe livre
  const isAdmin = !!profile?.is_admin;
  const effectivePlan: Plan = isAdmin ? "founder" : (plan ?? "basic");

  const canUseSystem = useCallback((): boolean => {
    if (isAdmin || effectivePlan === "founder") return true;
    return canUseLead(effectivePlan, leadsUsedToday);
  }, [isAdmin, effectivePlan, leadsUsedToday]);

  const checkFeature = useCallback(
    (feature: Feature): boolean => {
      if (isAdmin) return true;
      return hasAccess(effectivePlan, feature);
    },
    [isAdmin, effectivePlan],
  );

  const blockWithUpgrade = useCallback(
    (feature: Feature) => {
      const msg = getUpgradeMessage(effectivePlan, feature);
      toast({ title: msg.title, description: msg.body, variant: "destructive" });
      trackEvent("blocked_access", feature, { plan: effectivePlan });
    },
    [effectivePlan, toast],
  );

  const blockLimitReached = useCallback(() => {
    toast({
      title: "🚫 Limite atingido",
      description: getLimitMessage(effectivePlan),
      variant: "destructive",
    });
    trackEvent("limit_reached", "leads", { plan: effectivePlan, leadsUsedToday });
  }, [effectivePlan, leadsUsedToday, toast]);

  /**
   * Tenta consumir 1 lead via RPC (servidor é a fonte da verdade).
   * Use APENAS quando: usuário analisa um lead, gera abordagem ou gera proposta.
   * NÃO usar em busca/visualização.
   */
  const tryConsumeLead = useCallback(async (): Promise<boolean> => {
    if (isAdmin) return true;
    // Pre-check rápido client-side
    if (!canUseSystem()) {
      blockLimitReached();
      return false;
    }
    const { data, error } = await supabase.rpc("consume_lead");
    if (error || data === false) {
      blockLimitReached();
      await refresh();
      return false;
    }
    await refresh();
    return true;
  }, [isAdmin, canUseSystem, blockLimitReached, refresh]);

  return {
    plan: effectivePlan,
    isAdmin,
    leadsUsedToday,
    canUseSystem,
    checkFeature,
    blockWithUpgrade,
    blockLimitReached,
    tryConsumeLead,
  };
}
