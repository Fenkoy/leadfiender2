import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Check, ChefHat, Scissors, Stethoscope, Pencil, Loader2, Rocket, Target, Sparkles, TrendingUp, FlaskConical } from "lucide-react";
import { cn } from "@/lib/utils";

type NicheKey = "restaurante" | "barbearia" | "estetica" | "outros";
type Goal = "clientes_rapido" | "testar" | "renda_extra";
type Experience = "nunca" | "ja_tentei" | "ja_vendo";

const NICHE_OPTIONS: { key: NicheKey; label: string; Icon: typeof ChefHat; emoji: string }[] = [
  { key: "restaurante", label: "Restaurantes", Icon: ChefHat, emoji: "🍽️" },
  { key: "barbearia", label: "Barbearias", Icon: Scissors, emoji: "💈" },
  { key: "estetica", label: "Clínicas", Icon: Stethoscope, emoji: "🩺" },
  { key: "outros", label: "Outro", Icon: Pencil, emoji: "✏️" },
];

const GOAL_OPTIONS: { key: Goal; label: string; desc: string; Icon: typeof Rocket }[] = [
  { key: "clientes_rapido", label: "Conseguir clientes rápido", desc: "Quero fechar contratos nos próximos dias", Icon: Rocket },
  { key: "testar", label: "Testar o sistema", desc: "Quero ver como funciona antes de me comprometer", Icon: FlaskConical },
  { key: "renda_extra", label: "Criar renda extra", desc: "Quero uma fonte adicional de receita constante", Icon: TrendingUp },
];

const EXP_OPTIONS: { key: Experience; label: string; desc: string }[] = [
  { key: "nunca", label: "Nunca vendi", desc: "Sou iniciante em vendas e prospecção" },
  { key: "ja_tentei", label: "Já tentei vender", desc: "Já fiz algumas tentativas, com pouco resultado" },
  { key: "ja_vendo", label: "Já vendo serviços", desc: "Tenho experiência ativa em vendas B2B" },
];

const LOADING_BASE_STEPS = [
  "Analisando seu perfil...",
  "Buscando {NICHE} com potencial na sua região...",
  "Identificando negócios com presença digital fraca...",
  "Preparando seus primeiros leads...",
];

export default function Onboarding() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile } = useAuth();

  const [step, setStep] = useState(1);
  const [niche, setNiche] = useState<NicheKey | null>(null);
  const [customNiche, setCustomNiche] = useState("");
  const [goal, setGoal] = useState<Goal | null>(null);
  const [experience, setExperience] = useState<Experience | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [loadingScreen, setLoadingScreen] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);

  // Se já completou onboarding, manda pro dashboard
  useEffect(() => {
    if (profile?.onboarding_completed) navigate("/", { replace: true });
  }, [profile, navigate]);

  const progress = step === 1 ? 33 : step === 2 ? 66 : 100;

  const nicheLabel = useMemo(() => {
    if (niche === "outros") return customNiche.trim() || "negócios";
    return NICHE_OPTIONS.find((n) => n.key === niche)?.label.toLowerCase() ?? "negócios";
  }, [niche, customNiche]);

  const finishOnboarding = async () => {
    if (!user || !niche || !goal || !experience) return;
    setSubmitting(true);

    const finalNiche = niche === "outros" ? (customNiche.trim() || "outros") : niche;

    // Garantir profile (caso trigger não tenha rodado) e atualizar
    const { error } = await supabase.from("profiles").update({
      niche: finalNiche,
      goal,
      experience,
      onboarding_completed: true,
    }).eq("id", user.id);

    if (error) {
      console.error("Onboarding error:", error);
      // Fallback: se update falhar por falta da linha (trigger demorou/falhou), tenta insert:
      if (error.code === 'PGRST116' || error.message?.includes('0 rows') || error.code === '404') {
        const { error: insertError } = await supabase.from("profiles").insert({
          id: user.id,
          email: user.email,
          niche: finalNiche,
          goal,
          experience,
          onboarding_completed: true,
        });
        if (insertError) {
          alert("Erro crítico ao salvar perfil: " + insertError.message);
          setSubmitting(false);
          return;
        }
      } else {
        alert("Erro ao salvar perfil: " + error.message);
        setSubmitting(false);
        return;
      }
    }

    setSubmitting(false);
    setLoadingScreen(true);
  };

  // Sequência da tela de loading premium
  useEffect(() => {
    if (!loadingScreen) return;
    const timers: ReturnType<typeof setTimeout>[] = [];
    [700, 1500, 2300, 3100].forEach((ms, i) => {
      timers.push(setTimeout(() => setLoadingStep(i + 1), ms));
    });
    timers.push(
      setTimeout(async () => {
        await refreshProfile();
        const finalNiche = niche === "outros" ? (customNiche.trim() || "outros") : niche;
        navigate("/", { replace: true, state: { onboardingNiche: finalNiche, autoSearch: true } });
      }, 3900),
    );
    return () => timers.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadingScreen]);

  if (loadingScreen) {
    const steps = LOADING_BASE_STEPS.map((s) => s.replace("{NICHE}", nicheLabel));
    return (
      <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4">
        <div className="neural-vignette" />
        <div className="relative z-10 w-full max-w-xl animate-fade-in">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/15 ring-1 ring-primary/40">
              <Sparkles className="h-7 w-7 text-primary" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">Configurando sua experiência</h1>
            <p className="mt-2 text-muted-foreground">Estamos encontrando oportunidades reais pra você</p>
          </div>

          <ul className="space-y-3 rounded-2xl border border-border/60 bg-card/60 p-5 backdrop-blur">
            {steps.map((label, i) => {
              const done = loadingStep > i;
              const active = loadingStep === i;
              return (
                <li
                  key={i}
                  className={cn(
                    "flex items-center gap-3 rounded-xl px-3 py-3 transition-all",
                    done && "bg-primary/5",
                    active && "bg-primary/10",
                    !done && !active && "opacity-50",
                  )}
                >
                  <span className="flex h-7 w-7 items-center justify-center rounded-full border border-border bg-background">
                    {done ? (
                      <Check className="h-4 w-4 text-primary" />
                    ) : active ? (
                      <Loader2 className="h-4 w-4 animate-spin text-primary" />
                    ) : (
                      <span className="h-2 w-2 rounded-full bg-muted-foreground/40" />
                    )}
                  </span>
                  <span className={cn("text-base", done && "text-foreground", active && "text-foreground font-medium")}>
                    {label}
                  </span>
                </li>
              );
            })}
          </ul>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {loadingStep < 3 ? "Estamos encontrando oportunidades reais" : "Quase pronto..."}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4 py-10">
      <div className="neural-vignette" />
      <div className="relative z-10 w-full max-w-2xl">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between text-sm">
          <span className="font-medium text-muted-foreground">Etapa {step} de 3</span>
          <span className="text-muted-foreground">Leva menos de 30 segundos</span>
        </div>
        <Progress value={progress} className="mb-8 h-2" />

        <div key={step} className="animate-fade-in">
          {step === 1 && (
            <section>
              <h1 className="text-3xl font-bold tracking-tight md:text-4xl">Qual nicho você quer atender?</h1>
              <p className="mt-2 text-muted-foreground">Vamos encontrar clientes pra você nesse mercado</p>

              <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {NICHE_OPTIONS.map((n) => {
                  const selected = niche === n.key;
                  return (
                    <button
                      key={n.key}
                      type="button"
                      onClick={() => setNiche(n.key)}
                      className={cn(
                        "group flex items-center gap-4 rounded-2xl border-2 bg-card/60 p-5 text-left transition-all hover:scale-[1.01]",
                        selected ? "border-primary shadow-[0_0_0_4px_hsl(var(--primary)/0.15)]" : "border-border hover:border-primary/40",
                      )}
                    >
                      <span className="text-3xl">{n.emoji}</span>
                      <span className="flex-1 text-lg font-semibold">{n.label}</span>
                      {selected && <Check className="h-5 w-5 text-primary" />}
                    </button>
                  );
                })}
              </div>

              {niche === "outros" && (
                <div className="mt-4 animate-fade-in">
                  <label className="mb-2 block text-sm font-medium text-muted-foreground">
                    Conta pra gente qual nicho você quer atender:
                  </label>
                  <Textarea
                    autoFocus
                    placeholder="Ex.: pet shops, academias, advogados..."
                    value={customNiche}
                    onChange={(e) => setCustomNiche(e.target.value)}
                    className="text-base"
                  />
                </div>
              )}

              <div className="mt-8 flex justify-end">
                <Button
                  size="lg"
                  disabled={!niche || (niche === "outros" && !customNiche.trim())}
                  onClick={() => setStep(2)}
                  className="min-w-[160px]"
                >
                  Continuar
                </Button>
              </div>
            </section>
          )}

          {step === 2 && (
            <section>
              <div className="mb-2 flex items-center gap-2 text-sm text-primary">
                <Target className="h-4 w-4" /> Seu objetivo
              </div>
              <h1 className="text-3xl font-bold tracking-tight md:text-4xl">O que você quer alcançar?</h1>
              <p className="mt-2 text-muted-foreground">Vamos personalizar o sistema com base no que importa pra você</p>

              <div className="mt-8 space-y-3">
                {GOAL_OPTIONS.map((o) => {
                  const selected = goal === o.key;
                  const Icon = o.Icon;
                  return (
                    <button
                      key={o.key}
                      type="button"
                      onClick={() => setGoal(o.key)}
                      className={cn(
                        "flex w-full items-center gap-4 rounded-2xl border-2 bg-card/60 p-5 text-left transition-all hover:scale-[1.005]",
                        selected ? "border-primary shadow-[0_0_0_4px_hsl(var(--primary)/0.15)]" : "border-border hover:border-primary/40",
                      )}
                    >
                      <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                        <Icon className="h-6 w-6" />
                      </span>
                      <span className="flex-1">
                        <span className="block text-lg font-semibold">{o.label}</span>
                        <span className="block text-sm text-muted-foreground">{o.desc}</span>
                      </span>
                      {selected && <Check className="h-5 w-5 text-primary" />}
                    </button>
                  );
                })}
              </div>

              <div className="mt-8 flex items-center justify-between">
                <Button variant="ghost" onClick={() => setStep(1)}>
                  Voltar
                </Button>
                <Button size="lg" disabled={!goal} onClick={() => setStep(3)} className="min-w-[160px]">
                  Continuar
                </Button>
              </div>
            </section>
          )}

          {step === 3 && (
            <section>
              <h1 className="text-3xl font-bold tracking-tight md:text-4xl">Qual seu nível com vendas?</h1>
              <p className="mt-2 text-muted-foreground">Sem julgamento — vamos ajustar a experiência pra você</p>

              <div className="mt-8 space-y-3">
                {EXP_OPTIONS.map((o) => {
                  const selected = experience === o.key;
                  return (
                    <button
                      key={o.key}
                      type="button"
                      onClick={() => setExperience(o.key)}
                      className={cn(
                        "flex w-full items-center gap-4 rounded-2xl border-2 bg-card/60 p-5 text-left transition-all hover:scale-[1.005]",
                        selected ? "border-primary shadow-[0_0_0_4px_hsl(var(--primary)/0.15)]" : "border-border hover:border-primary/40",
                      )}
                    >
                      <span className="flex-1">
                        <span className="block text-lg font-semibold">{o.label}</span>
                        <span className="block text-sm text-muted-foreground">{o.desc}</span>
                      </span>
                      {selected && <Check className="h-5 w-5 text-primary" />}
                    </button>
                  );
                })}
              </div>

              <div className="mt-8 flex items-center justify-between">
                <Button variant="ghost" onClick={() => setStep(2)} disabled={submitting}>
                  Voltar
                </Button>
                <Button
                  size="lg"
                  disabled={!experience || submitting}
                  onClick={finishOnboarding}
                  className="min-w-[200px]"
                >
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Concluir e começar"}
                </Button>
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
