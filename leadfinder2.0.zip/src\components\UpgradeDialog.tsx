import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { trackEvent, type Feature } from "@/lib/plans";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  feature: Feature;
  title: string;
  body: string;
  cta: string;
};

export function UpgradeDialog({ open, onOpenChange, feature, title, body, cta }: Props) {
  const navigate = useNavigate();
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-primary/30">
        <DialogHeader>
          <DialogTitle className="text-lg">{title}</DialogTitle>
          <DialogDescription className="pt-2 text-sm leading-relaxed">{body}</DialogDescription>
        </DialogHeader>
        <DialogFooter className="gap-2 sm:gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Agora não
          </Button>
          <Button
            onClick={async () => {
              await trackEvent("upgrade_clicked", feature);
              onOpenChange(false);
              navigate("/pricing");
            }}
          >
            {cta}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
