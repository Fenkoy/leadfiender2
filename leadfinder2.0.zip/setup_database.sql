-- Cleaned and consolidated database setup

-- 1. Enum de planos
DO $$ BEGIN
    CREATE TYPE public.plan_type AS ENUM ('founder', 'basic', 'pro');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;
ALTER TYPE public.plan_type ADD VALUE IF NOT EXISTS 'founder';
ALTER TYPE public.plan_type ADD VALUE IF NOT EXISTS 'basic';
ALTER TYPE public.plan_type ADD VALUE IF NOT EXISTS 'pro';

-- 2. Profiles (1:1 com auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  niche text,
  goal text,
  experience text,
  onboarding_completed boolean not null default false,
  is_admin boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- (drop policies if they exist so we can recreate them cleanly)
drop policy if exists "profiles_self_select" on public.profiles;
drop policy if exists "profiles_self_update" on public.profiles;
drop policy if exists "profiles_self_insert" on public.profiles;
drop policy if exists "profiles_admin_select" on public.profiles;

create policy "profiles_self_select" on public.profiles
  for select to authenticated using (id = auth.uid());
create policy "profiles_self_update" on public.profiles
  for update to authenticated using (id = auth.uid());
create policy "profiles_self_insert" on public.profiles
  for insert to authenticated with check (id = auth.uid());

-- 3. user_plans
CREATE TABLE IF NOT EXISTS public.user_plans (
  user_id uuid primary key references auth.users(id) on delete cascade,
  plan public.plan_type not null default 'basic',
  status text not null default 'active',
  current_period_end timestamptz,
  stripe_customer_id text,
  stripe_subscription_id text,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
alter table public.user_plans enable row level security;

drop policy if exists "user_plans_self_select" on public.user_plans;
drop policy if exists "user_plans_admin_select" on public.user_plans;

create policy "user_plans_self_select" on public.user_plans
  for select to authenticated using (user_id = auth.uid());

-- 4. lead_usage
CREATE TABLE IF NOT EXISTS public.lead_usage (
  user_id uuid primary key references auth.users(id) on delete cascade,
  leads_used_today integer not null default 0,
  last_reset_date date not null default current_date,
  updated_at timestamptz not null default now()
);
alter table public.lead_usage enable row level security;

drop policy if exists "lead_usage_self_select" on public.lead_usage;
drop policy if exists "lead_usage_admin_select" on public.lead_usage;

create policy "lead_usage_self_select" on public.lead_usage
  for select to authenticated using (user_id = auth.uid());

-- 5. upgrade_events
CREATE TABLE IF NOT EXISTS public.upgrade_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  event_type text not null,
  feature text,
  from_plan public.plan_type,
  to_plan public.plan_type,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);
alter table public.upgrade_events enable row level security;

drop policy if exists "upgrade_events_self_select" on public.upgrade_events;
drop policy if exists "upgrade_events_self_insert" on public.upgrade_events;

create policy "upgrade_events_self_select" on public.upgrade_events
  for select to authenticated using (user_id = auth.uid());
create policy "upgrade_events_self_insert" on public.upgrade_events
  for insert to authenticated with check (user_id = auth.uid());

drop index if exists upgrade_events_user_idx;
create index upgrade_events_user_idx on public.upgrade_events (user_id, created_at desc);

-- 6. founder_slots
CREATE TABLE IF NOT EXISTS public.founder_slots (
  id integer primary key default 1,
  total_slots integer not null default 50,
  claimed integer not null default 0,
  updated_at timestamptz not null default now(),
  constraint founder_slots_singleton check (id = 1)
);
alter table public.founder_slots enable row level security;
insert into public.founder_slots (id, total_slots, claimed) values (1, 50, 0) on conflict do nothing;

drop policy if exists "founder_slots_public_read" on public.founder_slots;
create policy "founder_slots_public_read" on public.founder_slots
  for select to anon, authenticated using (true);

-- Funções e RPCs

-- is_admin
create or replace function public.is_admin(_uid uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select is_admin from public.profiles where id = _uid), false);
$$;

-- Atualiza políticas de admin
create policy "profiles_admin_select" on public.profiles
  for select to authenticated using (public.is_admin());
create policy "user_plans_admin_select" on public.user_plans
  for select to authenticated using (public.is_admin());
create policy "lead_usage_admin_select" on public.lead_usage
  for select to authenticated using (public.is_admin());

-- handle_new_user
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  _is_admin boolean := lower(new.email) = 'gabrieleitejesus@gmail.com';
begin
  insert into public.profiles (id, full_name, email, is_admin)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', ''),
    new.email,
    _is_admin
  )
  on conflict (id) do update set is_admin = excluded.is_admin or public.profiles.is_admin;

  insert into public.user_plans (user_id, plan, status)
  values (new.id, case when _is_admin then 'founder'::public.plan_type else 'basic'::public.plan_type end, 'active')
  on conflict (user_id) do nothing;

  insert into public.lead_usage (user_id) values (new.id)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- current_plan
create or replace function public.current_plan()
returns public.plan_type
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select plan from public.user_plans
      where user_id = auth.uid()
        and status = 'active'
        and (plan = 'founder' or current_period_end is null or current_period_end > now())
      limit 1),
    'basic'::public.plan_type
  );
$$;

-- has_feature
create or replace function public.has_feature(_feature text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select case public.current_plan()
    when 'founder' then true
    when 'pro'     then true
    when 'basic'   then _feature in ('leads', 'workbench', 'scripts')
  end;
$$;

-- can_use_lead
create or replace function public.can_use_lead()
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  _plan public.plan_type;
  _used integer;
  _reset date;
begin
  _plan := public.current_plan();
  if _plan = 'founder' then return true; end if;

  select leads_used_today, last_reset_date
    into _used, _reset
    from public.lead_usage
    where user_id = auth.uid();

  if _reset is null or _reset < current_date then
    return true;
  end if;

  if _plan = 'pro'   and _used >= 100 then return false; end if;
  if _plan = 'basic' and _used >= 30  then return false; end if;
  return true;
end;
$$;

-- consume_lead
create or replace function public.consume_lead()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  _plan public.plan_type;
  _limit integer;
  _used integer;
  _reset date;
begin
  if auth.uid() is null then return false; end if;
  _plan := public.current_plan();

  insert into public.lead_usage (user_id) values (auth.uid())
  on conflict (user_id) do nothing;

  select leads_used_today, last_reset_date
    into _used, _reset
    from public.lead_usage
    where user_id = auth.uid()
    for update;

  if _reset < current_date then
    _used := 0;
    update public.lead_usage
       set leads_used_today = 0, last_reset_date = current_date, updated_at = now()
     where user_id = auth.uid();
  end if;

  _limit := case _plan
              when 'founder' then 2147483647
              when 'pro' then 100
              when 'basic' then 30
            end;

  if _used >= _limit then
    insert into public.upgrade_events (user_id, event_type, feature, from_plan, metadata)
    values (auth.uid(), 'limit_reached', 'leads', _plan, jsonb_build_object('limit', _limit));
    return false;
  end if;

  update public.lead_usage
     set leads_used_today = leads_used_today + 1, updated_at = now()
   where user_id = auth.uid();
  return true;
end;
$$;

-- claim_founder
create or replace function public.claim_founder()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  _claimed integer;
  _total integer;
begin
  if auth.uid() is null then return false; end if;

  select claimed, total_slots into _claimed, _total
    from public.founder_slots where id = 1 for update;

  if _claimed >= _total then return false; end if;

  update public.founder_slots
     set claimed = claimed + 1, updated_at = now()
   where id = 1;

  update public.user_plans
     set plan = 'founder', status = 'active', current_period_end = null, updated_at = now()
   where user_id = auth.uid();

  return true;
end;
$$;

-- admin_list_users
create or replace function public.admin_list_users()
returns table (
  user_id uuid,
  email text,
  full_name text,
  is_admin boolean,
  plan public.plan_type,
  leads_used_today integer,
  last_reset_date date,
  created_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden';
  end if;
  return query
    select
      p.id,
      p.email,
      p.full_name,
      p.is_admin,
      coalesce(up.plan, 'basic'::public.plan_type),
      coalesce(case when lu.last_reset_date = current_date then lu.leads_used_today else 0 end, 0),
      coalesce(lu.last_reset_date, current_date),
      p.created_at
    from public.profiles p
    left join public.user_plans up on up.user_id = p.id
    left join public.lead_usage lu on lu.user_id = p.id
    order by p.created_at desc;
end;
$$;

-- admin_set_plan
create or replace function public.admin_set_plan(_user_id uuid, _plan public.plan_type)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden';
  end if;
  insert into public.user_plans (user_id, plan, status)
  values (_user_id, _plan, 'active')
  on conflict (user_id) do update
    set plan = excluded.plan,
        status = 'active',
        current_period_end = case when excluded.plan = 'founder' then null else public.user_plans.current_period_end end,
        updated_at = now();
  return true;
end;
$$;

-- admin_reset_leads
create or replace function public.admin_reset_leads(_user_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden';
  end if;
  insert into public.lead_usage (user_id, leads_used_today, last_reset_date, updated_at)
  values (_user_id, 0, current_date, now())
  on conflict (user_id) do update
    set leads_used_today = 0,
        last_reset_date = current_date,
        updated_at = now();
  return true;
end;
$$;

-- admin_delete_user
create or replace function public.admin_delete_user(_user_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden';
  end if;
  if _user_id = auth.uid() then
    raise exception 'cannot delete self';
  end if;
  delete from auth.users where id = _user_id;
  return true;
end;
$$;
