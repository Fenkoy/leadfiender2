import { useEffect, useState, useMemo } from "react";
import {
  Target,
  Search,
  ExternalLink,
  FileText,
  Copy,
  Check,
  Download,
  Sparkles,
  History,
  Trash2,
  Flame,
  ChevronDown,
  ChevronUp,
  Globe,
  Play,
  Image as ImageIcon,
  MessageSquare,
  Megaphone,
  CalendarDays,
  Upload,
  
  X,
} from "lucide-react";
import { jsPDF } from "jspdf";
import { NICHES, getNiche } from "@/lib/niches";
import {
  fetchCountries,
  fetchStates,
  fetchCities,
  type Country,
  type State,
  type City,
} from "@/lib/places";
import { LeadWorkbench } from "@/components/LeadWorkbench";
import { AppShell } from "@/components/AppShell";
import { useAuth } from "@/hooks/useAuth";
import { useGate } from "@/hooks/useGate";
import { usePersonalization } from "@/hooks/usePersonalization";
import { PLAN_LIMITS } from "@/lib/plans";
import { useLocation, Link } from "react-router-dom";
import { Lock, Lightbulb } from "lucide-react";

const VALID_NICHE_IDS = new Set(["restaurante", "barbearia", "pizzaria", "hamburgueria", "salao", "estetica", "nutricao", "psicologia", "terapia", "perfumaria", "outros"]);

function Index() {
  const { profile } = useAuth();
  const gate = useGate();
  const personalization = usePersonalization();
  const location = useLocation();
  const initialNiche = (() => {
    const fromState = (location.state as { onboardingNiche?: string } | null)?.onboardingNiche;
    const candidate = fromState ?? profile?.niche ?? "restaurante";
    if (candidate && VALID_NICHE_IDS.has(candidate)) return candidate;
    return candidate ? "outros" : "restaurante";
  })();
  const initialCustom = (() => {
    const fromState = (location.state as { onboardingNiche?: string } | null)?.onboardingNiche;
    const candidate = fromState ?? profile?.niche ?? "";
    if (candidate && !VALID_NICHE_IDS.has(candidate)) return candidate;
    return "";
  })();
  

  // ---------- Search ----------
  const [nicheId, setNicheId] = useState(initialNiche);
  const [customKeyword, setCustomKeyword] = useState(initialCustom);
  const [countries, setCountries] = useState<Country[]>([]);
  const [countryCode, setCountryCode] = useState("BR");
  const [states, setStates] = useState<State[]>([]);
  const [stateCode, setStateCode] = useState("");
  const [cities, setCities] = useState<City[]>([]);
  const [citiesLoading, setCitiesLoading] = useState(false);
  const [city, setCity] = useState("");

  // Search history (localStorage)
  type HistoryItem = { query: string; url: string; ts: number };
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);

  useEffect(() => {
    fetchCountries().then(setCountries).catch(() => setCountries([]));
    try {
      const raw = localStorage.getItem("lc_search_history");
      if (raw) setHistory(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!countryCode) return;
    setStates([]);
    setStateCode("");
    setCities([]);
    setCity("");
    fetchStates(countryCode).then(setStates).catch(() => setStates([]));
  }, [countryCode]);

  useEffect(() => {
    setCities([]);
    setCity("");
    if (!countryCode || !stateCode) return;
    const country = countries.find((c) => c.code === countryCode);
    const state = states.find((s) => s.code === stateCode);
    if (!country || !state) return;
    setCitiesLoading(true);
    fetchCities(country.englishName, state.name)
      .then(setCities)
      .catch(() => setCities([]))
      .finally(() => setCitiesLoading(false));
  }, [countryCode, stateCode, countries, states]);

  const mapsUrl = useMemo(() => {
    const niche = getNiche(nicheId);
    const term = nicheId === "outros" ? customKeyword.trim() : niche?.label ?? "";
    if (!term) return null;
    const country = countries.find((c) => c.code === countryCode);
    const state = states.find((s) => s.code === stateCode);
    const locParts = [city.trim(), state?.name, country?.name].filter(Boolean);
    const query = locParts.length ? `${term} em ${locParts.join(", ")}` : term;
    return `https://www.google.com/maps/search/${encodeURIComponent(query)}`;
  }, [nicheId, customKeyword, countries, countryCode, states, stateCode, city]);

  const currentQuery = useMemo(() => {
    const niche = getNiche(nicheId);
    const term = nicheId === "outros" ? customKeyword.trim() : niche?.label ?? "";
    if (!term) return "";
    const country = countries.find((c) => c.code === countryCode);
    const state = states.find((s) => s.code === stateCode);
    const locParts = [city.trim(), state?.name, country?.name].filter(Boolean);
    return locParts.length ? `${term} em ${locParts.join(", ")}` : term;
  }, [nicheId, customKeyword, countries, countryCode, states, stateCode, city]);

  const pushHistory = () => {
    if (!mapsUrl || !currentQuery) return;
    setHistory((prev) => {
      const filtered = prev.filter((h) => h.query !== currentQuery);
      const next = [{ query: currentQuery, url: mapsUrl, ts: Date.now() }, ...filtered].slice(0, 20);
      try {
        localStorage.setItem("lc_search_history", JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  };

  const clearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem("lc_search_history");
    } catch {
      /* ignore */
    }
  };

  // Top regions derived from history
  const regionStats = useMemo(() => {
    const map = new Map<string, number>();
    history.forEach((h) => {
      const m = h.query.match(/ em (.+)$/);
      const region = m ? m[1] : "(sem localização)";
      map.set(region, (map.get(region) ?? 0) + 1);
    });
    return Array.from(map.entries())
      .map(([region, count]) => ({ region, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [history]);

  // ---------- Contract ----------
  const [contract, setContract] = useState({
    providerName: "",
    providerDoc: "",
    clientName: "",
    clientDoc: "",
    service: "",
    deadlineHours: "72",
    amount: "",
    date: new Date().toISOString().slice(0, 10),
  });
  const [contractCopied, setContractCopied] = useState(false);
  // Logo embutido no cabeçalho de TODAS as páginas do termo gerado.
  // Aceita PNG / JPEG. Persistido em localStorage como dataURL.
  const [contractLogo, setContractLogo] = useState<{
    name: string;
    size: number;
    type: string;
    dataUrl: string;
    width: number;
    height: number;
  } | null>(() => {
    try {
      const raw = localStorage.getItem("lc_contract_logo");
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    try {
      if (contractLogo) localStorage.setItem("lc_contract_logo", JSON.stringify(contractLogo));
      else localStorage.removeItem("lc_contract_logo");
    } catch {
      /* ignore quota */
    }
  }, [contractLogo]);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!/^image\/(png|jpe?g)$/i.test(file.type)) {
      alert("Envie um arquivo PNG ou JPEG.");
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      alert("Logo muito grande. Limite de 4 MB para manter o PDF leve.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result);
      const img = new Image();
      img.onload = () => {
        setContractLogo({
          name: file.name,
          size: file.size,
          type: file.type,
          dataUrl,
          width: img.naturalWidth,
          height: img.naturalHeight,
        });
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const contractText = useMemo(() => {
    const c = contract;
    return `TERMO DE GARANTIA E COMPROMISSO DE ENTREGA

Pelo presente instrumento particular:

PRESTADOR: ${c.providerName || "[seu nome]"}, portador do CPF/CNPJ nº ${c.providerDoc || "[seu CPF/CNPJ]"}.

CONTRATANTE: ${c.clientName || "[nome do cliente]"}, portador do CPF/CNPJ nº ${c.clientDoc || "[CPF/CNPJ do cliente]"}.

OBJETO: Desenvolvimento e entrega de ${c.service || "[descrição do serviço/projeto]"}.

VALOR: R$ ${c.amount || "[valor]"}.

PRAZO DE ENTREGA: ${c.deadlineHours || "72"} horas, contadas a partir da confirmação do pagamento.

CLÁUSULA DE GARANTIA: Caso o PRESTADOR não entregue o objeto contratado dentro do prazo de ${c.deadlineHours || "72"} horas, compromete-se a devolver integralmente o valor pago pelo CONTRATANTE, sem necessidade de justificativa adicional, no prazo máximo de 7 (sete) dias úteis.

Data: ${c.date}

_________________________________
${c.providerName || "Prestador"}

_________________________________
${c.clientName || "Contratante"}`;
  }, [contract]);

  const downloadContractPdf = () => {
    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const margin = 48;
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const maxWidth = pageWidth - margin * 2;

    // Header com logo (em todas as páginas). Altura fixa de ~56pt, largura proporcional, centralizado.
    const headerHeight = contractLogo ? 70 : 0;
    const drawHeader = () => {
      if (!contractLogo) return;
      const maxH = 56;
      const ratio = contractLogo.width / contractLogo.height || 1;
      let h = maxH;
      let w = h * ratio;
      const maxLogoW = pageWidth * 0.4;
      if (w > maxLogoW) {
        w = maxLogoW;
        h = w / ratio;
      }
      const x = (pageWidth - w) / 2;
      const fmt = /png/i.test(contractLogo.type) ? "PNG" : "JPEG";
      try {
        doc.addImage(contractLogo.dataUrl, fmt, x, margin / 2, w, h);
      } catch {
        /* imagem inválida — segue sem logo */
      }
      // linha separadora
      doc.setDrawColor(180);
      doc.line(margin, margin / 2 + h + 6, pageWidth - margin, margin / 2 + h + 6);
    };

    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    const lines = doc.splitTextToSize(contractText, maxWidth);
    const lineHeight = 15;
    const topY = margin + headerHeight;
    let y = topY;
    drawHeader();
    lines.forEach((line: string) => {
      if (y > pageHeight - margin) {
        doc.addPage();
        drawHeader();
        y = topY;
      }
      doc.text(line, margin, y);
      y += lineHeight;
    });
    doc.save(`termo-garantia-${contract.date}.pdf`);
  };

  // ---------- Copy helper ----------
  const copy = async (text: string, setter: (v: boolean) => void) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setter(true);
    setTimeout(() => setter(false), 1800);
  };

  const openExternal = (url: string) => {
    // Always open in a brand-new tab. Never navigate the current/top frame
    // (that would replace the user's session in the preview/published site).
    try {
      const w = window.open(url, "_blank", "noopener,noreferrer");
      if (w) {
        w.opener = null;
        return;
      }
    } catch {
      /* ignore */
    }
    // Popup blocked: render an invisible anchor and click it (most reliable
    // way to bypass popup blockers when triggered from a user gesture).
    try {
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch {
      /* ignore */
    }
  };

  // ---------- Prompt Generator ----------
  const PALETTES = [
    "Escuro com neon verde",
    "Escuro com neon roxo",
    "Claro minimalista (estilo Apple)",
    "Pastel suave",
    "Preto e branco com acento vermelho",
    "Azul corporativo",
    "Gradientes vibrantes (laranja/rosa)",
  ];
  const STYLES = ["Estilo Apple (clean/minimalista)", "Neon quente", "Neon brilhante", "Moderno", "Brutalista", "Glassmorphism"];
  const FONTS = ["Roboto", "Poppins", "Lato", "Montserrat", "Inter", "Space Grotesk"];
  const FEATURES = [
    "Design 100% responsivo",
    "Estados de carregamento (animações visuais)",
    "Modo escuro e claro",
    "Tratamento de erros amigável",
    "Gerenciamento de perfil",
    "Onboarding interativo",
    "Sistema de gamificação",
    "Sistema de notificação",
    "Autenticação (login/cadastro)",
    "Dashboard administrativo",
    "Integração com pagamentos",
  ];

  const [pg, setPg] = useState({
    appName: "",
    inspiration: "",
    audience: "",
    description: "",
    palette: PALETTES[0],
    style: STYLES[0],
    font: FONTS[0],
    extra: "",
  });
  const [pgFeatures, setPgFeatures] = useState<string[]>([
    "Design 100% responsivo",
    "Modo escuro e claro",
  ]);
  const [pgCopied, setPgCopied] = useState(false);
  type PromptTab =
    | "venda-online"
    | "criativo-vsl"
    | "identidade-visual"
    | "script-venda"
    | "trafego-local"
    | "cronograma-social";
  const [promptTab, setPromptTab] = useState<PromptTab>("venda-online");

  // Shared "marketing" inputs reused by the 3 new tabs (script / tráfego / cronograma).
  // We keep them separate from the site/video/image generators so each tab is focused.
  const [mk, setMk] = useState({
    niche: "",
    leadName: "",
    audience: "",
    description: "",
    tone: "Consultivo (curiosidade + dor leve + CTA)",
    region: "",
    palette: "Escuro com neon verde",
    channel: "WhatsApp (1-a-1)",
  });
  const TONE_OPTIONS = [
    "Consultivo (curiosidade + dor leve + CTA)",
    "Consultivo Estratégico (foco em ROI e oportunidade)",
    "Consultivo Educativo (ensina antes de ofertar)",
    "Storytelling (narrativa + identificação + CTA)",
    "Provocativo (quebra de padrão + insight + CTA)",
    "Autoridade (dados + case + CTA seguro)",
  ];
  const [scriptCopied, setScriptCopied] = useState(false);
  const [trafficCopied, setTrafficCopied] = useState(false);
  const [socialCopied, setSocialCopied] = useState(false);

  const toggleFeature = (f: string) =>
    setPgFeatures((prev) => (prev.includes(f) ? prev.filter((x) => x !== f) : [...prev, f]));

  // ---------- Video Prompt Generator ----------
  const VIDEO_MODELS = [
    { id: "veo3", label: "Google Veo 3 (hiper-realista)", paid: true },
    { id: "sora", label: "OpenAI Sora", paid: true },
    { id: "runway", label: "Runway Gen-3 Alpha", paid: true },
    { id: "kling", label: "Kling AI 1.6", paid: true },
    { id: "luma", label: "Luma Dream Machine", paid: false },
    { id: "pika", label: "Pika Labs 2.0", paid: false },
    { id: "haiper", label: "Haiper AI", paid: false },
  ];
  const VIDEO_STYLES = [
    "Hiper-realista (cinematográfico)",
    "Cinematográfico (filme 35mm)",
    "Anime/Estilo Studio Ghibli",
    "Cartoon 3D (Pixar)",
    "Stop motion",
    "Documentário",
    "Vlog estilo YouTube",
    "Comercial publicitário",
    "Slow motion artístico",
    "Time-lapse",
  ];
  const VIDEO_CAMERA = [
    "Estática", "Travelling lateral", "Dolly in (aproximação)", "Dolly out (afastamento)",
    "Crane shot (de cima)", "Drone aéreo", "POV (primeira pessoa)", "Handheld (mão livre)",
    "Tracking shot (segue o sujeito)",
  ];
  const VIDEO_LIGHTING = [
    "Golden hour (luz dourada)", "Blue hour", "Luz natural difusa", "Estúdio com softbox",
    "Neon noturno (cyberpunk)", "Contraluz dramático", "Luz baixa moody",
  ];
  const VIDEO_DURATION = ["3 segundos", "5 segundos", "10 segundos", "15 segundos", "30 segundos"];
  const VIDEO_RATIOS = ["16:9 (paisagem)", "9:16 (vertical/Reels)", "1:1 (quadrado)", "21:9 (cinema)"];
  const VIDEO_EDITS = [
    "Corte rápido (alto ritmo)",
    "Transições suaves (dissolve)",
    "Match cut",
    "Whip pan",
    "Color grading cinematográfico",
    "Slow-motion em momentos chave",
    "Texto/Lower thirds animados",
    "Trilha sonora épica",
    "SFX (sound design)",
  ];

  const [vp, setVp] = useState({
    model: VIDEO_MODELS[0].id,
    scene: "",
    subject: "",
    action: "",
    style: VIDEO_STYLES[0],
    camera: VIDEO_CAMERA[0],
    lighting: VIDEO_LIGHTING[0],
    duration: VIDEO_DURATION[1],
    ratio: VIDEO_RATIOS[0],
    extra: "",
  });
  const [vpEdits, setVpEdits] = useState<string[]>(["Color grading cinematográfico"]);
  const [vpCopied, setVpCopied] = useState(false);

  const toggleVpEdit = (e: string) =>
    setVpEdits((prev) => (prev.includes(e) ? prev.filter((x) => x !== e) : [...prev, e]));

  const generatedVideoPrompt = useMemo(() => {
    const model = VIDEO_MODELS.find((m) => m.id === vp.model);
    return `🎬 PROMPT DE VÍDEO — ${model?.label ?? ""}${model?.paid ? " (requer licença paga)" : ""}

CENA: ${vp.scene || "[descreva o cenário/ambiente]"}
SUJEITO: ${vp.subject || "[quem ou o que é o foco]"}
AÇÃO: ${vp.action || "[o que está acontecendo]"}

🎨 ESTILO VISUAL: ${vp.style}
📷 CÂMERA: ${vp.camera}
💡 ILUMINAÇÃO: ${vp.lighting}
⏱ DURAÇÃO: ${vp.duration}
📐 PROPORÇÃO: ${vp.ratio}

✂ EDIÇÃO / PÓS-PRODUÇÃO:
${vpEdits.length ? vpEdits.map((e) => `- ${e}`).join("\n") : "- (nenhuma)"}

📌 DETALHES EXTRA:
${vp.extra || "(nenhum)"}

Entregue um vídeo coeso, com qualidade profissional, atenção a detalhes de iluminação, composição e movimento de câmera.`;
  }, [vp, vpEdits]);

  // ---------- Image / Logo / Banner Prompt Generator ----------
  const IMAGE_TYPES = [
    "Logo", "Banner para redes sociais", "Banner para site (hero)", "Capa de perfil",
    "Thumbnail de YouTube", "Post de Instagram", "Stories", "Flyer/Folder", "Cartão de visita", "Ilustração geral",
  ];
  const IMAGE_STYLES = [
    "Minimalista (flat)", "Realista fotográfico", "3D render moderno", "Aquarela",
    "Vetorial colorido", "Pixel art", "Linha (line art)", "Cyberpunk neon",
    "Vintage/Retrô", "Brutalista", "Glassmorphism", "Cartoon",
  ];
  const IMAGE_PALETTES = [
    "Cores quentes (laranja/vermelho)",
    "Cores frias (azul/roxo)",
    "Tons pastéis suaves",
    "Preto e branco com 1 acento",
    "Gradiente vibrante",
    "Tons terrosos/naturais",
    "Neon escuro",
    "Monocromático azul corporativo",
  ];
  const IMAGE_MOODS = [
    "Profissional/corporativo", "Divertido/jovem", "Luxuoso/premium",
    "Tecnológico/futurista", "Acolhedor/familiar", "Místico/artístico",
    "Energético/esportivo", "Calmo/relaxante",
  ];
  const IMAGE_COMPOSITIONS = [
    "Centralizado simétrico", "Regra dos terços", "Diagonal dinâmica",
    "Close-up", "Wide shot (panorâmico)", "Composição minimalista com muito espaço",
  ];
  const IMAGE_RATIOS = ["1:1 (Instagram post)", "9:16 (Stories/Reels)", "16:9 (banner site)", "4:5 (post vertical)", "Logo quadrado transparente"];

  const [ip, setIp] = useState({
    type: IMAGE_TYPES[0],
    subject: "",
    brand: "",
    style: IMAGE_STYLES[0],
    palette: IMAGE_PALETTES[0],
    mood: IMAGE_MOODS[0],
    composition: IMAGE_COMPOSITIONS[0],
    ratio: IMAGE_RATIOS[0],
    text: "",
    extra: "",
  });
  const [ipCopied, setIpCopied] = useState(false);

  const generatedImagePrompt = useMemo(() => {
    return `🖼 PROMPT DE IMAGEM — ${ip.type}

ASSUNTO/CONCEITO: ${ip.subject || "[descreva o que deve aparecer]"}
${ip.brand ? `MARCA/EMPRESA: ${ip.brand}` : ""}

🎨 ESTILO VISUAL: ${ip.style}
🌈 PALETA DE CORES: ${ip.palette}
💭 MOOD/SENSAÇÃO: ${ip.mood}
🧭 COMPOSIÇÃO: ${ip.composition}
📐 PROPORÇÃO: ${ip.ratio}

${ip.text ? `📝 TEXTO INCLUÍDO NA ARTE: "${ip.text}"` : "📝 SEM TEXTO NA ARTE"}

📌 DETALHES EXTRA:
${ip.extra || "(nenhum)"}

Entregue uma imagem com alta qualidade visual, hierarquia clara, atenção a tipografia (se aplicável) e coerência com a identidade descrita.`;
  }, [ip]);


  const generatedPrompt = useMemo(() => {
    return `Crie um aplicativo web chamado "${pg.appName || "[nome do app]"}".

🎯 OBJETIVO / DESCRIÇÃO DO PROJETO:
${pg.description || "[descreva o que o app faz]"}

👥 PÚBLICO-ALVO:
${pg.audience || "[descreva o público-alvo]"}

✨ INSPIRAÇÃO:
${pg.inspiration || "[apps/sites de referência]"}

🎨 IDENTIDADE VISUAL:
- Estilo: ${pg.style}
- Paleta de cores: ${pg.palette}
- Fonte principal: ${pg.font}

⚙️ FUNCIONALIDADES OBRIGATÓRIAS:
${pgFeatures.length ? pgFeatures.map((f) => `- ${f}`).join("\n") : "- (nenhuma selecionada)"}

📌 REQUISITOS ESPECIAIS:
${pg.extra || "(nenhum)"}

Entregue uma interface polida, com hierarquia visual clara, microinterações suaves e código limpo e organizado em componentes.`;
  }, [pg, pgFeatures]);

  return (
    <AppShell>
      <main className="relative z-10 mx-auto max-w-5xl space-y-8 px-4 py-8">
        {/* Saudação personalizada + contador de leads */}
        <section className="relative overflow-hidden rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card to-card p-5 animate-fade-in">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
                {personalization.greeting}
              </h1>
              <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{personalization.subtitle}</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              {(() => {
                const limit = PLAN_LIMITS[gate.plan].leadsPerDay;
                const limitLabel = limit === Infinity ? "∞" : limit;
                const blocked = !gate.canUseSystem();
                return (
                  <div
                    className={`rounded-xl border px-4 py-2 text-sm font-semibold ${
                      blocked
                        ? "border-destructive/50 bg-destructive/10 text-destructive"
                        : "border-primary/40 bg-primary/10 text-primary"
                    }`}
                  >
                    {gate.leadsUsedToday} / {limitLabel} leads usados hoje
                  </div>
                );
              })()}
              <span className="rounded-md border border-border bg-background px-3 py-1.5 text-xs uppercase tracking-widest text-muted-foreground">
                Plano {gate.plan}
              </span>
              {gate.isAdmin && (
                <Link
                  to="/admin"
                  className="rounded-md border border-primary/40 bg-primary/10 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-primary hover:bg-primary/20"
                >
                  👑 Admin
                </Link>
              )}
            </div>
          </div>

          {/* Personalized nudge / daily target */}
          {personalization.nudge && (
            <div className="mt-3 flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 px-4 py-2.5 text-sm text-primary/90">
              <Lightbulb className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
              <span>{personalization.nudge}</span>
            </div>
          )}

          {/* Beginner tips - only shown for nunca/ja_tentei */}
          {personalization.showTips && personalization.experience === "nunca" && (
            <div className="mt-3 rounded-lg border border-cyan-500/20 bg-cyan-500/5 px-4 py-2.5 text-sm text-cyan-400/90">
              💡 <strong>Dica de iniciante:</strong> Comece buscando estabelecimentos na sua cidade. Foque nos que NÃO têm site — esses são as maiores oportunidades.
            </div>
          )}

          {!gate.canUseSystem() && (
            <div className="mt-4 rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
              🚫 Você atingiu o limite de hoje. Faça upgrade para continuar gerando oportunidades.
            </div>
          )}
        </section>

        {/* SEARCH */}
        <section className="rounded-lg border border-border bg-card p-5">
          <div className="mb-4 flex items-center gap-2">
            <Search className="h-4 w-4 text-primary" />
            <h2 className="text-sm font-semibold uppercase tracking-wider">
              Buscar estabelecimentos
            </h2>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Nicho</label>
              <select
                value={nicheId}
                onChange={(e) => setNicheId(e.target.value)}
                className="input"
              >
                {NICHES.map((n) => (
                  <option key={n.id} value={n.id}>
                    {n.label}
                  </option>
                ))}
              </select>
              {nicheId === "outros" && (
                <input
                  type="text"
                  placeholder="Digite (ex: pet shop, advogado)"
                  value={customKeyword}
                  onChange={(e) => setCustomKeyword(e.target.value)}
                  className="input mt-2"
                />
              )}
            </div>

            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">País</label>
              <select
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                className="input"
              >
                {countries.length === 0 && <option value="BR">Brasil</option>}
                {countries.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Estado</label>
              <select
                value={stateCode}
                onChange={(e) => setStateCode(e.target.value)}
                disabled={states.length === 0}
                className="input disabled:opacity-50"
              >
                <option value="">
                  {states.length === 0 ? "Carregando..." : "Selecione o estado"}
                </option>
                {states.map((s) => (
                  <option key={s.code} value={s.code}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">
                Cidade (opcional)
              </label>
              {stateCode && cities.length > 0 ? (
                <>
                  <select
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="input"
                  >
                    <option value="">Todas as cidades do estado</option>
                    {cities.map((c) => (
                      <option key={c.name} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                  <p className="text-[10px] text-muted-foreground">
                    {cities.length} cidades · ou digite abaixo
                  </p>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Digitar cidade manualmente"
                    className="input"
                  />
                </>
              ) : (
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder={
                    citiesLoading
                      ? "Carregando cidades..."
                      : stateCode
                        ? "Ex: São Paulo"
                        : "Selecione um estado primeiro (opcional)"
                  }
                  className="input"
                />
              )}
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            {mapsUrl ? (
              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => {
                  e.preventDefault();
                  pushHistory();
                  openExternal(mapsUrl);
                }}
                className="inline-flex items-center gap-2 rounded bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90"
              >
                <Search className="h-4 w-4" /> Buscar no Google Maps
              </a>
            ) : (
              <button
                disabled
                className="inline-flex cursor-not-allowed items-center gap-2 rounded bg-muted px-4 py-2 text-sm font-semibold text-muted-foreground"
              >
                <Search className="h-4 w-4" /> Preencha o nicho
              </button>
            )}
            {mapsUrl && (
              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => {
                  e.preventDefault();
                  openExternal(mapsUrl);
                }}
                className="inline-flex items-center gap-2 rounded border border-border bg-background px-4 py-2 text-sm text-foreground hover:border-primary"
              >
                <ExternalLink className="h-4 w-4" /> Abrir resultado novamente
              </a>
            )}
            {mapsUrl && (
              <button
                onClick={() => copy(mapsUrl, () => {})}
                className="inline-flex items-center gap-2 rounded border border-border bg-background px-3 py-2 text-xs text-muted-foreground hover:border-primary"
                title={mapsUrl}
              >
                <Copy className="h-3 w-3" /> Copiar link
              </button>
            )}
          </div>

          {/* Search history + Stats — colapsável */}
          <div className="mt-6 border-t border-border pt-4">
            <button
              onClick={() => setHistoryOpen((v) => !v)}
              className="mb-3 inline-flex items-center gap-2 rounded border border-border bg-background px-3 py-1.5 text-xs font-semibold text-foreground hover:border-primary"
            >
              {historyOpen ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
              {historyOpen ? "Ocultar" : "Mostrar"} histórico e estatísticas ({history.length})
            </button>
          </div>
          {historyOpen && (
          <div className="mt-2 grid gap-4 md:grid-cols-2">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <History className="h-3.5 w-3.5 text-primary" />
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-foreground">
                    Histórico de buscas ({history.length})
                  </h3>
                </div>
                {history.length > 0 && (
                  <button
                    onClick={clearHistory}
                    className="inline-flex items-center gap-1 rounded border border-border bg-background px-2 py-1 text-[10px] text-muted-foreground hover:border-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-3 w-3" /> Limpar
                  </button>
                )}
              </div>
              {history.length === 0 ? (
                <p className="rounded border border-dashed border-border bg-background/50 px-3 py-4 text-center text-xs text-muted-foreground">
                  Nenhuma busca ainda. Suas pesquisas aparecerão aqui automaticamente.
                </p>
              ) : (
                <ul className="max-h-48 space-y-1 overflow-auto">
                  {history.map((h) => (
                    <li
                      key={h.ts}
                      className="flex items-center justify-between gap-2 rounded border border-border bg-background px-2 py-1.5 text-xs"
                    >
                      <span className="truncate text-foreground" title={h.query}>
                        {h.query}
                      </span>
                      <span className="flex shrink-0 items-center gap-1">
                        <span className="text-[10px] text-muted-foreground">
                          {new Date(h.ts).toLocaleDateString("pt-BR")}
                        </span>
                        <a
                          href={h.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => {
                            e.preventDefault();
                            openExternal(h.url);
                          }}
                          className="inline-flex items-center gap-1 rounded border border-border px-2 py-0.5 text-[10px] text-foreground hover:border-primary"
                        >
                          <ExternalLink className="h-3 w-3" /> Abrir
                        </a>
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div>
              <div className="mb-2 flex items-center gap-2">
                <Flame className="h-3.5 w-3.5 text-primary" />
                <h3 className="text-xs font-semibold uppercase tracking-wider text-foreground">
                  Top regiões pesquisadas
                </h3>
              </div>
              {regionStats.length === 0 ? (
                <p className="rounded border border-dashed border-border bg-background/50 px-3 py-4 text-center text-xs text-muted-foreground">
                  Conforme você pesquisa, suas regiões mais minadas aparecem aqui.
                </p>
              ) : (
                <ul className="space-y-1">
                  {regionStats.map((r) => (
                    <li
                      key={r.region}
                      className="flex items-center justify-between rounded border border-border bg-background px-2 py-1.5 text-xs"
                    >
                      <span className="truncate text-foreground">{r.region}</span>
                      <span className="rounded bg-primary/15 px-2 py-0.5 text-[10px] font-bold text-primary">
                        {r.count}× busca{r.count > 1 ? "s" : ""}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
          )}
        </section>

        {/* LEAD WORKBENCH */}
        <LeadWorkbench openExternal={openExternal} />

        {/* CONTRACT */}
        <section className="rounded-lg border border-border bg-card p-5">
          <div className="mb-4 flex items-center gap-2">
            <FileText className="h-4 w-4 text-primary" />
            <h2 className="text-sm font-semibold uppercase tracking-wider">
              Termo de garantia
            </h2>
          </div>

          <div className="grid gap-2 md:grid-cols-2">
            <Field label="Seu nome">
              <input className="input" value={contract.providerName}
                onChange={(e) => setContract({ ...contract, providerName: e.target.value })} />
            </Field>
            <Field label="Seu CPF/CNPJ">
              <input className="input" value={contract.providerDoc}
                onChange={(e) => setContract({ ...contract, providerDoc: e.target.value })} />
            </Field>
            <Field label="Nome do cliente">
              <input className="input" value={contract.clientName}
                onChange={(e) => setContract({ ...contract, clientName: e.target.value })} />
            </Field>
            <Field label="CPF/CNPJ do cliente">
              <input className="input" value={contract.clientDoc}
                onChange={(e) => setContract({ ...contract, clientDoc: e.target.value })} />
            </Field>
            <div className="md:col-span-2">
              <Field label="Serviço / Projeto">
                <input className="input" value={contract.service}
                  onChange={(e) => setContract({ ...contract, service: e.target.value })} />
              </Field>
            </div>
            <Field label="Prazo (horas)">
              <input type="number" className="input" value={contract.deadlineHours}
                onChange={(e) => setContract({ ...contract, deadlineHours: e.target.value })} />
            </Field>
            <Field label="Valor (R$)">
              <input className="input" value={contract.amount}
                onChange={(e) => setContract({ ...contract, amount: e.target.value })} />
            </Field>
          </div>

          <pre className="mt-4 max-h-64 overflow-auto whitespace-pre-wrap rounded border border-border bg-background p-3 text-xs text-foreground">
            {contractText}
          </pre>

          <div className="mt-3 flex flex-wrap gap-2">
            <button
              onClick={() => copy(contractText, setContractCopied)}
              className="inline-flex items-center gap-2 rounded border border-border bg-background px-4 py-2 text-sm font-semibold text-foreground hover:border-primary"
            >
              {contractCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              {contractCopied ? "Copiado!" : "Copiar termo"}
            </button>
            <button
              onClick={downloadContractPdf}
              className="inline-flex items-center gap-2 rounded bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90"
            >
              <Download className="h-4 w-4" /> Baixar PDF
            </button>
            <label
              className="inline-flex cursor-pointer items-center gap-2 rounded border border-primary/50 bg-primary/10 px-4 py-2 text-sm font-semibold text-primary hover:bg-primary/20"
              title="Envie um PNG ou JPEG do seu logo. Ele será embutido no cabeçalho de todas as páginas do PDF gerado."
            >
              <Upload className="h-4 w-4" />
              {contractLogo ? "Trocar logo" : "Anexar logo (PNG/JPEG)"}
              <input
                type="file"
                accept="image/png,image/jpeg"
                onChange={handleLogoUpload}
                className="hidden"
              />
            </label>
          </div>

          {contractLogo && (
            <div className="mt-3 flex items-center justify-between gap-3 rounded border border-primary/30 bg-primary/5 px-3 py-2 text-xs">
              <div className="flex min-w-0 items-center gap-3">
                <img
                  src={contractLogo.dataUrl}
                  alt="Pré-visualização do logo"
                  className="h-10 w-10 shrink-0 rounded border border-border bg-background object-contain p-0.5"
                />
                <div className="flex min-w-0 flex-col">
                  <span className="truncate font-medium text-foreground" title={contractLogo.name}>
                    {contractLogo.name}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    {contractLogo.width}×{contractLogo.height}px · {(contractLogo.size / 1024).toFixed(1)} KB · embutido em todas as páginas do PDF
                  </span>
                </div>
              </div>
              <button
                onClick={() => setContractLogo(null)}
                className="inline-flex shrink-0 items-center gap-1 rounded border border-border bg-background px-2 py-1 text-[10px] text-muted-foreground hover:border-destructive hover:text-destructive"
                title="Remover logo"
              >
                <X className="h-3 w-3" /> Remover
              </button>
            </div>
          )}
        </section>

        {/* PROMPT GENERATORS (unified, tabs) — gated por plano */}
        <section className="relative rounded-lg border border-border bg-card p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <h2 className="text-sm font-semibold uppercase tracking-wider">
                Gerador de prompts
              </h2>
              {!gate.checkFeature("gerador_prompts") && (
                <span className="ml-2 inline-flex items-center gap-1 rounded-md border border-primary/40 bg-primary/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-primary">
                  <Lock className="h-3 w-3" /> PRO
                </span>
              )}
            </div>
            <div className="-mx-1 flex max-w-full gap-1 overflow-x-auto rounded-md border border-border bg-background p-1 sm:flex-wrap sm:overflow-visible">
              {([
                { id: "venda-online", label: "Venda Online", Icon: Globe, feature: "venda_online" as const },
                { id: "criativo-vsl", label: "Criativo VSL", Icon: Play, feature: "gerador_prompts" as const },
                { id: "identidade-visual", label: "Identidade Visual", Icon: ImageIcon, feature: "gerador_prompts" as const },
                { id: "script-venda", label: "Script de Venda", Icon: MessageSquare, feature: "scripts" as const },
                { id: "trafego-local", label: "Tráfego Local", Icon: Megaphone, feature: "prompts_avancados" as const },
                { id: "cronograma-social", label: "Cronograma Social", Icon: CalendarDays, feature: "cronograma" as const },
              ]).map((t) => {
                const active = promptTab === t.id;
                const allowed = gate.checkFeature(t.feature);
                return (
                  <button
                    key={t.id}
                    onClick={() => setPromptTab(t.id as PromptTab)}
                    className={`inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded px-3 py-1.5 text-xs font-semibold transition ${
                      active
                        ? "bg-primary text-primary-foreground shadow-[0_0_10px_hsl(var(--primary)/0.5)]"
                        : "text-muted-foreground hover:text-foreground"
                    } ${!allowed ? "opacity-60" : ""}`}
                  >
                    <t.Icon className="h-3.5 w-3.5" />
                    {t.label}
                    {!allowed && <Lock className="ml-0.5 h-3 w-3" />}
                  </button>
                );
              })}
            </div>
          </div>

          {promptTab === "venda-online" && (
            !gate.checkFeature("venda_online") ? (
              <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 p-8 text-center animate-fade-in">
                <Lock className="mx-auto mb-3 h-8 w-8 text-primary" />
                <h3 className="text-lg font-bold">Venda Online é PRO</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Gere prompts de alta conversão para Vendas Online sem limites.
                </p>
                <Link to="/pricing" className="mt-4 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">
                  Fazer upgrade para PRO
                </Link>
              </div>
            ) :
          <>

          {/* Bloco: Projeto */}
          <h3 className="mb-2 text-xs font-bold uppercase text-muted-foreground">📝 Projeto</h3>
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Nome do app">
              <input className="input" value={pg.appName}
                onChange={(e) => setPg({ ...pg, appName: e.target.value })} />
            </Field>
            <Field label="Inspiração (referências)">
              <input className="input" placeholder="Ex: Notion, Linear, Apple"
                value={pg.inspiration}
                onChange={(e) => setPg({ ...pg, inspiration: e.target.value })} />
            </Field>
            <div className="md:col-span-2">
              <Field label="Descrição do projeto (o que ele faz)">
                <textarea className="input min-h-[80px]" value={pg.description}
                  onChange={(e) => setPg({ ...pg, description: e.target.value })} />
              </Field>
            </div>
            <div className="md:col-span-2">
              <Field label="Público-alvo">
                <textarea className="input min-h-[60px]"
                  placeholder="Ex: pequenos empreendedores entre 25-40 anos..."
                  value={pg.audience}
                  onChange={(e) => setPg({ ...pg, audience: e.target.value })} />
              </Field>
            </div>
          </div>

          {/* Bloco: Visual */}
          <h3 className="mb-2 mt-5 text-xs font-bold uppercase text-muted-foreground">🎨 Visual</h3>
          <div className="grid gap-3 md:grid-cols-3">
            <Field label="Paleta de cores">
              <select className="input" value={pg.palette}
                onChange={(e) => setPg({ ...pg, palette: e.target.value })}>
                {PALETTES.map((p) => <option key={p}>{p}</option>)}
              </select>
            </Field>
            <Field label="Estilo">
              <select className="input" value={pg.style}
                onChange={(e) => setPg({ ...pg, style: e.target.value })}>
                {STYLES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Fonte">
              <select className="input" value={pg.font}
                onChange={(e) => setPg({ ...pg, font: e.target.value })}>
                {FONTS.map((f) => <option key={f}>{f}</option>)}
              </select>
            </Field>
          </div>

          {/* Bloco: Funcionalidades */}
          <h3 className="mb-2 mt-5 text-xs font-bold uppercase text-muted-foreground">⚙️ Funcionalidades</h3>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3">
            {FEATURES.map((f) => {
              const active = pgFeatures.includes(f);
              return (
                <button
                  key={f}
                  type="button"
                  onClick={() => toggleFeature(f)}
                  className={`rounded border px-3 py-2 text-left text-xs font-medium transition ${
                    active
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-background text-foreground hover:border-primary"
                  }`}
                >
                  {active ? "✓ " : ""}{f}
                </button>
              );
            })}
          </div>

          {/* Bloco: Finalização */}
          <h3 className="mb-2 mt-5 text-xs font-bold uppercase text-muted-foreground">🏁 Finalização</h3>
          <Field label="Requisitos especiais (opcional)">
            <textarea className="input min-h-[70px]"
              placeholder="Ex: integrar com Stripe, suportar PT/EN, ter painel admin..."
              value={pg.extra}
              onChange={(e) => setPg({ ...pg, extra: e.target.value })} />
          </Field>

          <pre className="mt-4 max-h-80 overflow-auto whitespace-pre-wrap rounded border border-border bg-background p-3 text-xs text-foreground">
            {generatedPrompt}
          </pre>

          <button
            onClick={() => {
              const today = new Date().toISOString().slice(0, 10);
              const key = `lc_venda_online_count_${today}`;
              const count = parseInt(localStorage.getItem(key) || "0", 10);
              
              if (!gate.isAdmin && gate.plan === "basic" && count >= 5) {
                gate.blockWithUpgrade("venda_online");
                return;
              }
              
              copy(generatedPrompt, setPgCopied);
              if (!gate.isAdmin && gate.plan === "basic") {
                localStorage.setItem(key, (count + 1).toString());
              }
            }}
            className="mt-3 inline-flex items-center gap-2 rounded bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90"
          >
            {pgCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {pgCopied ? "Copiado!" : "Copiar prompt"}
          </button>
          </>
          )}

          {promptTab === "criativo-vsl" && (
            !gate.checkFeature("gerador_prompts") ? (
              <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 p-8 text-center animate-fade-in">
                <Lock className="mx-auto mb-3 h-8 w-8 text-primary" />
                <h3 className="text-lg font-bold">Criativo VSL é PRO</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  No plano Basic, você tem acesso ao Venda Online. Para acessar prompts de Criativos para Vídeo de Alta Conversão, atualize para PRO e libere recursos avançados.
                </p>
                <Link to="/pricing" className="mt-4 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">
                  Fazer upgrade para PRO
                </Link>
              </div>
            ) :
          <>
          <p className="mb-4 text-[11px] text-muted-foreground">
            Crie prompts profissionais para Veo 3, Sora, Runway, Kling e outras IAs de vídeo.
            Modelos marcados com 💎 exigem licença paga.
          </p>

          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Modelo de IA">
              <select className="input" value={vp.model} onChange={(e) => setVp({ ...vp, model: e.target.value })}>
                {VIDEO_MODELS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.paid ? "💎 " : "🆓 "}{m.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Estilo visual">
              <select className="input" value={vp.style} onChange={(e) => setVp({ ...vp, style: e.target.value })}>
                {VIDEO_STYLES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <div className="md:col-span-2">
              <Field label="Cena / Cenário">
                <textarea className="input min-h-[60px]"
                  placeholder="Ex: cozinha industrial moderna, vapor saindo das panelas, luz quente entrando pelas janelas"
                  value={vp.scene} onChange={(e) => setVp({ ...vp, scene: e.target.value })} />
              </Field>
            </div>
            <Field label="Sujeito principal">
              <input className="input" placeholder="Ex: um chef em ação"
                value={vp.subject} onChange={(e) => setVp({ ...vp, subject: e.target.value })} />
            </Field>
            <Field label="Ação">
              <input className="input" placeholder="Ex: flambando um prato com fogo intenso"
                value={vp.action} onChange={(e) => setVp({ ...vp, action: e.target.value })} />
            </Field>
          </div>

          <h3 className="mb-2 mt-5 text-xs font-bold uppercase text-muted-foreground">📷 Câmera & Luz</h3>
          <div className="grid gap-3 md:grid-cols-3">
            <Field label="Movimento de câmera">
              <select className="input" value={vp.camera} onChange={(e) => setVp({ ...vp, camera: e.target.value })}>
                {VIDEO_CAMERA.map((c) => <option key={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Iluminação">
              <select className="input" value={vp.lighting} onChange={(e) => setVp({ ...vp, lighting: e.target.value })}>
                {VIDEO_LIGHTING.map((l) => <option key={l}>{l}</option>)}
              </select>
            </Field>
            <Field label="Duração">
              <select className="input" value={vp.duration} onChange={(e) => setVp({ ...vp, duration: e.target.value })}>
                {VIDEO_DURATION.map((d) => <option key={d}>{d}</option>)}
              </select>
            </Field>
            <Field label="Proporção">
              <select className="input" value={vp.ratio} onChange={(e) => setVp({ ...vp, ratio: e.target.value })}>
                {VIDEO_RATIOS.map((r) => <option key={r}>{r}</option>)}
              </select>
            </Field>
          </div>

          <h3 className="mb-2 mt-5 text-xs font-bold uppercase text-muted-foreground">✂ Edição / Pós-produção</h3>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3">
            {VIDEO_EDITS.map((f) => {
              const active = vpEdits.includes(f);
              return (
                <button key={f} type="button" onClick={() => toggleVpEdit(f)}
                  className={`rounded border px-3 py-2 text-left text-xs font-medium transition ${
                    active ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-background text-foreground hover:border-primary"
                  }`}>
                  {active ? "✓ " : ""}{f}
                </button>
              );
            })}
          </div>

          <h3 className="mb-2 mt-5 text-xs font-bold uppercase text-muted-foreground">🏁 Detalhes extra</h3>
          <Field label="Requisitos especiais (opcional)">
            <textarea className="input min-h-[60px]"
              placeholder="Ex: incluir logo da marca no canto inferior direito, sem rostos identificáveis..."
              value={vp.extra} onChange={(e) => setVp({ ...vp, extra: e.target.value })} />
          </Field>

          <pre className="mt-4 max-h-80 overflow-auto whitespace-pre-wrap rounded border border-border bg-background p-3 text-xs text-foreground">
            {generatedVideoPrompt}
          </pre>

          <button onClick={() => copy(generatedVideoPrompt, setVpCopied)}
            className="mt-3 inline-flex items-center gap-2 rounded bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">
            {vpCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {vpCopied ? "Copiado!" : "Copiar prompt de vídeo"}
          </button>
          </>
          )}

          {promptTab === "identidade-visual" && (
            !gate.checkFeature("gerador_prompts") ? (
              <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 p-8 text-center animate-fade-in">
                <Lock className="mx-auto mb-3 h-8 w-8 text-primary" />
                <h3 className="text-lg font-bold">Identidade Visual é PRO</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Gere prompts profissionais para Midjourney, DALL·E e Ideogram com o plano PRO. Eleva o nível visual das suas propostas!
                </p>
                <Link to="/pricing" className="mt-4 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">
                  Fazer upgrade para PRO
                </Link>
              </div>
            ) :
          <>
          <p className="mb-4 text-[11px] text-muted-foreground">
            Personalize o prompt completo para Midjourney, DALL·E, Stable Diffusion, Ideogram e similares.
          </p>

          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Tipo de arte">
              <select className="input" value={ip.type} onChange={(e) => setIp({ ...ip, type: e.target.value })}>
                {IMAGE_TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </Field>
            <Field label="Marca/Empresa (opcional)">
              <input className="input" placeholder="Ex: Pizzaria Bella Napoli"
                value={ip.brand} onChange={(e) => setIp({ ...ip, brand: e.target.value })} />
            </Field>
            <div className="md:col-span-2">
              <Field label="Assunto / conceito da imagem">
                <textarea className="input min-h-[60px]"
                  placeholder="Ex: pizza artesanal vista de cima com ingredientes frescos ao redor"
                  value={ip.subject} onChange={(e) => setIp({ ...ip, subject: e.target.value })} />
              </Field>
            </div>
          </div>

          <h3 className="mb-2 mt-5 text-xs font-bold uppercase text-muted-foreground">🎨 Estética</h3>
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Estilo visual">
              <select className="input" value={ip.style} onChange={(e) => setIp({ ...ip, style: e.target.value })}>
                {IMAGE_STYLES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Paleta de cores">
              <select className="input" value={ip.palette} onChange={(e) => setIp({ ...ip, palette: e.target.value })}>
                {IMAGE_PALETTES.map((p) => <option key={p}>{p}</option>)}
              </select>
            </Field>
            <Field label="Mood / Sensação">
              <select className="input" value={ip.mood} onChange={(e) => setIp({ ...ip, mood: e.target.value })}>
                {IMAGE_MOODS.map((m) => <option key={m}>{m}</option>)}
              </select>
            </Field>
            <Field label="Composição">
              <select className="input" value={ip.composition} onChange={(e) => setIp({ ...ip, composition: e.target.value })}>
                {IMAGE_COMPOSITIONS.map((c) => <option key={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Proporção / formato">
              <select className="input" value={ip.ratio} onChange={(e) => setIp({ ...ip, ratio: e.target.value })}>
                {IMAGE_RATIOS.map((r) => <option key={r}>{r}</option>)}
              </select>
            </Field>
            <Field label="Texto na arte (opcional)">
              <input className="input" placeholder='Ex: "Promoção 50% off"'
                value={ip.text} onChange={(e) => setIp({ ...ip, text: e.target.value })} />
            </Field>
          </div>

          <h3 className="mb-2 mt-5 text-xs font-bold uppercase text-muted-foreground">🏁 Detalhes extra</h3>
          <Field label="Requisitos especiais (opcional)">
            <textarea className="input min-h-[60px]"
              placeholder="Ex: fundo transparente para uso em embalagem, sem pessoas, evitar marcas registradas..."
              value={ip.extra} onChange={(e) => setIp({ ...ip, extra: e.target.value })} />
          </Field>

          <pre className="mt-4 max-h-80 overflow-auto whitespace-pre-wrap rounded border border-border bg-background p-3 text-xs text-foreground">
            {generatedImagePrompt}
          </pre>

          <button onClick={() => copy(generatedImagePrompt, setIpCopied)}
            className="mt-3 inline-flex items-center gap-2 rounded bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">
            {ipCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {ipCopied ? "Copiado!" : "Copiar prompt de imagem"}
          </button>
          </>
          )}

          {promptTab === "script-venda" && (
            !gate.checkFeature("scripts") ? (
              <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 p-8 text-center animate-fade-in">
                <Lock className="mx-auto mb-3 h-8 w-8 text-primary" />
                <h3 className="text-lg font-bold">Script de Vendas é PRO</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Acesse scripts validados com método AIDA para WhatsApp, Email e Ligações. Economize horas de copywriting.
                </p>
                <Link to="/pricing" className="mt-4 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">
                  Fazer upgrade para PRO
                </Link>
              </div>
            ) :
            <MarketingTab
              kind="script"
              mk={mk}
              setMk={setMk}
              tones={TONE_OPTIONS}
              copy={copy}
              copied={scriptCopied}
              setCopied={setScriptCopied}
            />
          )}

          {promptTab === "trafego-local" && (
            !gate.checkFeature("prompts_avancados") ? (
              <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 p-8 text-center animate-fade-in">
                <Lock className="mx-auto mb-3 h-8 w-8 text-primary" />
                <h3 className="text-lg font-bold">Tráfego Local é PRO</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Anúncios prontas para Meta Ads, Google Ads e TikTok Ads para empresas locais. O plano PRO desbloqueia isso e muito mais!
                </p>
                <Link to="/pricing" className="mt-4 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">
                  Fazer upgrade para PRO
                </Link>
              </div>
            ) :
            <MarketingTab
              kind="traffic"
              mk={mk}
              setMk={setMk}
              tones={TONE_OPTIONS}
              copy={copy}
              copied={trafficCopied}
              setCopied={setTrafficCopied}
            />
          )}

          {promptTab === "cronograma-social" && (
            !gate.checkFeature("cronograma") ? (
              <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 p-8 text-center animate-fade-in">
                <Lock className="mx-auto mb-3 h-8 w-8 text-primary" />
                <h3 className="text-lg font-bold">Cronograma Social é PRO</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Gere um calendário editorial mensal completo para redes sociais em um clique. Exclusivo para usuários PRO!
                </p>
                <Link to="/pricing" className="mt-4 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">
                  Fazer upgrade para PRO
                </Link>
              </div>
            ) :
            <MarketingTab
              kind="social"
              mk={mk}
              setMk={setMk}
              tones={TONE_OPTIONS}
              copy={copy}
              copied={socialCopied}
              setCopied={setSocialCopied}
            />
          )}
        </section>
      </main>
    </AppShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="text-xs text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

type MarketingState = {
  niche: string;
  leadName: string;
  audience: string;
  description: string;
  tone: string;
  region: string;
  palette: string;
  channel: string;
};

const CHANNEL_OPTIONS: Record<"script" | "traffic" | "social", string[]> = {
  script: [
    "WhatsApp (1-a-1)",
    "Cold E-mail",
    "DM Instagram",
    "DM LinkedIn (B2B)",
    "SMS curto",
    "Ligação fria (script falado)",
  ],
  traffic: [
    "Meta Ads — Feed/Stories (Instagram + Facebook)",
    "Meta Ads — Reels (vídeo curto)",
    "Google Ads — Pesquisa (texto)",
    "Google Ads — Performance Max",
    "YouTube Ads (in-stream)",
    "TikTok Ads (Spark Ads)",
    "LinkedIn Ads (B2B)",
  ],
  social: [
    "Instagram + TikTok (Reels foco)",
    "Instagram (feed + stories + reels)",
    "TikTok puro (vídeo curto viral)",
    "YouTube Shorts + Reels",
    "LinkedIn (B2B / autoridade)",
    "Pinterest (visual / nichos estéticos)",
  ],
};

function channelGuidance(kind: "script" | "traffic" | "social", channel: string): string {
  if (kind === "script") {
    if (channel.startsWith("WhatsApp")) return "Frases curtas, quebra em 2-3 mensagens, zero formalidade excessiva, 1 emoji no máximo, sem links na 1ª msg.";
    if (channel.startsWith("Cold E-mail")) return "Inclua ASSUNTO chamativo (<50 caracteres), preview text, corpo escaneável com bullets, 1 P.S. e assinatura completa.";
    if (channel.startsWith("DM Instagram")) return "Tom casual, mencione algo do feed/bio do lead, máx 4 linhas, CTA leve para conversa — sem áudio longo na 1ª.";
    if (channel.startsWith("DM LinkedIn")) return "Tom profissional B2B, mencione cargo/empresa, foco em ROI/eficiência, sem emojis, CTA: call de 15min.";
    if (channel.startsWith("SMS")) return "Máximo 160 caracteres TOTAIS, 1 frase de gancho + 1 CTA com link curto. Identifique o remetente.";
    if (channel.startsWith("Ligação")) return "Script FALADO: abertura em 8s (nome + motivo), pergunta aberta, objeção provável + resposta, CTA agendamento.";
  }
  if (kind === "traffic") {
    if (channel.includes("Meta Ads — Feed")) return "Headlines até 40 char, primary text até 125 char (corte mobile), 1 CTA do Meta (Saiba mais/Enviar mensagem). Foco em parar o scroll.";
    if (channel.includes("Meta Ads — Reels")) return "Roteiro de vídeo 9:16 de 15-30s: HOOK em 2s, dor, solução, CTA na tela. Legenda curta, hashtags locais.";
    if (channel.includes("Google Ads — Pesquisa")) return "15 headlines (até 30 char) + 4 descriptions (até 90 char) + sitelinks. Use palavras-chave do nicho/cidade. SEM emojis.";
    if (channel.includes("Performance Max")) return "Forneça 5 headlines curtas, 5 long headlines, 5 descriptions, 5 ideias de imagem e 1 vídeo curto. Foque em conversão.";
    if (channel.includes("YouTube")) return "Roteiro 30s (skippable após 5s): HOOK forte nos 5s primeiros, problema, solução, CTA verbal + overlay. Pensado para áudio ON.";
    if (channel.includes("TikTok")) return "Estilo nativo (sem cara de anúncio), UGC, primeira frase = padrão de quebra. 9:16, legenda < 100 char, trend de áudio.";
    if (channel.includes("LinkedIn")) return "Tom B2B, dado/insight no início, CTA para baixar material ou agendar demo. Sem clickbait.";
  }
  if (kind === "social") {
    if (channel.includes("Reels foco")) return "70% dos posts em Reels (15-30s), 20% carrossel, 10% estático. Cada Reels com hook visual nos 2s iniciais.";
    if (channel.includes("Instagram (feed")) return "Mix equilibrado: 3 Reels, 2 carrosséis, 1 estático e 7 stories por semana. Stories com enquetes/caixinhas.";
    if (channel.includes("TikTok puro")) return "Foco 100% em vídeo nativo 9:16, áudios em alta da semana, séries (Parte 1/2/3), gancho nos primeiros 1.5s.";
    if (channel.includes("YouTube Shorts")) return "Roteiros 45-60s, hook + valor denso + loop final. Inclua título otimizado para busca + thumbnail conceitual.";
    if (channel.includes("LinkedIn")) return "Posts texto longo (1200-1800 char) + carrosséis PDF. Tom autoral, 1 case por semana, CTA para newsletter/DM.";
    if (channel.includes("Pinterest")) return "Pins verticais 2:3, títulos com palavra-chave de busca, descrição rica em SEO. 5 pins novos por semana.";
  }
  return "Adapte o formato e o ritmo da copy ao canal escolhido.";
}

function buildMarketingPrompt(
  kind: "script" | "traffic" | "social",
  m: MarketingState
) {
  const niche = m.niche.trim() || "[nicho do lead]";
  const leadName = m.leadName.trim() || "[nome do estabelecimento]";
  const audience = m.audience.trim() || "[público-alvo principal]";
  const description = m.description.trim() || "[objetivo / oferta principal]";
  const tone = m.tone;
  const region = m.region.trim() || "[cidade/região do lead]";
  const palette = m.palette;
  const channel = m.channel || CHANNEL_OPTIONS[kind][0];
  const guidance = channelGuidance(kind, channel);

  if (kind === "script") {
    return `Atue como um Copywriter Sênior especialista em abordagem fria.
Crie UM script de primeira abordagem para o lead "${leadName}" do nicho ${niche}.

📡 CANAL DE ENVIO: ${channel}
🧭 BOAS PRÁTICAS DO CANAL: ${guidance}

🎯 OBJETIVO: ${description}
👥 PÚBLICO ALVO DELE: ${audience}
🎙 TOM DE VOZ: ${tone}

📐 ESTRUTURA OBRIGATÓRIA — método AIDA com toque consultivo (sem ser agressivo):
1. ATENÇÃO: abertura curta e personalizada com o nome do lead, citando algo específico do negócio (rating, categoria, região).
2. INTERESSE: levante 1 oportunidade de melhora observada (não liste defeitos — aponte ganho potencial). Gere CURIOSIDADE.
3. DESEJO: insira 1 micro-prova social do nicho ${niche} (resultado real, % de aumento, case curto).
4. AÇÃO: CTA leve focado em "topa eu te mostrar em 2 minutos como aplicaria isso na ${leadName}?".

⚠ REGRAS:
- Sem listar tudo o que está errado. Foco em oportunidade + dor leve + CTA.
- Adapte 100% o formato, tamanho e ritmo às boas práticas do canal acima.
- Termine com a assinatura "[Seu nome]".
- Entregue a versão pronta para colar diretamente em ${channel}.`;
  }

  if (kind === "traffic") {
    return `Atue como um Gestor de Tráfego sênior especialista em conversão local.
Crie 3 variações de anúncios para "${leadName}" — nicho ${niche} em ${region}.

📡 PLATAFORMA / FORMATO: ${channel}
🧭 BOAS PRÁTICAS DA PLATAFORMA: ${guidance}

👥 PÚBLICO: ${audience}
🎯 OFERTA / OBJETIVO: ${description}
🎨 ESTILO VISUAL SUGERIDO: paleta ${palette}, tom ${tone}.

📐 PARA CADA UMA DAS 3 VARIAÇÕES, ENTREGUE NO FORMATO NATIVO de ${channel}:
- HEADLINE (respeitando o limite de caracteres da plataforma)
- CORPO / DESCRIÇÃO (no tamanho ideal do canal)
- CTA (use os CTAs nativos disponíveis na plataforma)
- SUGESTÃO DE CRIATIVO (descrição visual ou roteiro de vídeo, conforme o canal pedir)
- SEGMENTAÇÃO RECOMENDADA (interesses/keywords/audiências) específica para ${channel} em ${region}

⚠ FOCO: conversão local em ${region}. Evite copy genérica nacional.
Termine indicando qual variação é a "principal" para começar o teste A/B e qual KPI acompanhar.`;
  }

  // social
  return `Atue como Social Media Manager sênior especialista em ${niche}.
Crie um CRONOGRAMA DE 30 DIAS de conteúdo para o lead "${leadName}".

📡 CANAIS / FORMATO: ${channel}
🧭 BOAS PRÁTICAS DOS CANAIS: ${guidance}

👥 PÚBLICO: ${audience}
🎯 OBJETIVO COMERCIAL: ${description}
🎙 TOM DE VOZ: ${tone}

📐 ESTRUTURA — divida em 4 SEMANAS, cada uma com 7 posts:
- Semana 1 — AUTORIDADE (educar, mostrar bastidor, processo)
- Semana 2 — CONEXÃO (humanizar, depoimentos, comunidade)
- Semana 3 — DESEJO/PROVA (resultados, antes/depois, cases)
- Semana 4 — VENDA (oferta, CTA direto, escassez leve)

PARA CADA POST entregue: data sugerida (D+N), formato NATIVO de ${channel}, tema, copy completa do caption (no tamanho ideal do canal) e 3 hashtags locais (quando aplicável).

📹 BÔNUS: 3 ROTEIROS COMPLETOS DE VÍDEO no formato principal de ${channel}, com:
- Hook nos primeiros 2 segundos
- Desenvolvimento (3 cenas)
- CTA final
- Áudio sugerido / trend atual (quando o canal usar áudio)

⚠ REGRA: nenhum post pode ser puramente promocional. Sempre 70% valor / 30% venda.
⚠ FORMATO: respeite as boas práticas listadas acima — não entregue um post genérico.`;
}

function MarketingTab({
  kind,
  mk,
  setMk,
  tones,
  copy,
  copied,
  setCopied,
}: {
  kind: "script" | "traffic" | "social";
  mk: MarketingState;
  setMk: (m: MarketingState) => void;
  tones: string[];
  copy: (text: string, setFlag: (v: boolean) => void) => void;
  copied: boolean;
  setCopied: (v: boolean) => void;
}) {
  const prompt = buildMarketingPrompt(kind, mk);
  const intro =
    kind === "script"
      ? "Gera scripts de abordagem fria (WhatsApp + Cold Mail) com método AIDA e gatilhos consultivos — sem ser agressivo."
      : kind === "traffic"
        ? "Gera 3 variações prontas de anúncios locais (Headline + Corpo + CTA + Criativo) focadas em conversão na cidade do lead."
        : "Gera um calendário de 30 dias para Instagram/TikTok dividido em Autoridade · Conexão · Prova · Venda + 3 roteiros de Reels.";

  return (
    <>
      <p className="mb-4 text-[11px] text-muted-foreground">{intro}</p>

      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Nicho do lead">
          <input
            className="input"
            placeholder="Ex: pizzaria, barbearia, clínica de estética"
            value={mk.niche}
            onChange={(e) => setMk({ ...mk, niche: e.target.value })}
          />
        </Field>
        <Field label="Nome do estabelecimento (lead)">
          <input
            className="input"
            placeholder="Ex: Pet Shop Mar Azul"
            value={mk.leadName}
            onChange={(e) => setMk({ ...mk, leadName: e.target.value })}
          />
        </Field>
        <Field label="Público-alvo do lead">
          <input
            className="input"
            placeholder="Ex: famílias com pets, classe B, 30-50 anos"
            value={mk.audience}
            onChange={(e) => setMk({ ...mk, audience: e.target.value })}
          />
        </Field>
        <Field label="Tom da abordagem">
          <select
            className="input"
            value={mk.tone}
            onChange={(e) => setMk({ ...mk, tone: e.target.value })}
          >
            {tones.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field
          label={
            kind === "script"
              ? "Canal de envio (onde vai o script?)"
              : kind === "traffic"
                ? "Plataforma / formato do anúncio"
                : "Canais / formato do conteúdo"
          }
        >
          <select
            className="input"
            value={mk.channel || CHANNEL_OPTIONS[kind][0]}
            onChange={(e) => setMk({ ...mk, channel: e.target.value })}
          >
            {CHANNEL_OPTIONS[kind].map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </Field>
        <div className="md:col-span-2">
          <Field label="Objetivo / oferta principal">
            <textarea
              className="input min-h-[60px]"
              placeholder="Ex: aumentar agendamentos pelo WhatsApp em 30 dias com landing + tráfego pago"
              value={mk.description}
              onChange={(e) => setMk({ ...mk, description: e.target.value })}
            />
          </Field>
        </div>
        {kind === "traffic" && (
          <>
            <Field label="Cidade / região do lead">
              <input
                className="input"
                placeholder="Ex: Rio Grande - RS"
                value={mk.region}
                onChange={(e) => setMk({ ...mk, region: e.target.value })}
              />
            </Field>
            <Field label="Paleta sugerida (criativo)">
              <input
                className="input"
                value={mk.palette}
                onChange={(e) => setMk({ ...mk, palette: e.target.value })}
              />
            </Field>
          </>
        )}
      </div>

      <pre className="mt-4 max-h-80 overflow-auto whitespace-pre-wrap rounded border border-border bg-background p-3 text-xs text-foreground">
        {prompt}
      </pre>

      <button
        onClick={() => copy(prompt, setCopied)}
        className="mt-3 inline-flex items-center gap-2 rounded bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90"
      >
        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
        {copied ? "Copiado!" : "Copiar para o clipboard"}
      </button>
    </>
  );
}

export default Index;

