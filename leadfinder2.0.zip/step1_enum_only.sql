-- =============================================
-- STEP 1: Enums (must be committed separately)
-- =============================================
DO $$ BEGIN
    CREATE TYPE public.plan_type AS ENUM ('founder', 'basic', 'pro');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE public.user_status AS ENUM ('active', 'trial', 'suspended', 'banned');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE public.user_role AS ENUM ('root', 'admin', 'support', 'finance', 'user');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

-- Ensure all values exist (safe for re-runs)
ALTER TYPE public.plan_type ADD VALUE IF NOT EXISTS 'founder';
ALTER TYPE public.plan_type ADD VALUE IF NOT EXISTS 'basic';
ALTER TYPE public.plan_type ADD VALUE IF NOT EXISTS 'pro';

ALTER TYPE public.user_status ADD VALUE IF NOT EXISTS 'active';
ALTER TYPE public.user_status ADD VALUE IF NOT EXISTS 'trial';
ALTER TYPE public.user_status ADD VALUE IF NOT EXISTS 'suspended';
ALTER TYPE public.user_status ADD VALUE IF NOT EXISTS 'banned';

ALTER TYPE public.user_role ADD VALUE IF NOT EXISTS 'root';
ALTER TYPE public.user_role ADD VALUE IF NOT EXISTS 'admin';
ALTER TYPE public.user_role ADD VALUE IF NOT EXISTS 'support';
ALTER TYPE public.user_role ADD VALUE IF NOT EXISTS 'finance';
ALTER TYPE public.user_role ADD VALUE IF NOT EXISTS 'user';
