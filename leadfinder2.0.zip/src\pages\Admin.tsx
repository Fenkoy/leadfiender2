import { useCallback, useEffect, useMemo, useState } from "react";
import { Navigate, Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Shield, ArrowLeft, Plus, RefreshCw, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

import type { AdminUser, AdminStats, Plan, UserStatus } from "@/lib/admin-types";
import {
  fetchAdminUsers, fetchAdminStats,
  adminSetPlan, adminSetStatus, adminUpdateUser,
  adminResetLeads, adminResetPassword,
  adminDeleteUser, adminAddTag, adminRemoveTag,
  adminCreateUser,
} from "@/lib/admin-api";

import AdminStatsGrid from "@/components/admin/AdminStatsGrid";
import AdminFilters from "@/components/admin/AdminFilters";
import AdminUserTable from "@/components/admin/AdminUserTable";
import EditUserModal from "@/components/admin/EditUserModal";
import CreateUserModal from "@/components/admin/CreateUserModal";

const PAGE_SIZE = 25;

export default function Admin() {
  const { profile, loading: authLoading } = useAuth();
  const { toast } = useToast();

  // Data
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [totalCount, setTotalCount] = useState(0);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [loadingStats, setLoadingStats] = useState(true);

  // Filters
  const [search, setSearch] = useState("");
  const [planFilter, setPlanFilter] = useState<Plan | null>(null);
  const [statusFilter, setStatusFilter] = useState<UserStatus | null>(null);
  const [page, setPage] = useState(0);

  // UI
  const [busyId, setBusyId] = useState<string | null>(null);
  const [editUser, setEditUser] = useState<AdminUser | null>(null);
  const [showCreate, setShowCreate] = useState(false);

  // Debounced search
  const [debouncedSearch, setDebouncedSearch] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(t);
  }, [search]);

  // Reset page when filters change
  useEffect(() => { setPage(0); }, [debouncedSearch, planFilter, statusFilter]);

  // Load users
  const loadUsers = useCallback(async () => {
    setLoadingUsers(true);
    try {
      const { users: rows, totalCount: count } = await fetchAdminUsers({
        search: debouncedSearch || undefined,
        planFilter,
        statusFilter,
        limit: PAGE_SIZE,
        offset: page * PAGE_SIZE,
      });
      setUsers(rows);
      setTotalCount(count);
    } catch (err) {
      toast({ title: "Erro", description: err instanceof Error ? err.message : "Erro ao carregar", variant: "destructive" });
    } finally {
      setLoadingUsers(false);
    }
  }, [debouncedSearch, planFilter, statusFilter, page, toast]);

  // Load stats
  const loadStats = useCallback(async () => {
    setLoadingStats(true);
    try {
      const data = await fetchAdminStats();
      setStats(data);
    } catch {
      // Stats are non-critical, fail silently
    } finally {
      setLoadingStats(false);
    }
  }, []);

  // Initial load
  useEffect(() => {
    if (profile?.is_admin) {
      loadUsers();
      loadStats();
    }
  }, [profile?.is_admin, loadUsers, loadStats]);

  // Pagination
  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  // Guard
  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }
  if (!profile?.is_admin) return <Navigate to="/" replace />;

  // ---------- Actions ----------
  const handleSetPlan = async (uid: string, plan: Plan) => {
    setBusyId(uid);
    try {
      await adminSetPlan(uid, plan);
      toast({ title: "Plano atualizado", description: `→ ${plan.toUpperCase()}` });
      loadUsers();
      loadStats();
    } catch (err) {
      toast({ title: "Erro", description: err instanceof Error ? err.message : "Erro", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  };

  const handleSetStatus = async (uid: string, status: UserStatus) => {
    setBusyId(uid);
    try {
      await adminSetStatus(uid, status);
      toast({ title: "Status atualizado", description: `→ ${status}` });
      loadUsers();
      loadStats();
    } catch (err) {
      toast({ title: "Erro", description: err instanceof Error ? err.message : "Erro", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  };

  const handleResetLeads = async (uid: string) => {
    setBusyId(uid);
    try {
      await adminResetLeads(uid);
      toast({ title: "Leads resetados" });
      loadUsers();
    } catch (err) {
      toast({ title: "Erro", description: err instanceof Error ? err.message : "Erro", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  };

  const handleResetPassword = async (email: string) => {
    try {
      await adminResetPassword(email);
      toast({ title: "Email enviado", description: `Link de reset enviado para ${email}` });
    } catch (err) {
      toast({ title: "Erro", description: err instanceof Error ? err.message : "Erro", variant: "destructive" });
    }
  };

  const handleDelete = async (uid: string, email: string | null) => {
    if (!confirm(`Deletar ${email ?? "este usuário"}? Esta ação é irreversível.`)) return;
    setBusyId(uid);
    try {
      await adminDeleteUser(uid);
      toast({ title: "Usuário removido" });
      loadUsers();
      loadStats();
    } catch (err) {
      toast({ title: "Erro", description: err instanceof Error ? err.message : "Erro", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  };

  const handleAddTag = async (uid: string, tag: string) => {
    try {
      await adminAddTag(uid, tag);
      loadUsers();
    } catch (err) {
      toast({ title: "Erro", description: err instanceof Error ? err.message : "Erro", variant: "destructive" });
    }
  };

  const handleRemoveTag = async (uid: string, tag: string) => {
    try {
      await adminRemoveTag(uid, tag);
      loadUsers();
    } catch (err) {
      toast({ title: "Erro", description: err instanceof Error ? err.message : "Erro", variant: "destructive" });
    }
  };

  const handleEditSave = async (uid: string, data: { full_name?: string; status?: UserStatus; role?: any; leads_limit?: number; plan?: Plan }) => {
    try {
      if (data.plan) await adminSetPlan(uid, data.plan);
      await adminUpdateUser(uid, {
        full_name: data.full_name,
        status: data.status,
        role: data.role,
        leads_limit: data.leads_limit,
      });
      toast({ title: "Usuário atualizado" });
      loadUsers();
      loadStats();
    } catch (err) {
      toast({ title: "Erro", description: err instanceof Error ? err.message : "Erro", variant: "destructive" });
    }
  };

  const handleCreate = async (data: { email: string; password: string; full_name: string; plan: Plan; status: UserStatus }) => {
    try {
      await adminCreateUser(data);
      toast({ title: "Usuário criado!", description: `${data.email} foi adicionado.` });
      // Reload after a delay to allow the trigger to fire
      setTimeout(() => { loadUsers(); loadStats(); }, 1500);
    } catch (err) {
      toast({ title: "Erro ao criar", description: err instanceof Error ? err.message : "Erro", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 border border-primary/20">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Painel Admin</h1>
              <p className="text-xs text-muted-foreground">Gerenciamento de usuários e sistema</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => { loadUsers(); loadStats(); }} className="gap-1.5">
              <RefreshCw className="h-3.5 w-3.5" /> Atualizar
            </Button>
            <Button size="sm" onClick={() => setShowCreate(true)} className="gap-1.5">
              <Plus className="h-3.5 w-3.5" /> Criar Usuário
            </Button>
            <Link
              to="/"
              className="ml-2 inline-flex items-center gap-1 rounded-md border border-border px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground hover:border-border/80 transition-colors"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Voltar
            </Link>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="mb-6">
          <AdminStatsGrid stats={stats} loading={loadingStats} />
        </div>

        {/* Filters */}
        <div className="mb-4">
          <AdminFilters
            search={search}
            onSearchChange={setSearch}
            planFilter={planFilter}
            onPlanFilterChange={setPlanFilter}
            statusFilter={statusFilter}
            onStatusFilterChange={setStatusFilter}
          />
        </div>

        {/* User count + pagination info */}
        <div className="mb-3 flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            {loadingUsers ? (
              "Carregando..."
            ) : (
              <>
                <span className="font-semibold text-foreground">{totalCount}</span> usuário{totalCount !== 1 ? "s" : ""}
                {(debouncedSearch || planFilter || statusFilter) && " encontrado" + (totalCount !== 1 ? "s" : "")}
              </>
            )}
          </p>
          {totalPages > 1 && (
            <div className="flex items-center gap-2">
              <Button
                variant="outline" size="sm"
                onClick={() => setPage(Math.max(0, page - 1))}
                disabled={page === 0}
                className="h-7 w-7 p-0"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
              </Button>
              <span className="text-xs text-muted-foreground tabular-nums">
                {page + 1} / {totalPages}
              </span>
              <Button
                variant="outline" size="sm"
                onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
                disabled={page >= totalPages - 1}
                className="h-7 w-7 p-0"
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </Button>
            </div>
          )}
        </div>

        {/* Table */}
        {loadingUsers && users.length === 0 ? (
          <div className="flex items-center justify-center py-20 rounded-xl border border-border bg-card/30">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : users.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 rounded-xl border border-border bg-card/30">
            <p className="text-sm text-muted-foreground">Nenhum usuário encontrado.</p>
          </div>
        ) : (
          <AdminUserTable
            users={users}
            currentUserId={profile.id}
            busyId={busyId}
            onSetPlan={handleSetPlan}
            onSetStatus={handleSetStatus}
            onResetLeads={handleResetLeads}
            onResetPassword={handleResetPassword}
            onDelete={handleDelete}
            onAddTag={handleAddTag}
            onRemoveTag={handleRemoveTag}
            onEditUser={setEditUser}
          />
        )}

        {/* Modals */}
        <EditUserModal
          user={editUser}
          open={editUser !== null}
          onClose={() => setEditUser(null)}
          onSave={handleEditSave}
        />
        <CreateUserModal
          open={showCreate}
          onClose={() => setShowCreate(false)}
          onCreate={handleCreate}
        />
      </div>
    </div>
  );
}
