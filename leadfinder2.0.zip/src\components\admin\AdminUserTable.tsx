import { useState } from "react";
import {
  AdminUser, Plan, UserStatus,
  PLAN_CONFIG, STATUS_CONFIG, ROLE_CONFIG,
  TAG_PRESETS,
} from "@/lib/admin-types";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import {
  MoreHorizontal, Edit, Key, Eye, Ban,
  UserCheck, Trash2, ChevronDown, ChevronRight,
  Tag, X, Plus, Zap, Calendar, Clock,
} from "lucide-react";
import UserExpandedRow from "./UserExpandedRow";

type Props = {
  users: AdminUser[];
  currentUserId: string;
  busyId: string | null;
  onSetPlan: (uid: string, plan: Plan) => void;
  onSetStatus: (uid: string, status: UserStatus) => void;
  onResetLeads: (uid: string) => void;
  onResetPassword: (email: string) => void;
  onDelete: (uid: string, email: string | null) => void;
  onAddTag: (uid: string, tag: string) => void;
  onRemoveTag: (uid: string, tag: string) => void;
  onEditUser: (user: AdminUser) => void;
};

function getInitials(name: string | null, email: string | null): string {
  if (name) {
    const parts = name.trim().split(/\s+/);
    return parts.map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  }
  return (email ?? "?")[0].toUpperCase();
}

function timeAgo(dateStr: string | null): string {
  if (!dateStr) return "Nunca";
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Agora";
  if (mins < 60) return `${mins}m atrás`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h atrás`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d atrás`;
  return new Date(dateStr).toLocaleDateString("pt-BR");
}

export default function AdminUserTable({
  users, currentUserId, busyId,
  onSetPlan, onSetStatus, onResetLeads, onResetPassword,
  onDelete, onAddTag, onRemoveTag, onEditUser,
}: Props) {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [tagInputId, setTagInputId] = useState<string | null>(null);
  const [tagInputValue, setTagInputValue] = useState("");

  const toggleExpand = (uid: string) => {
    setExpandedId(expandedId === uid ? null : uid);
  };

  const handleAddTag = (uid: string, tag: string) => {
    if (tag.trim()) {
      onAddTag(uid, tag.trim());
      setTagInputValue("");
      setTagInputId(null);
    }
  };

  return (
    <div className="overflow-x-auto rounded-xl border border-border bg-card/30 backdrop-blur-sm">
      <table className="w-full text-sm">
        <thead className="border-b border-border bg-muted/20">
          <tr>
            <th className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground w-8" />
            <th className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Usuário
            </th>
            <th className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Status
            </th>
            <th className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Plano
            </th>
            <th className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Leads
            </th>
            <th className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Tags
            </th>
            <th className="px-4 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Último Login
            </th>
            <th className="px-4 py-3 text-right text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Ações
            </th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => {
            const isExpanded = expandedId === u.user_id;
            const isBusy = busyId === u.user_id;
            const isSelf = u.user_id === currentUserId;
            const planCfg = PLAN_CONFIG[u.plan];
            const statusCfg = STATUS_CONFIG[u.status];
            const roleCfg = ROLE_CONFIG[u.role];

            return (
              <>
                <tr
                  key={u.user_id}
                  className={`border-b border-border/50 transition-colors hover:bg-muted/10 ${isExpanded ? "bg-muted/10" : ""}`}
                >
                  {/* Expand toggle */}
                  <td className="px-4 py-3">
                    <button onClick={() => toggleExpand(u.user_id)} className="text-muted-foreground hover:text-foreground transition-colors">
                      {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                    </button>
                  </td>

                  {/* User info */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary border border-primary/20">
                        {getInitials(u.full_name, u.email)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-medium truncate">{u.full_name || "(sem nome)"}</span>
                          {u.is_admin && <span className="text-xs" title={roleCfg.label}>{roleCfg.icon}</span>}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">{u.email}</div>
                      </div>
                    </div>
                  </td>

                  {/* Status */}
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium ${statusCfg.bgClass}`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${statusCfg.dot}`} />
                      {statusCfg.label}
                    </span>
                  </td>

                  {/* Plan */}
                  <td className="px-4 py-3">
                    <select
                      value={u.plan}
                      disabled={isBusy}
                      onChange={(e) => onSetPlan(u.user_id, e.target.value as Plan)}
                      className={`rounded-md border px-2 py-1 text-xs font-medium bg-transparent cursor-pointer transition-colors ${planCfg.bgClass}`}
                    >
                      <option value="basic" className="bg-background text-foreground">Basic</option>
                      <option value="pro" className="bg-background text-foreground">Pro</option>
                      <option value="founder" className="bg-background text-foreground">Founder</option>
                    </select>
                  </td>

                  {/* Leads */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Zap className="h-3.5 w-3.5 text-cyan-400" />
                      <span className="font-mono text-sm font-semibold">{u.leads_used_today}</span>
                      <span className="text-[10px] text-muted-foreground">/ {u.leads_limit >= 999999 ? "∞" : u.leads_limit}</span>
                    </div>
                  </td>

                  {/* Tags */}
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap items-center gap-1 max-w-[200px]">
                      {u.tags.slice(0, 3).map((tag) => (
                        <span
                          key={tag}
                          className="group/tag inline-flex items-center gap-1 rounded-md bg-muted/50 px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground border border-border/50 hover:border-red-500/30 transition-colors"
                        >
                          {tag}
                          <button
                            onClick={(e) => { e.stopPropagation(); onRemoveTag(u.user_id, tag); }}
                            className="opacity-0 group-hover/tag:opacity-100 transition-opacity text-red-400 hover:text-red-300"
                          >
                            <X className="h-2.5 w-2.5" />
                          </button>
                        </span>
                      ))}
                      {u.tags.length > 3 && (
                        <span className="text-[10px] text-muted-foreground">+{u.tags.length - 3}</span>
                      )}
                      {tagInputId === u.user_id ? (
                        <div className="flex items-center gap-1">
                          <input
                            autoFocus
                            value={tagInputValue}
                            onChange={(e) => setTagInputValue(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") handleAddTag(u.user_id, tagInputValue);
                              if (e.key === "Escape") { setTagInputId(null); setTagInputValue(""); }
                            }}
                            onBlur={() => { setTagInputId(null); setTagInputValue(""); }}
                            className="h-5 w-20 rounded border border-primary/30 bg-transparent px-1 text-[10px] outline-none focus:border-primary"
                            placeholder="Tag..."
                            list={`tags-${u.user_id}`}
                          />
                          <datalist id={`tags-${u.user_id}`}>
                            {TAG_PRESETS.filter((t) => !u.tags.includes(t)).map((t) => (
                              <option key={t} value={t} />
                            ))}
                          </datalist>
                        </div>
                      ) : (
                        <button
                          onClick={() => setTagInputId(u.user_id)}
                          className="rounded p-0.5 text-muted-foreground hover:text-primary transition-colors"
                          title="Adicionar tag"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      )}
                    </div>
                  </td>

                  {/* Last login */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {timeAgo(u.last_login_at)}
                    </div>
                  </td>

                  {/* Actions dropdown */}
                  <td className="px-4 py-3 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0" disabled={isBusy}>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuLabel className="text-[10px] uppercase tracking-wider">Ações</DropdownMenuLabel>
                        <DropdownMenuSeparator />

                        <DropdownMenuItem onClick={() => toggleExpand(u.user_id)}>
                          <Eye className="mr-2 h-3.5 w-3.5" /> Ver Detalhes
                        </DropdownMenuItem>

                        <DropdownMenuItem onClick={() => onEditUser(u)}>
                          <Edit className="mr-2 h-3.5 w-3.5" /> Editar Usuário
                        </DropdownMenuItem>

                        <DropdownMenuItem
                          onClick={() => u.email && onResetPassword(u.email)}
                          disabled={!u.email}
                        >
                          <Key className="mr-2 h-3.5 w-3.5" /> Resetar Senha
                        </DropdownMenuItem>

                        <DropdownMenuItem onClick={() => onResetLeads(u.user_id)}>
                          <Zap className="mr-2 h-3.5 w-3.5" /> Resetar Leads
                        </DropdownMenuItem>

                        <DropdownMenuSeparator />

                        {u.status !== "suspended" ? (
                          <DropdownMenuItem
                            onClick={() => onSetStatus(u.user_id, "suspended")}
                            className="text-orange-400 focus:text-orange-400"
                            disabled={isSelf}
                          >
                            <Ban className="mr-2 h-3.5 w-3.5" /> Suspender
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem
                            onClick={() => onSetStatus(u.user_id, "active")}
                            className="text-emerald-400 focus:text-emerald-400"
                          >
                            <UserCheck className="mr-2 h-3.5 w-3.5" /> Reativar
                          </DropdownMenuItem>
                        )}

                        {u.status !== "banned" && (
                          <DropdownMenuItem
                            onClick={() => onSetStatus(u.user_id, "banned")}
                            className="text-red-400 focus:text-red-400"
                            disabled={isSelf}
                          >
                            <Ban className="mr-2 h-3.5 w-3.5" /> Banir
                          </DropdownMenuItem>
                        )}

                        <DropdownMenuSeparator />

                        <DropdownMenuItem
                          onClick={() => onDelete(u.user_id, u.email)}
                          className="text-red-500 focus:text-red-500"
                          disabled={isSelf}
                        >
                          <Trash2 className="mr-2 h-3.5 w-3.5" /> Deletar
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>

                {/* Expanded detail row */}
                {isExpanded && (
                  <tr key={`${u.user_id}-expanded`}>
                    <td colSpan={8} className="px-0 py-0">
                      <UserExpandedRow user={u} />
                    </td>
                  </tr>
                )}
              </>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
