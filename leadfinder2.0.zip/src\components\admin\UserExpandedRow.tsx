import { useEffect, useState } from "react";
import { AdminUser, UserLog, ACTION_LABELS, PLAN_CONFIG, STATUS_CONFIG } from "@/lib/admin-types";
import { fetchUserLogs } from "@/lib/admin-api";
import { Zap, Calendar, Clock, Activity, FileText, Loader2 } from "lucide-react";

type Props = { user: AdminUser };

export default function UserExpandedRow({ user }: Props) {
  const [logs, setLogs] = useState<UserLog[] | null>(null);
  const [loadingLogs, setLoadingLogs] = useState(true);

  useEffect(() => {
    setLoadingLogs(true);
    fetchUserLogs(user.user_id, 10)
      .then(setLogs)
      .catch(() => setLogs([]))
      .finally(() => setLoadingLogs(false));
  }, [user.user_id]);

  const createdDate = new Date(user.created_at).toLocaleDateString("pt-BR", {
    day: "2-digit", month: "short", year: "numeric",
  });

  const planCfg = PLAN_CONFIG[user.plan];
  const statusCfg = STATUS_CONFIG[user.status];

  return (
    <div className="border-t border-primary/10 bg-gradient-to-b from-primary/[0.02] to-transparent px-6 py-5">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Stats */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            <Activity className="h-3 w-3" /> Estatísticas de Leads
          </h4>
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-lg border border-border bg-card/50 p-3 text-center">
              <p className="text-lg font-bold text-cyan-400 tabular-nums">{user.leads_used_today}</p>
              <p className="text-[10px] text-muted-foreground">Hoje</p>
            </div>
            <div className="rounded-lg border border-border bg-card/50 p-3 text-center">
              <p className="text-lg font-bold text-blue-400 tabular-nums">{user.leads_used_week}</p>
              <p className="text-[10px] text-muted-foreground">Semana</p>
            </div>
            <div className="rounded-lg border border-border bg-card/50 p-3 text-center">
              <p className="text-lg font-bold text-violet-400 tabular-nums">{user.leads_used_month}</p>
              <p className="text-[10px] text-muted-foreground">Mês</p>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground flex items-center gap-1.5">
                <Zap className="h-3 w-3" /> Limite diário
              </span>
              <span className="font-mono font-semibold">
                {user.leads_limit >= 999999 ? "∞" : user.leads_limit}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground flex items-center gap-1.5">
                <Calendar className="h-3 w-3" /> Criado em
              </span>
              <span className="font-medium">{createdDate}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground flex items-center gap-1.5">
                <Clock className="h-3 w-3" /> Último login
              </span>
              <span className="font-medium">
                {user.last_login_at
                  ? new Date(user.last_login_at).toLocaleString("pt-BR")
                  : "Nunca"}
              </span>
            </div>
          </div>
        </div>

        {/* Info panel */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            <FileText className="h-3 w-3" /> Informações
          </h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Plano</span>
              <span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium ${planCfg.bgClass}`}>
                {planCfg.label}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Status</span>
              <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium ${statusCfg.bgClass}`}>
                <span className={`h-1.5 w-1.5 rounded-full ${statusCfg.dot}`} />
                {statusCfg.label}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Email</span>
              <span className="font-mono text-[11px]">{user.email}</span>
            </div>
            {user.tags.length > 0 && (
              <div className="flex items-start justify-between text-xs">
                <span className="text-muted-foreground mt-0.5">Tags</span>
                <div className="flex flex-wrap gap-1 justify-end max-w-[180px]">
                  {user.tags.map((tag) => (
                    <span key={tag} className="rounded bg-muted/50 px-1.5 py-0.5 text-[10px] border border-border/50">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Activity Logs */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            <Activity className="h-3 w-3" /> Atividade Recente
          </h4>
          {loadingLogs ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            </div>
          ) : logs && logs.length > 0 ? (
            <div className="space-y-1.5 max-h-[200px] overflow-y-auto pr-1">
              {logs.map((log) => (
                <div key={log.id} className="flex items-start gap-2 rounded-md bg-muted/20 px-2.5 py-2 text-[11px]">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary/60 mt-1.5 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <span className="font-medium">
                      {ACTION_LABELS[log.action] ?? log.action}
                    </span>
                    {log.metadata && Object.keys(log.metadata).length > 0 && (
                      <p className="text-muted-foreground truncate">
                        {Object.entries(log.metadata)
                          .filter(([, v]) => v != null)
                          .map(([k, v]) => `${k}: ${v}`)
                          .join(" · ")}
                      </p>
                    )}
                    <p className="text-muted-foreground/60 text-[10px]">
                      {new Date(log.created_at).toLocaleString("pt-BR")}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground py-4 text-center">Nenhuma atividade registrada.</p>
          )}
        </div>
      </div>
    </div>
  );
}
