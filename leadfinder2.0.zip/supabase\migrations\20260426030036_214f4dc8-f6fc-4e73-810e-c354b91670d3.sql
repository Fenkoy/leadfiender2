-- =========================================================
-- LeadFinder: planos, usuários, contadores e eventos
-- =========================================================

-- 1. Enum de planos
create type public.plan_type as enum ('founder', 'basic', 'pro');

-- 2. Profiles (1:1 com auth.users)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

create policy "profiles_self_select" on public.profiles
  for select to authenticated using (id = auth.uid());
create policy "profiles_self_update" on public.profiles
  for update to authenticated using (id = auth.uid());
create policy "profiles_self_insert" on public.profiles
  for insert to authenticated with check (id = auth.uid());

-- 3. user_plans (1:1 atual; mantemos histórico via current_period_end)
create table public.user_plans (
  user_id uuid primary key references auth.users(id) on delete cascade,
  plan public.plan_type not null default 'basic',
  status text not null default 'active', -- active | canceled | past_due
  current_period_end timestamptz, -- null = vitalício (founder)
  stripe_customer_id text,
  stripe_subscription_id text,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
alter table public.user_plans enable row level security;

create policy "user_plans_self_select" on public.user_plans
  for select to authenticated using (user_id = auth.uid());

-- 4. lead_usage (linha por usuário, atualizada em cada captura)
create table public.lead_usage (
  user_id uuid primary key references auth.users(id) on delete cascade,
  leads_used_today integer not null default 0,
  last_reset_date date not null default current_date,
  updated_at timestamptz not null default now()
);
alter table public.lead_usage enable row level security;

create policy "lead_usage_self_select" on public.lead_usage
  for select to authenticated using (user_id = auth.uid());

-- 5. upgrade_events (analytics de conversão)
create table public.upgrade_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  event_type text not null, -- 'blocked_access' | 'limit_reached' | 'upgrade_clicked' | 'checkout_started'
  feature text,
  from_plan public.plan_type,
  to_plan public.plan_type,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);
alter table public.upgrade_events enable row level security;

create policy "upgrade_events_self_select" on public.upgrade_events
  for select to authenticated using (user_id = auth.uid());
create policy "upgrade_events_self_insert" on public.upgrade_events
  for insert to authenticated with check (user_id = auth.uid());

create index upgrade_events_user_idx on public.upgrade_events (user_id, created_at desc);

-- 6. founder_slots (singleton-like)
create table public.founder_slots (
  id integer primary key default 1,
  total_slots integer not null default 50,
  claimed integer not null default 0,
  updated_at timestamptz not null default now(),
  constraint founder_slots_singleton check (id = 1)
);
alter table public.founder_slots enable row level security;
insert into public.founder_slots (id, total_slots, claimed) values (1, 50, 0);

create policy "founder_slots_public_read" on public.founder_slots
  for select to anon, authenticated using (true);

-- =========================================================
-- Funções (security definer, search_path travado)
-- =========================================================

-- Trigger: cria profile + plano basic ao registrar usuário
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', ''),
    new.email
  )
  on conflict (id) do nothing;

  insert into public.user_plans (user_id, plan, status)
  values (new.id, 'basic', 'active')
  on conflict (user_id) do nothing;

  insert into public.lead_usage (user_id) values (new.id)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- current_plan: plano efetivo do usuário logado
create or replace function public.current_plan()
returns public.plan_type
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select plan from public.user_plans
      where user_id = auth.uid()
        and status = 'active'
        and (plan = 'founder' or current_period_end is null or current_period_end > now())
      limit 1),
    'basic'::public.plan_type
  );
$$;

-- has_feature: gating server-side
create or replace function public.has_feature(_feature text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select case public.current_plan()
    when 'founder' then true
    when 'pro'     then true
    when 'basic'   then _feature in ('leads', 'workbench', 'scripts')
  end;
$$;

-- can_use_lead: respeita limite diário com reset automático
create or replace function public.can_use_lead()
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  _plan public.plan_type;
  _used integer;
  _reset date;
begin
  _plan := public.current_plan();
  if _plan = 'founder' then return true; end if;

  select leads_used_today, last_reset_date
    into _used, _reset
    from public.lead_usage
    where user_id = auth.uid();

  if _reset is null or _reset < current_date then
    return true; -- novo dia → contador será zerado em consume_lead
  end if;

  if _plan = 'pro'   and _used >= 100 then return false; end if;
  if _plan = 'basic' and _used >= 30  then return false; end if;
  return true;
end;
$$;

-- consume_lead: atomic increment com reset
create or replace function public.consume_lead()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  _plan public.plan_type;
  _limit integer;
  _used integer;
  _reset date;
begin
  if auth.uid() is null then return false; end if;
  _plan := public.current_plan();

  insert into public.lead_usage (user_id) values (auth.uid())
  on conflict (user_id) do nothing;

  select leads_used_today, last_reset_date
    into _used, _reset
    from public.lead_usage
    where user_id = auth.uid()
    for update;

  if _reset < current_date then
    _used := 0;
    update public.lead_usage
       set leads_used_today = 0, last_reset_date = current_date, updated_at = now()
     where user_id = auth.uid();
  end if;

  _limit := case _plan
              when 'founder' then 2147483647
              when 'pro' then 100
              when 'basic' then 30
            end;

  if _used >= _limit then
    insert into public.upgrade_events (user_id, event_type, feature, from_plan, metadata)
    values (auth.uid(), 'limit_reached', 'leads', _plan, jsonb_build_object('limit', _limit));
    return false;
  end if;

  update public.lead_usage
     set leads_used_today = leads_used_today + 1, updated_at = now()
   where user_id = auth.uid();
  return true;
end;
$$;

-- claim_founder: usa um dos 50 slots se houver
create or replace function public.claim_founder()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  _claimed integer;
  _total integer;
begin
  if auth.uid() is null then return false; end if;

  select claimed, total_slots into _claimed, _total
    from public.founder_slots where id = 1 for update;

  if _claimed >= _total then return false; end if;

  update public.founder_slots
     set claimed = claimed + 1, updated_at = now()
   where id = 1;

  update public.user_plans
     set plan = 'founder', status = 'active', current_period_end = null, updated_at = now()
   where user_id = auth.uid();

  return true;
end;
$$;
