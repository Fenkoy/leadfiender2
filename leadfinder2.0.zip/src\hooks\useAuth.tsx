import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Plan } from "@/lib/plans";

export type Profile = {
  id: string;
  full_name: string | null;
  email: string | null;
  niche: string | null;
  goal: string | null;
  experience: string | null;
  onboarding_completed: boolean;
  is_admin: boolean;
};

type Ctx = {
  user: User | null;
  session: Session | null;
  plan: Plan | null;
  profile: Profile | null;
  leadsUsedToday: number;
  loading: boolean;
  refresh: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  signOut: () => Promise<void>;
};

const AuthCtx = createContext<Ctx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [plan, setPlan] = useState<Plan | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [leadsUsedToday, setLeads] = useState(0);
  const [loading, setLoading] = useState(true);

  const loadAll = async (uid: string) => {
    const [{ data: planRow }, { data: usageRow }, { data: profileRow }] = await Promise.all([
      supabase.from("user_plans").select("plan").eq("user_id", uid).maybeSingle(),
      supabase.from("lead_usage").select("leads_used_today, last_reset_date").eq("user_id", uid).maybeSingle(),
      supabase
        .from("profiles")
        .select("id, full_name, email, niche, goal, experience, onboarding_completed, is_admin")
        .eq("id", uid)
        .maybeSingle(),
    ]);
    setPlan((planRow?.plan as Plan) ?? "basic");
    const today = new Date().toISOString().slice(0, 10);
    setLeads(usageRow && usageRow.last_reset_date === today ? usageRow.leads_used_today : 0);
    setProfile((profileRow as Profile) ?? null);
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) {
        setTimeout(() => loadAll(s.user.id), 0);
      } else {
        setPlan(null);
        setProfile(null);
        setLeads(0);
      }
    });

    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) loadAll(s.user.id).finally(() => setLoading(false));
      else setLoading(false);
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  const refresh = async () => {
    if (user) await loadAll(user.id);
  };
  const refreshProfile = refresh;

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <AuthCtx.Provider
      value={{ user, session, plan, profile, leadsUsedToday, loading, refresh, refreshProfile, signOut }}
    >
      {children}
    </AuthCtx.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthCtx);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
