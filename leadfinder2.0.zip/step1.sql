DO $$ BEGIN
    CREATE TYPE public.plan_type AS ENUM ('founder', 'basic', 'pro');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;
ALTER TYPE public.plan_type ADD VALUE IF NOT EXISTS 'founder';
ALTER TYPE public.plan_type ADD VALUE IF NOT EXISTS 'basic';
ALTER TYPE public.plan_type ADD VALUE IF NOT EXISTS 'pro';
