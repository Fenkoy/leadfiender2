// Niche presets mapped to OSM tag filters for Overpass.
// Each entry produces multiple "key=value" matches OR regex name matches.

export interface NichePreset {
  id: string;
  label: string;
  // OSM tag filters: array of [key, valueRegex]
  tags: Array<[string, string]>;
  // Fallback name keywords (regex, case-insensitive) for places without proper tags
  nameKeywords: string[];
}

export const NICHES: NichePreset[] = [
  {
    id: "restaurante",
    label: "Restaurantes",
    tags: [["amenity", "restaurant"]],
    nameKeywords: ["restaurante", "restaurant"],
  },
  {
    id: "barbearia",
    label: "Barbearias",
    tags: [
      ["shop", "hairdresser"],
      ["shop", "barber"],
      ["craft", "barber"],
    ],
    nameKeywords: ["barbearia", "barber"],
  },
  {
    id: "pizzaria",
    label: "Pizzarias",
    tags: [
      ["amenity", "restaurant"],
      ["cuisine", "pizza"],
    ],
    nameKeywords: ["pizza", "pizzaria"],
  },
  {
    id: "hamburgueria",
    label: "Hamburguerias",
    tags: [
      ["amenity", "fast_food"],
      ["cuisine", "burger"],
    ],
    nameKeywords: ["burger", "hamburg", "smash"],
  },
  {
    id: "salao",
    label: "Salões de Beleza",
    tags: [
      ["shop", "beauty"],
      ["shop", "hairdresser"],
    ],
    nameKeywords: ["salão", "salao", "beleza", "beauty"],
  },
  {
    id: "estetica",
    label: "Clínicas de Estética",
    tags: [
      ["shop", "beauty"],
      ["healthcare", "cosmetic"],
      ["amenity", "clinic"],
    ],
    nameKeywords: ["estética", "estetica", "aesthetic"],
  },
  {
    id: "nutricao",
    label: "Nutricionistas",
    tags: [
      ["healthcare", "nutrition_counseling"],
      ["healthcare:speciality", "nutrition"],
      ["office", "nutritionist"],
    ],
    nameKeywords: ["nutricion", "nutri"],
  },
  {
    id: "psicologia",
    label: "Psicólogos",
    tags: [
      ["healthcare", "psychotherapist"],
      ["healthcare:speciality", "psychology"],
      ["office", "psychologist"],
    ],
    nameKeywords: ["psicolog", "psychol"],
  },
  {
    id: "terapia",
    label: "Terapeutas",
    tags: [
      ["healthcare", "alternative"],
      ["healthcare", "therapist"],
      ["healthcare:speciality", "therapy"],
    ],
    nameKeywords: ["terapeut", "terapia", "therapy"],
  },
  {
    id: "perfumaria",
    label: "Perfumarias",
    tags: [
      ["shop", "perfumery"],
      ["shop", "cosmetics"],
    ],
    nameKeywords: ["perfumaria", "perfume"],
  },
  {
    id: "outros",
    label: "Outros (digite)",
    tags: [],
    nameKeywords: [],
  },
];

export function getNiche(id: string): NichePreset | undefined {
  return NICHES.find((n) => n.id === id);
}
