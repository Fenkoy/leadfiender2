// Admin API — all Supabase calls for the admin panel
import { supabase } from "@/integrations/supabase/client";
import type { AdminUser, AdminStats, UserLog, Plan, UserStatus, UserRole } from "@/lib/admin-types";

// ---------- List Users ----------
export async function fetchAdminUsers(params: {
  search?: string;
  planFilter?: Plan | null;
  statusFilter?: UserStatus | null;
  limit?: number;
  offset?: number;
}): Promise<{ users: AdminUser[]; totalCount: number }> {
  const { data, error } = await supabase.rpc("admin_list_users", {
    _search: params.search || null,
    _plan_filter: params.planFilter || null,
    _status_filter: params.statusFilter || null,
    _limit: params.limit ?? 50,
    _offset: params.offset ?? 0,
  });
  if (error) throw new Error(error.message);
  const rows = (data as AdminUser[]) ?? [];
  return {
    users: rows,
    totalCount: rows.length > 0 ? Number(rows[0].total_count) : 0,
  };
}

// ---------- Dashboard Stats ----------
export async function fetchAdminStats(): Promise<AdminStats> {
  const { data, error } = await supabase.rpc("admin_get_stats");
  if (error) throw new Error(error.message);
  return data as AdminStats;
}

// ---------- Set Plan ----------
export async function adminSetPlan(userId: string, plan: Plan): Promise<void> {
  const { error } = await supabase.rpc("admin_set_plan", { _user_id: userId, _plan: plan });
  if (error) throw new Error(error.message);
}

// ---------- Set Status ----------
export async function adminSetStatus(userId: string, status: UserStatus): Promise<void> {
  const { error } = await supabase.rpc("admin_set_status", { _user_id: userId, _status: status });
  if (error) throw new Error(error.message);
}

// ---------- Update User ----------
export async function adminUpdateUser(userId: string, data: {
  full_name?: string;
  status?: UserStatus;
  role?: UserRole;
  leads_limit?: number;
}): Promise<void> {
  const { error } = await supabase.rpc("admin_update_user", {
    _user_id: userId,
    _full_name: data.full_name ?? null,
    _status: data.status ?? null,
    _role: data.role ?? null,
    _leads_limit: data.leads_limit ?? null,
  });
  if (error) throw new Error(error.message);
}

// ---------- Reset Leads ----------
export async function adminResetLeads(userId: string): Promise<void> {
  const { error } = await supabase.rpc("admin_reset_leads", { _user_id: userId });
  if (error) throw new Error(error.message);
}

// ---------- Delete User ----------
export async function adminDeleteUser(userId: string): Promise<void> {
  const { error } = await supabase.rpc("admin_delete_user", { _user_id: userId });
  if (error) throw new Error(error.message);
}

// ---------- User Logs ----------
export async function fetchUserLogs(userId: string, limit = 20): Promise<UserLog[]> {
  const { data, error } = await supabase.rpc("admin_get_user_logs", {
    _user_id: userId,
    _limit: limit,
  });
  if (error) throw new Error(error.message);
  return (data as UserLog[]) ?? [];
}

// ---------- Tags ----------
export async function adminAddTag(userId: string, tag: string): Promise<void> {
  const { error } = await supabase.rpc("admin_add_tag", { _user_id: userId, _tag: tag });
  if (error) throw new Error(error.message);
}

export async function adminRemoveTag(userId: string, tag: string): Promise<void> {
  const { error } = await supabase.rpc("admin_remove_tag", { _user_id: userId, _tag: tag });
  if (error) throw new Error(error.message);
}

// ---------- Reset Password ----------
export async function adminResetPassword(email: string): Promise<void> {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/reset-password`,
  });
  if (error) throw new Error(error.message);
  // Log it
  // Note: This is logged client-side because password reset uses auth API, not an RPC
}

// ---------- Create User ----------
export async function adminCreateUser(params: {
  email: string;
  password: string;
  full_name: string;
  plan: Plan;
  status: UserStatus;
}): Promise<void> {
  // Use Supabase auth signUp (creates the user in auth.users, trigger handles the rest)
  const { error } = await supabase.auth.signUp({
    email: params.email,
    password: params.password,
    options: {
      data: { full_name: params.full_name },
      emailRedirectTo: `${window.location.origin}/`,
    },
  });
  if (error) throw new Error(error.message);

  // We need to wait a moment for the trigger to create the profile, then update plan/status
  // This is a known limitation of client-side user creation
  // In production, this would be an edge function with service_role key
}
