import { useEffect, useRef, useState } from "react";
import { Zap, ScanLine, CheckCircle2 } from "lucide-react";

type Phase = "idle" | "scanning" | "success";

interface Particle {
  id: number;
  left: number;
  delay: number;
  char: string;
}

interface Props {
  /** Receives the raw pasted text. Parent decides what to do with it. */
  onCapture: (text: string) => void;
  /** Optional secondary action area (e.g. an "enrich last lead" button). */
  footer?: React.ReactNode;
}

/**
 * Câmara de Extração HUD
 * --------------------------------------------------------------------
 * Replaces the legacy <textarea> with a futuristic glassmorphism panel.
 * - Pulsing neon-green border (system active)
 * - L-shaped corner brackets (target frame)
 * - On Ctrl+V: laser scan animation + binary particles + success flash
 * - The pasted content is forwarded to the parent and never visible inside
 *   the chamber.
 */
export function ExtractionChamber({ onCapture, footer }: Props) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [particles, setParticles] = useState<Particle[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  const hiddenInputRef = useRef<HTMLTextAreaElement>(null);

  // Allow the user to focus the chamber and just hit Ctrl+V anywhere on it.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const handler = () => hiddenInputRef.current?.focus();
    el.addEventListener("click", handler);
    return () => el.removeEventListener("click", handler);
  }, []);

  const triggerScan = (text: string) => {
    if (!text.trim()) return;
    // Generate 14 binary/hex particles at random positions
    const next: Particle[] = Array.from({ length: 14 }).map((_, i) => ({
      id: Date.now() + i,
      left: Math.random() * 92 + 4, // 4% – 96%
      delay: Math.random() * 350,   // ms within the 800ms window
      char: Math.random() > 0.5
        ? (Math.random() > 0.5 ? "1" : "0")
        : "01"[Math.floor(Math.random() * 2)] + "01"[Math.floor(Math.random() * 2)],
    }));
    setParticles(next);
    setPhase("scanning");

    // After the scan, hand off the data and show success
    window.setTimeout(() => {
      onCapture(text);
      setPhase("success");
    }, 820);

    // Then return to idle
    window.setTimeout(() => {
      setPhase("idle");
      setParticles([]);
    }, 2200);
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const text = e.clipboardData.getData("text");
    if (!text) return;
    e.preventDefault();
    triggerScan(text);
  };

  return (
    <div className="space-y-2">
      <div
        ref={containerRef}
        onPaste={handlePaste}
        tabIndex={0}
        role="textbox"
        aria-label="Câmara de extração — cole os dados do Maps aqui"
        className="hud-chamber animate-hud-pulse relative min-h-[260px] cursor-text select-none focus:outline-none"
      >
        {/* L-shaped corner brackets */}
        <span className="hud-corner tl" />
        <span className="hud-corner tr" />
        <span className="hud-corner bl" />
        <span className="hud-corner br" />

        {/* Hidden textarea capturing keyboard paste / typing-paste */}
        <textarea
          ref={hiddenInputRef}
          value=""
          onChange={() => {
            /* never store */
          }}
          onPaste={handlePaste}
          aria-hidden="true"
          tabIndex={-1}
          className="absolute inset-0 z-10 h-full w-full cursor-text resize-none bg-transparent p-4 text-transparent caret-transparent outline-none"
        />

        {/* Center content depending on phase */}
        <div className="relative z-[1] flex min-h-[260px] flex-col items-center justify-center gap-3 px-6 py-10 text-center">
          {phase === "idle" && (
            <>
              <div className="relative">
                <Zap
                  className="h-12 w-12 text-primary"
                  style={{ filter: "drop-shadow(0 0 14px hsl(var(--primary)))" }}
                  strokeWidth={1.5}
                />
                <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-primary/30 blur-md" />
              </div>
              <p className="font-mono text-sm font-bold uppercase tracking-[0.32em] text-primary">
                Nova consulta · Aguardando dados
              </p>
              <p className="max-w-md font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                Cole aqui (Ctrl + V) o conteúdo copiado do <b className="text-foreground">card do estabelecimento</b> no Google Maps
              </p>
              <p className="mt-1 font-mono text-[10px] tracking-wider text-muted-foreground/70">
                Nome · categoria · rating · telefone · site são extraídos automaticamente
              </p>
            </>
          )}

          {phase === "scanning" && (
            <>
              <ScanLine
                className="h-9 w-9 text-primary"
                style={{ filter: "drop-shadow(0 0 10px hsl(var(--primary)))" }}
                strokeWidth={1.5}
              />
              <p className="font-mono text-[11px] font-bold uppercase tracking-[0.28em] text-primary">
                Escaneando…
              </p>
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Filtrando dados relevantes
              </p>
            </>
          )}

          {phase === "success" && (
            <div className="flex flex-col items-center gap-2 animate-hud-success">
              <CheckCircle2
                className="h-9 w-9 text-primary"
                style={{ filter: "drop-shadow(0 0 10px hsl(var(--primary)))" }}
                strokeWidth={1.8}
              />
              <p className="font-mono text-[11px] font-bold uppercase tracking-[0.28em] text-primary">
                Dados extraídos com sucesso
              </p>
            </div>
          )}
        </div>

        {/* Laser sweep */}
        {phase === "scanning" && <span className="hud-laser animate-hud-laser" />}

        {/* Binary particles */}
        {phase === "scanning" &&
          particles.map((p) => (
            <span
              key={p.id}
              className="hud-particle animate-hud-rise"
              style={{
                left: `${p.left}%`,
                bottom: "12px",
                animationDelay: `${p.delay}ms`,
              }}
            >
              {p.char}
            </span>
          ))}
      </div>

      {footer}
    </div>
  );
}
