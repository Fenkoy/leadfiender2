-- 1. Coluna is_admin
alter table public.profiles add column if not exists is_admin boolean not null default false;

-- 2. Marca admin pelo e-mail
update public.profiles set is_admin = true where lower(email) = 'gabrieleitejesus@gmail';

-- 3. Atualiza trigger para marcar admin no signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  _is_admin boolean := lower(new.email) = 'gabrieleitejesus@gmail';
begin
  insert into public.profiles (id, full_name, email, is_admin)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', ''),
    new.email,
    _is_admin
  )
  on conflict (id) do update set is_admin = excluded.is_admin or public.profiles.is_admin;

  insert into public.user_plans (user_id, plan, status)
  values (new.id, case when _is_admin then 'founder'::public.plan_type else 'basic'::public.plan_type end, 'active')
  on conflict (user_id) do nothing;

  insert into public.lead_usage (user_id) values (new.id)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

-- 4. Garantir trigger ativo
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- 5. Função is_admin (security definer, evita recursão de RLS)
create or replace function public.is_admin(_uid uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select is_admin from public.profiles where id = _uid), false);
$$;

-- 6. Policies adicionais para admin lerem tudo
drop policy if exists "profiles_admin_select" on public.profiles;
create policy "profiles_admin_select" on public.profiles
  for select to authenticated using (public.is_admin());

drop policy if exists "user_plans_admin_select" on public.user_plans;
create policy "user_plans_admin_select" on public.user_plans
  for select to authenticated using (public.is_admin());

drop policy if exists "lead_usage_admin_select" on public.lead_usage;
create policy "lead_usage_admin_select" on public.lead_usage
  for select to authenticated using (public.is_admin());

-- 7. RPC: listar todos usuários (admin only)
create or replace function public.admin_list_users()
returns table (
  user_id uuid,
  email text,
  full_name text,
  is_admin boolean,
  plan public.plan_type,
  leads_used_today integer,
  last_reset_date date,
  created_at timestamptz
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden';
  end if;
  return query
    select
      p.id,
      p.email,
      p.full_name,
      p.is_admin,
      coalesce(up.plan, 'basic'::public.plan_type),
      coalesce(case when lu.last_reset_date = current_date then lu.leads_used_today else 0 end, 0),
      coalesce(lu.last_reset_date, current_date),
      p.created_at
    from public.profiles p
    left join public.user_plans up on up.user_id = p.id
    left join public.lead_usage lu on lu.user_id = p.id
    order by p.created_at desc;
end;
$$;

-- 8. RPC: alterar plano de qualquer usuário
create or replace function public.admin_set_plan(_user_id uuid, _plan public.plan_type)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden';
  end if;
  insert into public.user_plans (user_id, plan, status)
  values (_user_id, _plan, 'active')
  on conflict (user_id) do update
    set plan = excluded.plan,
        status = 'active',
        current_period_end = case when excluded.plan = 'founder' then null else public.user_plans.current_period_end end,
        updated_at = now();
  return true;
end;
$$;

-- 9. RPC: resetar leads de um usuário
create or replace function public.admin_reset_leads(_user_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden';
  end if;
  insert into public.lead_usage (user_id, leads_used_today, last_reset_date, updated_at)
  values (_user_id, 0, current_date, now())
  on conflict (user_id) do update
    set leads_used_today = 0,
        last_reset_date = current_date,
        updated_at = now();
  return true;
end;
$$;

-- 10. RPC: deletar usuário
create or replace function public.admin_delete_user(_user_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden';
  end if;
  if _user_id = auth.uid() then
    raise exception 'cannot delete self';
  end if;
  delete from auth.users where id = _user_id;
  return true;
end;
$$;