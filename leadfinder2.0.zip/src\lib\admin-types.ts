// Admin types — shared across all admin components

export type Plan = "founder" | "basic" | "pro";
export type UserStatus = "active" | "trial" | "suspended" | "banned";
export type UserRole = "root" | "admin" | "support" | "finance" | "user";

export type AdminUser = {
  user_id: string;
  email: string | null;
  full_name: string | null;
  is_admin: boolean;
  plan: Plan;
  status: UserStatus;
  role: UserRole;
  leads_used_today: number;
  leads_used_week: number;
  leads_used_month: number;
  leads_limit: number;
  last_reset_date: string;
  last_login_at: string | null;
  tags: string[];
  created_at: string;
  total_count: number;
};

export type UserLog = {
  id: string;
  action: string;
  performed_by: string;
  metadata: Record<string, unknown>;
  created_at: string;
};

export type AdminStats = {
  total_users: number;
  active_users: number;
  trial_users: number;
  suspended_users: number;
  banned_users: number;
  basic_plans: number;
  pro_plans: number;
  founder_plans: number;
  total_leads_today: number;
  inactive_7d: number;
};

export const PLAN_CONFIG: Record<Plan, { label: string; color: string; bgClass: string; leadsPerDay: number }> = {
  founder: { label: "Founder", color: "text-amber-400", bgClass: "bg-amber-500/15 text-amber-400 border-amber-500/30", leadsPerDay: 999999 },
  pro:     { label: "Pro",     color: "text-violet-400", bgClass: "bg-violet-500/15 text-violet-400 border-violet-500/30", leadsPerDay: 100 },
  basic:   { label: "Basic",   color: "text-slate-400", bgClass: "bg-slate-500/15 text-slate-400 border-slate-500/30", leadsPerDay: 30 },
};

export const STATUS_CONFIG: Record<UserStatus, { label: string; color: string; bgClass: string; dot: string }> = {
  active:    { label: "Ativo",     color: "text-emerald-400", bgClass: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30", dot: "bg-emerald-400" },
  trial:     { label: "Trial",     color: "text-yellow-400",  bgClass: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30", dot: "bg-yellow-400" },
  suspended: { label: "Suspenso",  color: "text-red-400",     bgClass: "bg-red-500/15 text-red-400 border-red-500/30", dot: "bg-red-400" },
  banned:    { label: "Banido",    color: "text-zinc-500",    bgClass: "bg-zinc-600/15 text-zinc-400 border-zinc-600/30", dot: "bg-zinc-500" },
};

export const ROLE_CONFIG: Record<UserRole, { label: string; icon: string }> = {
  root:    { label: "Root",    icon: "👑" },
  admin:   { label: "Admin",   icon: "🛡️" },
  support: { label: "Suporte", icon: "🎧" },
  finance: { label: "Finanças", icon: "💰" },
  user:    { label: "Usuário", icon: "👤" },
};

export const ACTION_LABELS: Record<string, string> = {
  PLAN_CHANGED: "Plano alterado",
  STATUS_CHANGED: "Status alterado",
  LEADS_RESET: "Leads resetados",
  USER_DELETED: "Usuário deletado",
  USER_UPDATED: "Usuário atualizado",
  TAG_ADDED: "Tag adicionada",
  TAG_REMOVED: "Tag removida",
  PASSWORD_RESET: "Senha resetada",
  USER_CREATED: "Usuário criado",
};

export const TAG_PRESETS = [
  "High Value",
  "Early Adopter",
  "Test",
  "Buggy",
  "VIP",
  "Churn Risk",
  "Enterprise",
] as const;
