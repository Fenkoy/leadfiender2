import { useEffect, useState } from "react";
import { Check, Crown, Zap, Sparkles } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { trackEvent } from "@/lib/plans";
import { useNavigate } from "react-router-dom";

type Slots = { total_slots: number; claimed: number };

export default function Pricing() {
  const { user, plan, refresh } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [slots, setSlots] = useState<Slots | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from("founder_slots")
      .select("total_slots, claimed")
      .eq("id", 1)
      .maybeSingle()
      .then(({ data }) => data && setSlots(data));
  }, []);

  const founderRemaining = slots ? slots.total_slots - slots.claimed : null;

  const claimFounder = async () => {
    if (!user) return navigate("/auth");
    setBusy("founder");
    const { data, error } = await supabase.rpc("claim_founder");
    setBusy(null);
    if (error || !data) {
      toast({
        title: "Vagas esgotadas",
        description: "Os 50 lugares fundadores acabaram. Confira PRO ou Basic.",
        variant: "destructive",
      });
      return;
    }
    toast({ title: "🎉 Bem-vindo, Founder!", description: "Acesso vitalício liberado." });
    await refresh();
    navigate("/");
  };

  const startCheckout = async (target: "basic" | "pro") => {
    if (!user) return navigate("/auth");
    await trackEvent("checkout_started", undefined, { plan: target });
    toast({
      title: "Em breve",
      description: "O checkout Stripe será ativado na próxima atualização. Por enquanto, fale com o suporte.",
    });
  };

  const PlanCard = ({
    id,
    name,
    price,
    period,
    badge,
    icon,
    highlight,
    features,
    cta,
    onClick,
    disabled,
  }: {
    id: string;
    name: string;
    price: string;
    period: string;
    badge?: string;
    icon: React.ReactNode;
    highlight?: boolean;
    features: { ok: boolean; text: string }[];
    cta: string;
    onClick: () => void;
    disabled?: boolean;
  }) => (
    <div
      className={`relative flex flex-col rounded-lg border p-6 ${
        highlight
          ? "border-primary bg-primary/5 shadow-[0_0_24px_hsl(var(--primary)/0.25)]"
          : "border-border bg-card"
      }`}
    >
      {badge && (
        <span className="absolute -top-3 left-6 rounded-full bg-primary px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
          {badge}
        </span>
      )}
      <div className="mb-3 flex items-center gap-2">
        {icon}
        <h3 className="text-lg font-bold">{name}</h3>
      </div>
      <div className="mb-1">
        <span className="text-3xl font-extrabold">{price}</span>
        <span className="ml-1 text-sm text-muted-foreground">{period}</span>
      </div>
      <ul className="mt-4 flex-1 space-y-2 text-sm">
        {features.map((f, i) => (
          <li key={i} className={`flex items-start gap-2 ${f.ok ? "" : "text-muted-foreground line-through"}`}>
            <Check className={`mt-0.5 h-4 w-4 shrink-0 ${f.ok ? "text-primary" : "text-muted-foreground"}`} />
            <span>{f.text}</span>
          </li>
        ))}
      </ul>
      <Button
        className="mt-5 w-full"
        variant={highlight ? "default" : "outline"}
        disabled={disabled || busy === id}
        onClick={onClick}
      >
        {busy === id ? "Processando..." : cta}
      </Button>
      {plan === id && (
        <p className="mt-2 text-center text-[10px] uppercase tracking-widest text-primary">Seu plano atual</p>
      )}
    </div>
  );

  return (
    <AppShell>
      <main className="relative z-10 mx-auto max-w-5xl px-4 py-10">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-extrabold tracking-tight">Escolha seu plano</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Comece grátis. Suba para PRO quando precisar de mais leads e os scripts completos.
          </p>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          <PlanCard
            id="basic"
            name="Basic"
            price="Grátis"
            period=""
            icon={<Zap className="h-5 w-5 text-muted-foreground" />}
            features={[
              { ok: true, text: "30 leads por dia" },
              { ok: true, text: "Workbench completo" },
              { ok: true, text: "1 script de abordagem por dia" },
              { ok: false, text: "Cronograma de conteúdo" },
              { ok: false, text: "Prompts avançados (tráfego, AIDA)" },
            ]}
            cta={plan === "basic" ? "Plano atual" : "Começar grátis"}
            onClick={() => (user ? navigate("/") : navigate("/auth"))}
            disabled={plan === "basic"}
          />

          <PlanCard
            id="pro"
            name="Pro"
            price="R$ 97"
            period="/mês"
            badge="Mais popular"
            highlight
            icon={<Sparkles className="h-5 w-5 text-primary" />}
            features={[
              { ok: true, text: "100 leads por dia" },
              { ok: true, text: "Todos os scripts (9 tons × 5 canais)" },
              { ok: true, text: "Cronograma de conteúdo (30 dias)" },
              { ok: true, text: "Prompts avançados (Meta, Google, Reels)" },
              { ok: true, text: "Suporte prioritário" },
            ]}
            cta={plan === "pro" ? "Plano atual" : "Assinar PRO"}
            onClick={() => startCheckout("pro")}
            disabled={plan === "pro"}
          />

          <PlanCard
            id="founder"
            name="Founder"
            price="R$ 50"
            period="vitalício"
            badge={founderRemaining !== null ? `${founderRemaining}/50 vagas` : undefined}
            icon={<Crown className="h-5 w-5 text-yellow-500" />}
            features={[
              { ok: true, text: "Acesso vitalício a tudo" },
              { ok: true, text: "Leads ilimitados" },
              { ok: true, text: "Todas as features atuais e futuras" },
              { ok: true, text: "Selo de Fundador" },
              { ok: true, text: "Roadmap influence" },
            ]}
            cta={
              plan === "founder"
                ? "Você é Founder 🎉"
                : founderRemaining === 0
                  ? "Esgotado"
                  : "Garantir vaga vitalícia"
            }
            onClick={claimFounder}
            disabled={plan === "founder" || founderRemaining === 0}
          />
        </div>

        <p className="mt-8 text-center text-xs text-muted-foreground">
          Pagamento real do PRO/Founder será habilitado na próxima atualização (integração Stripe).
        </p>
      </main>
    </AppShell>
  );
}
