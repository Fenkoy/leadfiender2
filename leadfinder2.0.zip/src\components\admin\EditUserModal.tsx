import { useState } from "react";
import { AdminUser, Plan, UserStatus, UserRole, PLAN_CONFIG, STATUS_CONFIG } from "@/lib/admin-types";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type Props = {
  user: AdminUser | null;
  open: boolean;
  onClose: () => void;
  onSave: (uid: string, data: { full_name?: string; status?: UserStatus; role?: UserRole; leads_limit?: number; plan?: Plan }) => void;
};

export default function EditUserModal({ user, open, onClose, onSave }: Props) {
  const [name, setName] = useState("");
  const [status, setStatus] = useState<UserStatus>("active");
  const [role, setRole] = useState<UserRole>("user");
  const [plan, setPlan] = useState<Plan>("basic");
  const [leadsLimit, setLeadsLimit] = useState(30);
  const [saving, setSaving] = useState(false);

  // Sync state when user changes
  const resetForm = () => {
    if (user) {
      setName(user.full_name ?? "");
      setStatus(user.status);
      setRole(user.role);
      setPlan(user.plan);
      setLeadsLimit(user.leads_limit >= 999999 ? 999999 : user.leads_limit);
    }
  };

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    await onSave(user.user_id, {
      full_name: name !== (user.full_name ?? "") ? name : undefined,
      status: status !== user.status ? status : undefined,
      role: role !== user.role ? role : undefined,
      leads_limit: leadsLimit !== user.leads_limit ? leadsLimit : undefined,
      plan: plan !== user.plan ? plan : undefined,
    });
    setSaving(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); else resetForm(); }}>
      <DialogContent className="max-w-md border-border bg-card" onOpenAutoFocus={() => resetForm()}>
        <DialogHeader>
          <DialogTitle className="text-lg">Editar Usuário</DialogTitle>
          <p className="text-xs text-muted-foreground">{user?.email}</p>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Name */}
          <div className="space-y-1.5">
            <Label htmlFor="edit-name" className="text-xs">Nome</Label>
            <Input id="edit-name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>

          {/* Plan */}
          <div className="space-y-1.5">
            <Label className="text-xs">Plano</Label>
            <div className="flex gap-2">
              {(Object.keys(PLAN_CONFIG) as Plan[]).map((p) => (
                <button
                  key={p}
                  onClick={() => {
                    setPlan(p);
                    setLeadsLimit(PLAN_CONFIG[p].leadsPerDay);
                  }}
                  className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium transition-all ${
                    plan === p ? PLAN_CONFIG[p].bgClass + " shadow-md" : "border-border text-muted-foreground hover:border-border/80"
                  }`}
                >
                  {PLAN_CONFIG[p].label}
                </button>
              ))}
            </div>
          </div>

          {/* Status */}
          <div className="space-y-1.5">
            <Label className="text-xs">Status</Label>
            <div className="flex gap-2">
              {(Object.keys(STATUS_CONFIG) as UserStatus[]).map((s) => (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium transition-all ${
                    status === s ? STATUS_CONFIG[s].bgClass + " shadow-md" : "border-border text-muted-foreground hover:border-border/80"
                  }`}
                >
                  {STATUS_CONFIG[s].label}
                </button>
              ))}
            </div>
          </div>

          {/* Role */}
          <div className="space-y-1.5">
            <Label htmlFor="edit-role" className="text-xs">Cargo</Label>
            <select
              id="edit-role"
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
            >
              <option value="user">Usuário</option>
              <option value="support">Suporte</option>
              <option value="finance">Finanças</option>
              <option value="admin">Admin</option>
              <option value="root">Root</option>
            </select>
          </div>

          {/* Leads limit */}
          <div className="space-y-1.5">
            <Label htmlFor="edit-leads" className="text-xs">Limite de leads/dia</Label>
            <Input
              id="edit-leads"
              type="number"
              min={0}
              value={leadsLimit >= 999999 ? "" : leadsLimit}
              placeholder="∞ (ilimitado)"
              onChange={(e) => setLeadsLimit(e.target.value ? Number(e.target.value) : 999999)}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancelar</Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? "Salvando..." : "Salvar Alterações"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
