import { useEffect, useMemo, useRef, useState } from "react";
import {
  Briefcase,
  Flame,
  Snowflake,
  Plus,
  Trash2,
  ExternalLink,
  MessageSquare,
  Copy,
  Link as LinkIcon,
  ClipboardCheck,
  TrendingUp,
  History,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { NICHES } from "@/lib/niches";
import { ExtractionChamber } from "@/components/ExtractionChamber";
import { useGate } from "@/hooks/useGate";


export type Language = "pt" | "es" | "en";
const LANGUAGES: { code: Language; flag: string; label: string }[] = [
  { code: "pt", flag: "🇧🇷", label: "PT" },
  { code: "es", flag: "🇪🇸", label: "ES" },
  { code: "en", flag: "🇺🇸", label: "EN" },
];

export interface Lead {
  id: string;
  name: string;
  niche: string;
  customNiche: string;
  category: string;
  rating: number | "";
  reviews: number | "";
  mapsUrl: string;
  ddi: string;
  whatsapp: string;
  hasWebsite: boolean;
  hasGbpOptimized: boolean;
  hasInstagramLink: boolean;
  hasProfessionalPhotos: boolean;
  respondsReviews: boolean;
  notes: string;
  // Abordagem personalizada (mesclada do antigo card "Abordagem WhatsApp")
  contactName: string;
  problem: string;
  solution: string;
  differential: string;
  goal: string;
  contacted: boolean;
  status: LeadStatus;
  // Dados de fechamento (preenchidos via modal quando status vira "fechado")
  contractValue?: number;
  contractService?: string;
  closedAt?: number;
  createdAt: number;
}

export type LeadStatus = "novo" | "andamento" | "fechado" | "perdido";

const STATUS_META: Record<LeadStatus, { label: string; color: string; dot: string }> = {
  novo: {
    label: "NOVA CONSULTA",
    color: "bg-blue-500/15 text-blue-300 border-blue-500/40",
    dot: "bg-blue-400",
  },
  andamento: {
    label: "EM ANDAMENTO",
    color: "bg-amber-500/15 text-amber-300 border-amber-500/40",
    dot: "bg-amber-400",
  },
  fechado: {
    label: "FECHADO ✓",
    color: "bg-emerald-500/15 text-emerald-300 border-emerald-500/40",
    dot: "bg-emerald-400",
  },
  perdido: {
    label: "PERDIDO",
    color: "bg-zinc-500/15 text-zinc-400 border-zinc-500/40",
    dot: "bg-zinc-500",
  },
};

const STORAGE_KEY = "lc_leads_v1";
const ACTIVITY_KEY = "lc_lead_activity_v1";

export const SERVICES = [
  "Sites / Landing Pages",
  "Vídeos / VSL",
  "Identidade Visual",
  "Gestão de Tráfego",
  "Social Media",
  "Outros",
] as const;
export type ServiceType = (typeof SERVICES)[number];

export type ActivityKind = "added" | "contacted" | "removed";
export interface ActivityEntry {
  id: string;
  kind: ActivityKind;
  leadName: string;
  niche: string;
  ts: number;
}

// Keys must match NICHES ids in src/lib/niches.ts
const nicheCopy: Record<string, string> = {
  restaurante:
    "Já ajudei restaurantes a aumentar as reservas em até 40% com cardápio digital + presença no Google Maps otimizada.",
  pizzaria:
    "Já ajudei pizzarias a aumentar os pedidos em 30% criando cardápio digital com pedido direto pelo WhatsApp.",
  hamburgueria:
    "Já ajudei hamburguerias a dobrar os pedidos no fim de semana com menu digital + campanha local segmentada.",
  barbearia:
    "Já ajudei barbearias a lotar a agenda com um sistema simples de agendamento online + Instagram organizado.",
  salao:
    "Já ajudei salões de beleza a reduzir faltas em 60% com agendamento automático + lembretes pelo WhatsApp.",
  estetica:
    "Já ajudei clínicas de estética a transformar curiosos em pacientes pagantes com landing page de orçamento + WhatsApp integrado.",
  nutricao:
    "Já ajudei nutricionistas a fechar mais consultas particulares com site profissional + área de planos online.",
  psicologia:
    "Já ajudei psicólogos(as) a construir presença online sólida para atender particular sem depender só de indicação.",
  terapia:
    "Já ajudei terapeutas a estruturar a presença digital com site profissional + agendamento direto pelo WhatsApp.",
  perfumaria:
    "Já ajudei perfumarias a aumentar as vendas com vitrine digital integrada ao WhatsApp.",
  outros: "",
};

// Aberturas/fechamentos por tom — modulam só a "casca" da mensagem,
// mantendo o miolo consultivo (oportunidade + curiosidade + CTA leve).
function openingByTone(
  tone: Tone,
  lang: "pt" | "es" | "en",
  sender: string,
  company: string,
  ratingLine: string,
  hi: string
): string {
  if (lang === "en") {
    switch (tone) {
      case "formal":
        return `${hi}, I hope this message finds you well.\n\nMy name is ${sender}, and I'm reaching out regarding ${company}${ratingLine}.`;
      case "formal-casual":
        return `${hi}, hope you're doing well.\n\nMy name is ${sender} — I'll be quick and to the point.`;
      case "formal-direto":
        return `${hi}.\n\nMy name is ${sender}. Sending a short note about ${company}${ratingLine}.`;
      case "casual":
        return `${hi}! 😊\n\nI'm ${sender}, nice to meet you. I came across ${company}${ratingLine} and wanted to drop you a quick line.`;
      case "casual-formal":
        return `${hi} 👋\n\nI'm ${sender}, nice to meet you. Quick context before anything:`;
      case "casual-direto":
        return `${hi}! 👋 ${sender} here.`;
      case "direto":
        return `${hi}. ${sender} here — straight to the point.`;
      case "direto-casual":
        return `${hi}, ${sender} here — going straight to the point.`;
      case "direto-formal":
        return `${hi}. I'm ${sender}.`;
    }
  }
  if (lang === "es") {
    switch (tone) {
      case "formal":
        return `${hi}, espero que se encuentre muy bien.\n\nMi nombre es ${sender} y le escribo respecto a ${company}${ratingLine}.`;
      case "formal-casual":
        return `${hi}, espero que esté todo bien.\n\nSoy ${sender} — voy a ser breve y al punto.`;
      case "formal-direto":
        return `${hi}.\n\nSoy ${sender}. Te escribo en pocas líneas sobre ${company}${ratingLine}.`;
      case "casual":
        return `${hi}! 😊\n\nSoy ${sender}, gusto en saludarte. Vi ${company}${ratingLine} y quise mandarte un mensaje rápido.`;
      case "casual-formal":
        return `${hi} 👋\n\nSoy ${sender}, gusto en saludarte. Un contexto rápido:`;
      case "casual-direto":
        return `${hi}! 👋 Acá ${sender}.`;
      case "direto":
        return `${hi}. ${sender} aquí — directo al grano.`;
      case "direto-casual":
        return `${hi}, soy ${sender} — voy directo al grano.`;
      case "direto-formal":
        return `${hi}. Soy ${sender}.`;
    }
  }
  // PT
  switch (tone) {
    case "formal":
      return `${hi}, espero que esteja muito bem.\n\nMeu nome é ${sender} e venho lhe escrever a respeito da ${company}${ratingLine}.`;
    case "formal-casual":
      return `${hi}, espero que esteja tudo bem por aí.\n\nMeu nome é ${sender} — vou ser breve e objetivo.`;
    case "formal-direto":
      return `${hi}.\n\nMeu nome é ${sender}. Te escrevo em poucas linhas sobre a ${company}${ratingLine}.`;
    case "casual":
      return `${hi}! 😊\n\nAqui é o ${sender}, prazer. Dei uma olhada na ${company}${ratingLine} e resolvi te chamar rapidinho.`;
    case "casual-formal":
      return `${hi} 👋\n\nSou ${sender}, prazer. Um contexto rápido antes de qualquer coisa:`;
    case "casual-direto":
      return `${hi}! 👋 Aqui é o ${sender}.`;
    case "direto":
      return `${hi}. Aqui é o ${sender} — vou direto ao ponto.`;
    case "direto-casual":
      return `${hi}, aqui é o ${sender} — já vou direto ao ponto.`;
    case "direto-formal":
      return `${hi}. Sou ${sender}.`;
  }
}

function closingByTone(tone: Tone, lang: "pt" | "es" | "en", sender: string): string {
  if (lang === "en") {
    switch (tone) {
      case "formal":
        return `Should this be of interest, I would be glad to share a brief 2-minute overview tailored to your business, at your convenience.\n\nKind regards,\n${sender}`;
      case "formal-casual":
        return `If it makes sense, I can show you in 2 minutes how this would apply specifically to your business — no commitment.\n\nBest,\n${sender}`;
      case "formal-direto":
        return `Would you have 2 minutes this week to look at this together?\n\nBest,\n${sender}`;
      case "casual":
        return `If you're up for it, I can send you a quick 2-min walkthrough made just for your business. Sound good?`;
      case "casual-formal":
        return `If you're curious, I can send a quick 2-minute breakdown specifically for your business. Want me to send it over?`;
      case "casual-direto":
        return `Want me to send a quick 2-minute walkthrough for your business? Just say the word 🙌`;
      case "direto":
        return `Yes or no: do I send the 2-min breakdown for your business?`;
      case "direto-casual":
        return `Quick yes/no: want me to send the 2-min breakdown for your business?`;
      case "direto-formal":
        return `Can I send you a 2-minute breakdown specifically for your business this week?`;
    }
  }
  if (lang === "es") {
    switch (tone) {
      case "formal":
        return `Si fuera de su interés, con gusto le comparto un breve análisis de 2 minutos hecho específicamente para su negocio.\n\nCordialmente,\n${sender}`;
      case "formal-casual":
        return `Si tiene sentido, te muestro en 2 minutos cómo aplicarlo específicamente a tu negocio — sin compromiso.\n\nSaludos,\n${sender}`;
      case "formal-direto":
        return `¿Tendrías 2 minutos esta semana para verlo juntos?\n\nSaludos,\n${sender}`;
      case "casual":
        return `Si te late, te paso un análisis rápido de 2 min hecho para tu negocio. ¿Va?`;
      case "casual-formal":
        return `Si te genera curiosidad, te paso un análisis rápido de 2 minutos específico para tu negocio. ¿Te mando?`;
      case "casual-direto":
        return `¿Te mando un análisis rápido de 2 min para tu negocio? Solo dime 🙌`;
      case "direto":
        return `Sí o no: ¿te mando el análisis de 2 min para tu negocio?`;
      case "direto-casual":
        return `Sí o no: ¿te mando el análisis de 2 min para tu negocio?`;
      case "direto-formal":
        return `¿Puedo enviarte un análisis de 2 minutos específico para tu negocio esta semana?`;
    }
  }
  // PT
  switch (tone) {
    case "formal":
      return `Caso seja de interesse, terei satisfação em compartilhar um breve diagnóstico de 2 minutos preparado especificamente para o seu negócio.\n\nCordialmente,\n${sender}`;
    case "formal-casual":
      return `Se fizer sentido, posso te mostrar em 2 minutos como isso se aplicaria especificamente ao seu negócio — sem compromisso.\n\nFico à disposição,\n${sender}`;
    case "formal-direto":
      return `Você teria 2 minutos esta semana para a gente olhar isso junto?\n\nAtenciosamente,\n${sender}`;
    case "casual":
      return `Se topar, te mando um diagnóstico rápido de 2 min feito pro seu negócio. Pode ser?`;
    case "casual-formal":
      return `Se gerou curiosidade, posso te mandar um diagnóstico rápido de 2 minutos específico pro seu negócio. Posso enviar?`;
    case "casual-direto":
      return `Quer que eu te mande um diagnóstico rápido de 2 min pro seu negócio? Só falar 🙌`;
    case "direto":
      return `Sim ou não: te mando o diagnóstico de 2 min pro seu negócio?`;
    case "direto-casual":
      return `Sim ou não: te mando o diagnóstico de 2 min pro seu negócio?`;
    case "direto-formal":
      return `Posso te enviar um diagnóstico de 2 minutos específico pro seu negócio ainda esta semana?`;
  }
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function leadScore(l: Lead): { score: number; tier: "hot" | "warm" | "cold" } {
  const rating = typeof l.rating === "number" ? l.rating : 0;
  const reviews = typeof l.reviews === "number" ? l.reviews : 0;
  // Heat = stars × log(reviews) × (no website bonus)
  const reviewWeight = reviews > 0 ? Math.min(Math.log10(reviews + 1) * 35, 100) : 0;
  const ratingWeight = (rating / 5) * 60;
  const noSiteBonus = l.hasWebsite ? 0 : 25;
  const raw = ratingWeight * 0.5 + reviewWeight * 0.5 + noSiteBonus;
  const score = Math.round(Math.min(raw, 100));
  let tier: "hot" | "warm" | "cold" = "cold";
  if (score >= 70) tier = "hot";
  else if (score >= 40) tier = "warm";
  return { score, tier };
}

function extractFromMapsUrl(
  url: string,
  pageText: string = ""
): {
  name?: string;
  coords?: string;
  rating?: number;
  reviews?: number;
  whatsapp?: string;
  hasWebsite?: boolean;
  category?: string;
} {
  const result: ReturnType<typeof extractFromMapsUrl> = {};
  // ---- URL parsing ----
  try {
    const u = new URL(url);
    const placeMatch = u.pathname.match(/\/place\/([^/@]+)/);
    if (placeMatch) {
      result.name = decodeURIComponent(placeMatch[1].replace(/\+/g, " "));
    }
    const coordMatch = u.pathname.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
    if (coordMatch) result.coords = `${coordMatch[1]},${coordMatch[2]}`;
  } catch {
    /* invalid URL — pageText fallback continues */
  }

  // ---- Page-text parsing (when user pastes content from the Maps page) ----
  const text = pageText || "";
  if (text) {
    // Known categories first — they help anchor the business name (which usually appears right above)
    const knownCategories = [
      "Salão de Beleza", "Salao de Beleza", "Restaurante", "Pizzaria", "Hamburgueria", "Lanchonete",
      "Barbearia", "Clínica de estética", "Clinica de estetica", "Spa", "Nutricionista", "Psicólogo",
      "Psicóloga", "Terapeuta", "Perfumaria", "Cafeteria", "Padaria", "Açaiteria",
      "Loja de roupas", "Petshop", "Pet shop", "Academia", "Estúdio de pilates",
      "Dentista", "Advogado", "Contador", "Studio", "Estúdio",
    ];
    for (const cat of knownCategories) {
      const re = new RegExp(`\\b${cat.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i");
      if (re.test(text)) {
        result.category = cat;
        break;
      }
    }

    const lines = text
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    // Build skip patterns — Maps UI noise + the search query line ("Salões de Beleza em Rio Grande...")
    const uiSkip = /^(resultados|pesquisar|menu|salvar|compartilhar|nas proximidades|enviar para o telefone|directions|search|nearby|share|save|send to phone|patrocinado|sponsored|sobre|reviews|avaliaç|fotos|photos|visão geral|overview|rotas|próximo|seu histórico|adicionar marcador|sugerir mudança|copiado|aberto|fechado|fecha|abre)/i;
    const looksLikeMeta = (s: string) => {
      if (s.length < 2 || s.length > 80) return true;
      if (/^\d/.test(s)) return true; // ratings/addresses/phones starting with digits
      if (/^https?:/i.test(s)) return true;
      if (/^\(?\+?\d/.test(s)) return true; // phone
      if (/^[★☆⭐•·–—-]+/.test(s)) return true;
      if (uiSkip.test(s)) return true;
      // The search query line is usually "<categoria plural> em <cidade>" — skip it
      if (/\b(em|in)\s+[A-ZÀ-Ú]/.test(s) && /(salões|saloes|restaurantes|pizzarias|barbearias|clínicas|clinicas|estúdios|estudios|lojas|hamburguerias|cafeterias|padarias|nutricionistas|psicólogos|psicologos|terapeutas|perfumarias)/i.test(s)) {
        return true;
      }
      return false;
    };

    if (!result.name) {
      // Strategy 1: line right BEFORE the detected category
      if (result.category) {
        const catIdx = lines.findIndex((l) => l.toLowerCase() === result.category!.toLowerCase());
        if (catIdx > 0) {
          // walk upward looking for first non-meta line
          for (let i = catIdx - 1; i >= 0; i--) {
            if (!looksLikeMeta(lines[i])) {
              result.name = lines[i];
              break;
            }
          }
        }
      }
      // Strategy 2: first non-meta line otherwise
      if (!result.name) {
        const candidate = lines.find((l) => !looksLikeMeta(l));
        if (candidate) result.name = candidate;
      }
    }

    // Rating + reviews — handle "5,0★★★★★(43)" or "4,6 (123)" or "4.6 stars"
    const ratingNear =
      text.match(/(\d[.,]\d)\s*[★⭐]+\s*\(\s*([\d.]+)\s*\)/) ||
      text.match(/(\d[.,]\d)\s*\(\s*([\d.]+)\s*\)/) ||
      text.match(/(\d[.,]\d)\s*estrela/i) ||
      text.match(/(\d[.,]\d)\s*star/i);
    if (ratingNear) {
      const r = parseFloat(ratingNear[1].replace(",", "."));
      if (r >= 0 && r <= 5) result.rating = r;
      if (ratingNear[2]) {
        const n = parseInt(ratingNear[2].replace(/\D/g, ""), 10);
        if (!Number.isNaN(n)) result.reviews = n;
      }
    }
    // Reviews count alone (e.g. "109 avaliações")
    if (result.reviews === undefined) {
      const rev = text.match(/([\d.]+)\s*(?:avaliaç|review|comentár)/i);
      if (rev) {
        const n = parseInt(rev[1].replace(/\D/g, ""), 10);
        if (!Number.isNaN(n)) result.reviews = n;
      }
    }
    // Phone: BR formats like "(84) 2040-4040" or "+55 11 99999-8888"
    const phone =
      text.match(/\+\s*55[\s-]*\(?\d{2}\)?[\s-]*9?\d{4}[\s-]?\d{4}/) ||
      text.match(/\(\s*\d{2}\s*\)\s*9?\d{4}[\s-]?\d{4}/) ||
      text.match(/\b\d{2}\s*9?\d{4}[\s-]?\d{4}\b/);
    if (phone) {
      const digits = phone[0].replace(/\D/g, "");
      if (digits.length >= 10) {
        result.whatsapp = digits.startsWith("55") ? digits : `55${digits}`;
      }
    }
    // Website / link presence detection.
    // Maps lists qualquer link externo do estabelecimento na coluna lateral:
    // site próprio, cardápio (shre.ink, linktr.ee, etc), Instagram, Facebook,
    // WhatsApp link (wa.me / api.whatsapp). Tudo isso conta como "tem presença web".
    const hasExternalUrl = /https?:\/\/(?!.*\.?(google\.com|goo\.gl|maps\.app|gstatic|googleusercontent))[\w.-]+/i.test(text);
    const hasKnownDomain = /\b(?:[\w-]+\.)?(?:shre\.ink|linktr\.ee|linktree|bit\.ly|wa\.me|api\.whatsapp\.com|whatsapp\.com|instagram\.com|facebook\.com|fb\.com|tiktok\.com|ifood\.com|anota\.ai|goomer|cardapioweb|abrahao\.com|menulux|menudino)\b/i.test(text);
    // Maps mostra labels "Cardápio", "Menu", "Website", "Site", "Pedidos online" quando há um link associado.
    // Quando o estabelecimento NÃO tem website, Maps mostra "Adicionar website" / "Adic. informações ausentes".
    const hasMissingWebsiteLabel = /(adicionar\s+website|add\s+a\s+website|adic\.\s*informa[çc][õo]es\s+ausentes)/i.test(text);
    const hasWebsiteLabel = /(^|\n)\s*(?:cardápio|cardapio|menu|website|site|pedidos online|order online|reservas|reserve)\s*(?:\n|$)/im.test(text);

    if (hasMissingWebsiteLabel && !hasExternalUrl && !hasKnownDomain) {
      result.hasWebsite = false;
    } else if (hasExternalUrl || hasKnownDomain || hasWebsiteLabel) {
      result.hasWebsite = true;
    }
  }

  return result;
}

function guessNicheFromCategory(category?: string): string | undefined {
  if (!category) return undefined;
  const c = category.toLowerCase();
  if (c.includes("salão") || c.includes("salao") || c.includes("beleza")) return "salao";
  if (c.includes("estética") || c.includes("estetica") || c.includes("spa")) return "estetica";
  if (c.includes("pizz")) return "pizzaria";
  if (c.includes("hambur") || c.includes("burger") || c.includes("lanchonete")) return "hamburgueria";
  if (c.includes("restaur") || c.includes("café") || c.includes("cafe") || c.includes("padaria")) return "restaurante";
  if (c.includes("barb")) return "barbearia";
  if (c.includes("nutri")) return "nutricao";
  if (c.includes("psic")) return "psicologia";
  if (c.includes("terap")) return "terapia";
  if (c.includes("perfum")) return "perfumaria";
  return undefined;
}

type Tone =
  | "formal"
  | "formal-casual"
  | "formal-direto"
  | "casual"
  | "casual-formal"
  | "casual-direto"
  | "direto"
  | "direto-casual"
  | "direto-formal";

const TONE_LABELS: Record<Tone, { label: string; emoji: string; hint: string }> = {
  "formal": { emoji: "🎩", label: "Formal", hint: "Estritamente profissional e respeitoso" },
  "formal-casual": { emoji: "🤝", label: "Formal · Casual", hint: "Profissional, com leveza humana" },
  "formal-direto": { emoji: "📐", label: "Formal · Direto", hint: "Profissional, sem rodeios" },
  "casual": { emoji: "💬", label: "Casual", hint: "Conversa próxima e leve" },
  "casual-formal": { emoji: "😎", label: "Casual · Formal", hint: "Próximo, mas com cuidado técnico" },
  "casual-direto": { emoji: "⚡", label: "Casual · Direto", hint: "Próximo e objetivo" },
  "direto": { emoji: "🎯", label: "Direto", hint: "Sem enrolação, foco no ponto" },
  "direto-casual": { emoji: "🔥", label: "Direto · Casual", hint: "Objetivo, com tom de papo" },
  "direto-formal": { emoji: "🧭", label: "Direto · Formal", hint: "Objetivo, com respeito ao tempo" },
};

const TONE_LIST: Tone[] = [
  "formal",
  "formal-casual",
  "formal-direto",
  "casual",
  "casual-formal",
  "casual-direto",
  "direto",
  "direto-casual",
  "direto-formal",
];

interface Props {
  openExternal: (url: string) => void;
}

export function LeadWorkbench({ openExternal }: Props) {
  const { tryConsumeLead } = useGate();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [pasteUrl, setPasteUrl] = useState("");
  const [pasteText, setPasteText] = useState("");
  const [contactedToday, setContactedToday] = useState(0);
  const [senderName, setSenderName] = useState("");
  const [tone, setTone] = useState<Tone>("formal-casual");
  const [activity, setActivity] = useState<ActivityEntry[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [leadsOpen, setLeadsOpen] = useState(true);
  const [language, setLanguage] = useState<Language>("pt");

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed: Array<Partial<Lead>> = JSON.parse(raw);
        // Backward-compat: ensure new fields exist on legacy records
        setLeads(
          parsed.map((l) => ({
            id: l.id ?? uid(),
            name: l.name ?? "",
            niche: l.niche ?? "restaurante",
            customNiche: l.customNiche ?? "",
            category: l.category ?? "",
            rating: l.rating ?? "",
            reviews: l.reviews ?? "",
            mapsUrl: l.mapsUrl ?? "",
            ddi: l.ddi ?? "55",
            whatsapp: l.whatsapp ?? "",
            hasWebsite: l.hasWebsite ?? false,
            hasGbpOptimized: l.hasGbpOptimized ?? false,
            hasInstagramLink: l.hasInstagramLink ?? false,
            hasProfessionalPhotos: l.hasProfessionalPhotos ?? false,
            respondsReviews: l.respondsReviews ?? false,
            notes: l.notes ?? "",
            contactName: l.contactName ?? "",
            problem: l.problem ?? "",
            solution: l.solution ?? "",
            differential: l.differential ?? "",
            goal: l.goal ?? "",
            contacted: l.contacted ?? false,
            status: (l as Partial<Lead>).status ?? "novo",
            contractValue: l.contractValue,
            contractService: l.contractService,
            closedAt: l.closedAt,
            createdAt: l.createdAt ?? Date.now(),
          }))
        );
      }
      const ct = localStorage.getItem("lc_contacted_today");
      const today = new Date().toISOString().slice(0, 10);
      if (ct) {
        const parsed = JSON.parse(ct) as { date: string; count: number };
        if (parsed.date === today) setContactedToday(parsed.count);
      }
      const sn = localStorage.getItem("lc_sender_name");
      if (sn) setSenderName(sn);
      const tn = localStorage.getItem("lc_tone");
      if (tn && (TONE_LIST as string[]).includes(tn)) setTone(tn as Tone);
      const act = localStorage.getItem(ACTIVITY_KEY);
      if (act) setActivity(JSON.parse(act) as ActivityEntry[]);
    } catch {
      /* ignore */
    }
  }, []);

  const logActivity = (kind: ActivityKind, lead: Pick<Lead, "name" | "niche">) => {
    const entry: ActivityEntry = {
      id: uid(),
      kind,
      leadName: lead.name || "(sem nome)",
      niche: lead.niche,
      ts: Date.now(),
    };
    setActivity((prev) => {
      const next = [entry, ...prev].slice(0, 200);
      try {
        localStorage.setItem(ACTIVITY_KEY, JSON.stringify(next));
      } catch {/* ignore */}
      return next;
    });
  };

  const clearActivity = () => {
    setActivity([]);
    try {
      localStorage.removeItem(ACTIVITY_KEY);
    } catch {/* ignore */}
  };

  useEffect(() => {
    try {
      localStorage.setItem("lc_sender_name", senderName);
    } catch {/* ignore */}
  }, [senderName]);
  useEffect(() => {
    try {
      localStorage.setItem("lc_tone", tone);
    } catch {/* ignore */}
  }, [tone]);

  const persist = (next: Lead[]) => {
    setLeads(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const addBlank = async () => {
    const consumed = await tryConsumeLead();
    if (!consumed) return;

    const lead: Lead = {
      id: uid(),
      name: "",
      niche: "restaurante",
      customNiche: "",
      category: "",
      rating: "",
      reviews: "",
      mapsUrl: "",
      ddi: "55",
      whatsapp: "",
      hasWebsite: false,
      hasGbpOptimized: false,
      hasInstagramLink: false,
      hasProfessionalPhotos: false,
      respondsReviews: false,
      notes: "",
      contactName: "",
      problem: "",
      solution: "",
      differential: "",
      goal: "",
      contacted: false,
      status: "novo",
      createdAt: Date.now(),
    };
    persist([lead, ...leads]);
    logActivity("added", lead);
  };

  const addFromPaste = () => {
    if (!pasteUrl.trim() && !pasteText.trim()) return;
    const ext = extractFromMapsUrl(pasteUrl.trim(), pasteText);
    const phoneDigits = ext.whatsapp ?? "";
    const ddi = phoneDigits.startsWith("55") ? "55" : phoneDigits.slice(0, 2) || "55";
    const localNumber = phoneDigits.startsWith(ddi) ? phoneDigits.slice(ddi.length) : phoneDigits;
    const guessed = guessNicheFromCategory(ext.category);
    const lead: Lead = {
      id: uid(),
      name: ext.name ?? "",
      niche: guessed ?? "restaurante",
      customNiche: "",
      category: ext.category ?? "",
      rating: ext.rating ?? "",
      reviews: ext.reviews ?? "",
      mapsUrl: pasteUrl.trim(),
      ddi,
      whatsapp: localNumber,
      hasWebsite: ext.hasWebsite ?? false,
      hasGbpOptimized: false,
      hasInstagramLink: false,
      hasProfessionalPhotos: false,
      respondsReviews: false,
      notes: "",
      contactName: "",
      problem: "",
      solution: "",
      differential: "",
      goal: "",
      contacted: false,
      status: "novo",
      createdAt: Date.now(),
    };
    persist([lead, ...leads]);
    logActivity("added", lead);
    setPasteUrl("");
    setPasteText("");
  };

  // Pré-visualização reativa do que será extraído do texto colado.
  // Mostra apenas os campos relevantes — o resto do "Ctrl+A" é descartado.
  const pastePreview = useMemo(() => {
    if (!pasteText.trim() && !pasteUrl.trim()) return null;
    return extractFromMapsUrl(pasteUrl.trim(), pasteText);
  }, [pasteText, pasteUrl]);

  // Mescla o texto colado no lead mais recente (útil quando você importou pela URL e
  // depois copia Ctrl+A→Ctrl+C da página do Maps para puxar rating/categoria/telefone)
  const enrichLatestWithText = () => {
    if (!pasteText.trim() || leads.length === 0) return;
    const target = leads[0];
    const ext = extractFromMapsUrl(target.mapsUrl || "", pasteText);
    const phoneDigits = ext.whatsapp ?? "";
    const ddi = phoneDigits ? (phoneDigits.startsWith("55") ? "55" : phoneDigits.slice(0, 2)) : target.ddi;
    const localNumber = phoneDigits
      ? (phoneDigits.startsWith(ddi) ? phoneDigits.slice(ddi.length) : phoneDigits)
      : target.whatsapp;
    const guessed = guessNicheFromCategory(ext.category);
    const patch: Partial<Lead> = {
      // só sobrescreve nome se o atual estiver vazio OU parecer ser a query da pesquisa
      name: target.name && !/\bem\s+[A-ZÀ-Ú]/.test(target.name) ? target.name : (ext.name ?? target.name),
      category: ext.category ?? target.category,
      niche: guessed ?? target.niche,
      rating: ext.rating ?? target.rating,
      reviews: ext.reviews ?? target.reviews,
      whatsapp: localNumber || target.whatsapp,
      ddi: ddi || target.ddi,
      hasWebsite: ext.hasWebsite ?? target.hasWebsite,
    };
    update(target.id, patch);
    setPasteText("");
  };

  const update = (id: string, patch: Partial<Lead>) =>
    persist(leads.map((l) => (l.id === id ? { ...l, ...patch } : l)));

  const remove = (id: string) => {
    const target = leads.find((l) => l.id === id);
    persist(leads.filter((l) => l.id !== id));
    if (target) logActivity("removed", target);
  };

  const markContacted = (id: string) => {
    const target = leads.find((l) => l.id === id);
    update(id, { contacted: true, status: target?.status === "novo" ? "andamento" : (target?.status ?? "andamento") });
    if (target && !target.contacted) logActivity("contacted", target);
    const today = new Date().toISOString().slice(0, 10);
    const next = contactedToday + 1;
    setContactedToday(next);
    try {
      localStorage.setItem(
        "lc_contacted_today",
        JSON.stringify({ date: today, count: next })
      );
    } catch {
      /* ignore */
    }
  };

  // Funnel metrics
  const totalLeads = leads.length;
  const opportunities = leads.filter((l) => !l.hasWebsite).length;
  const oppRate = totalLeads ? Math.round((opportunities / totalLeads) * 100) : 0;
  const hotLeads = leads.filter((l) => leadScore(l).tier === "hot").length;

  return (
    <section className="rounded-lg border border-border bg-card p-5">
      <div className="mb-1 flex items-center gap-2">
        <Briefcase className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-semibold uppercase tracking-wider">
          Workbench de leads
        </h2>
      </div>
      <p className="mb-4 text-[11px] text-muted-foreground">
        Mesa de trabalho e dados. Importe, audite e contate seus leads num só lugar.
      </p>

      {/* Funnel dashboard */}
      <div className="mb-5 grid grid-cols-2 gap-2 md:grid-cols-4">
        <Stat label="Total de leads" value={totalLeads.toString()} />
        <Stat
          label="Oportunidades (sem site)"
          value={`${opportunities} (${oppRate}%)`}
          accent
        />
        <Stat label="Aproveitar agora 🔥" value={hotLeads.toString()} accent />
        <Stat label="Contatos hoje" value={contactedToday.toString()} />
      </div>

      {/* Sender + Idioma global (shared by all leads) */}
      <div className="mb-4 grid gap-2 rounded border border-border/50 bg-background/40 p-3 md:grid-cols-[1fr_auto]">
        <div>
          <label className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Seu nome (assinatura nas mensagens)
          </label>
          <input
            value={senderName}
            onChange={(e) => setSenderName(e.target.value)}
            placeholder="Ex: João Silva"
            className="input mt-1 h-8"
          />
        </div>
        <div>
          <label className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Idioma das mensagens
          </label>
          <div className="mt-1 grid grid-cols-3 gap-1">
            {LANGUAGES.map((l) => (
              <button
                key={l.code}
                onClick={() => setLanguage(l.code)}
                className={`rounded border px-2 py-1 text-[11px] font-semibold transition ${
                  language === l.code
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-background text-foreground hover:border-primary"
                }`}
                title={`Gerar mensagens em ${l.label}`}
              >
                <span className="mr-1">{l.flag}</span>
                {l.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Add lead — terminal status bar (visual) + manual button */}
      <div className="mb-2 grid gap-2 md:grid-cols-[1fr_auto]">
        <div
          className="flex items-center gap-2 overflow-hidden rounded border border-primary/50 bg-black px-3 py-2 shadow-[0_0_12px_hsl(var(--primary)/0.25)]"
          style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
          aria-label="Status do sistema"
        >
          <span className="h-2 w-2 shrink-0 animate-pulse rounded-full bg-primary shadow-[0_0_8px_hsl(var(--primary))]" />
          <span className="truncate text-[11px] font-semibold tracking-wider text-primary/90">
            <span className="text-primary">[STATUS DO SISTEMA]:</span>{" "}
            <span className="text-primary/80">AGUARDANDO DADOS DO ESTABELECIMENTO (Ctrl+V)</span>
            <span className="ml-0.5 inline-block animate-pulse text-primary">_</span>
          </span>
        </div>
        <button
          onClick={addBlank}
          className="inline-flex items-center justify-center gap-2 rounded border border-border bg-background px-4 py-2 text-sm font-semibold text-foreground hover:border-primary"
        >
          <Plus className="h-4 w-4" /> Adicionar manual
        </button>
      </div>
      <div className="mb-4">
        <ExtractionChamber
          onCapture={async (text) => {
            setPasteText(text);
            const consumed = await tryConsumeLead();
            if (!consumed) return;

            // Auto-create lead from pasted Maps page text (the import button is gone).
            const ext = extractFromMapsUrl("", text);
            const phoneDigits = ext.whatsapp ?? "";
            const ddi = phoneDigits.startsWith("55") ? "55" : phoneDigits.slice(0, 2) || "55";
            const localNumber = phoneDigits.startsWith(ddi) ? phoneDigits.slice(ddi.length) : phoneDigits;
            const guessed = guessNicheFromCategory(ext.category);
            const lead: Lead = {
              id: uid(),
              name: ext.name ?? "",
              niche: guessed ?? "restaurante",
              customNiche: "",
              category: ext.category ?? "",
              rating: ext.rating ?? "",
              reviews: ext.reviews ?? "",
              mapsUrl: "",
              ddi,
              whatsapp: localNumber,
              hasWebsite: ext.hasWebsite ?? false,
              hasGbpOptimized: false,
              hasInstagramLink: false,
              hasProfessionalPhotos: false,
              respondsReviews: false,
              notes: "",
              contactName: "",
              problem: "",
              solution: "",
              differential: "",
              goal: "",
              contacted: false,
              status: "novo",
              createdAt: Date.now(),
            };
            persist([lead, ...leads]);
            logActivity("added", lead);
          }}
          footer={
            <div className="space-y-2">
              <div className="rounded-md border border-primary/30 bg-primary/5 p-3.5">
                <p className="mb-2 font-mono text-xs font-bold uppercase tracking-wider text-primary">
                  📋 Como copiar do Google Maps (passo a passo)
                </p>
                <ol className="ml-4 list-decimal space-y-1 text-[13px] leading-relaxed text-muted-foreground">
                  <li><b className="text-foreground">Clique no estabelecimento</b> nos resultados para abrir o card lateral à esquerda.</li>
                  <li>Dentro do card, <b className="text-foreground">selecione com o mouse</b> apenas as informações (nome, categoria, rating, telefone, site).</li>
                  <li>Pressione <b className="text-foreground">Ctrl + C</b> para copiar e cole aqui com <b className="text-foreground">Ctrl + V</b>.</li>
                </ol>
                <p className="mt-2 text-[13px] leading-relaxed text-amber-400">
                  ⚠ Não use Ctrl + A na página inteira — isso pega menus, anúncios e a lista de busca, e a extração falha.
                </p>
              </div>
              {leads.length > 0 && pasteText.trim() && (
                <div className="flex justify-end">
                  <button
                    onClick={enrichLatestWithText}
                    className="rounded border border-primary/60 bg-primary/10 px-2 py-1 font-mono text-[10px] font-semibold uppercase tracking-wider text-primary hover:bg-primary/20"
                  >
                    ⤴ Enriquecer último lead
                  </button>
                </div>
              )}
            </div>
          }
        />

        {/* Pré-visualização do tratamento — só campos relevantes */}
        {pastePreview && (pasteText.trim() || pasteUrl.trim()) && (
          <div className="mt-3 rounded-md border border-primary/30 bg-primary/5 p-3">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-primary">
                🔎 Tratamento dos dados (pré-visualização)
              </span>
              <span className="text-[9px] text-muted-foreground">
                Apenas o que é útil é aproveitado — o resto do texto é descartado.
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
              <PreviewField label="Nome" value={pastePreview.name} />
              <PreviewField label="Categoria" value={pastePreview.category} />
              <PreviewField
                label="Rating"
                value={
                  typeof pastePreview.rating === "number"
                    ? `${pastePreview.rating.toString().replace(".", ",")}★`
                    : undefined
                }
              />
              <PreviewField
                label="Avaliações"
                value={
                  typeof pastePreview.reviews === "number"
                    ? pastePreview.reviews.toLocaleString("pt-BR")
                    : undefined
                }
              />
              <PreviewField
                label="Telefone"
                value={
                  pastePreview.whatsapp
                    ? `+${pastePreview.whatsapp}`
                    : undefined
                }
              />
              <PreviewField
                label="Site próprio"
                value={pastePreview.hasWebsite ? "Sim" : "Não detectado"}
              />
            </div>
            {!pastePreview.name &&
              !pastePreview.category &&
              !pastePreview.rating &&
              !pastePreview.whatsapp && (
                <p className="mt-2 text-[10px] text-amber-400">
                  ⚠ Nada relevante detectado. Verifique se você copiou a aba do estabelecimento (não a lista de busca).
                </p>
              )}
          </div>
        )}
      </div>

      <div className="mt-4 border-t border-border/50 pt-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Briefcase className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-foreground">
              Consultas ({leads.length})
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLeadsOpen((v) => !v)}
              className="inline-flex items-center gap-1 rounded border border-border bg-background px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground hover:border-primary hover:text-foreground"
            >
              {leadsOpen ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
              {leadsOpen ? "Ocultar" : "Mostrar"} consultas
            </button>
            {leads.length > 0 && (
              <button
                onClick={() => {
                  if (confirm(`Limpar todas as ${leads.length} consultas? Essa ação não pode ser desfeita.`)) {
                    persist([]);
                  }
                }}
                className="inline-flex items-center gap-1 rounded border border-border bg-background px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground hover:border-destructive hover:text-destructive"
              >
                <Trash2 className="h-3 w-3" /> Limpar todas
              </button>
            )}
          </div>
        </div>

        {leadsOpen && (
          leads.length === 0 ? (
            <p className="rounded border border-dashed border-border bg-background/50 px-3 py-6 text-center text-xs text-muted-foreground">
              Nenhum lead salvo ainda. Cole a URL do Maps de um estabelecimento ou
              adicione manualmente para começar a pontuar e auditar.
            </p>
          ) : (
            <div className="space-y-3">
              {leads.map((lead) => (
                <LeadCard
                  key={lead.id}
                  lead={lead}
                  senderName={senderName}
                  tone={tone}
                  language={language}
                  onUpdate={(p) => update(lead.id, p)}
                  onRemove={() => remove(lead.id)}
                  onContacted={() => markContacted(lead.id)}
                  openExternal={openExternal}
                  onChangeTone={setTone}
                />
              ))}
            </div>
          )
        )}
      </div>


      {/* Histórico de atividades (recolhível) */}
      <div className="mt-5 border-t border-border/50 pt-3">
        <button
          onClick={() => setHistoryOpen((v) => !v)}
          className="inline-flex items-center gap-2 rounded border border-border bg-background px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground hover:border-primary hover:text-foreground"
        >
          <History className="h-3 w-3" />
          {historyOpen ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
          {historyOpen ? "Ocultar" : "Mostrar"} histórico do workbench ({activity.length})
        </button>

        {historyOpen && (
          <div className="mt-3 rounded border border-border/50 bg-background/40 p-3">
            {activity.length === 0 ? (
              <p className="text-center text-xs text-muted-foreground">
                Sem atividade ainda. Adicione, contate ou remova leads para gerar histórico.
              </p>
            ) : (
              <>
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    Últimas {activity.length} atividades
                  </span>
                  <button
                    onClick={clearActivity}
                    className="text-[10px] text-muted-foreground hover:text-destructive"
                  >
                    Limpar histórico
                  </button>
                </div>
                <ul className="max-h-64 space-y-1 overflow-auto text-xs">
                  {activity.map((a) => {
                    const icon =
                      a.kind === "added" ? "➕" : a.kind === "contacted" ? "💬" : "🗑";
                    const label =
                      a.kind === "added"
                        ? "Adicionado"
                        : a.kind === "contacted"
                          ? "Contatado"
                          : "Removido";
                    const color =
                      a.kind === "contacted"
                        ? "text-emerald-400"
                        : a.kind === "removed"
                          ? "text-muted-foreground"
                          : "text-primary";
                    return (
                      <li
                        key={a.id}
                        className="flex items-center justify-between gap-2 rounded border border-border/40 bg-background px-2 py-1"
                      >
                        <span className="flex items-center gap-2 truncate">
                          <span>{icon}</span>
                          <span className={`text-[10px] font-bold uppercase ${color}`}>
                            {label}
                          </span>
                          <span className="truncate text-foreground">{a.leadName}</span>
                          <span className="text-[10px] text-muted-foreground">· {a.niche}</span>
                        </span>
                        <span className="shrink-0 text-[10px] text-muted-foreground">
                          {new Date(a.ts).toLocaleString("pt-BR", {
                            day: "2-digit",
                            month: "2-digit",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div
      className={`rounded border px-3 py-2 ${
        accent
          ? "border-primary/40 bg-primary/10"
          : "border-border bg-background"
      }`}
    >
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className={`text-lg font-bold ${accent ? "text-primary" : "text-foreground"}`}>
        {value}
      </div>
    </div>
  );
}

function PreviewField({ label, value }: { label: string; value?: string | number }) {
  const has = value !== undefined && value !== "" && value !== null;
  const display = has ? String(value) : "—";
  const prevRef = useRef<string>(display);
  const [flashKey, setFlashKey] = useState(0);

  useEffect(() => {
    if (display !== prevRef.current && has) {
      setFlashKey((k) => k + 1);
      prevRef.current = display;
    } else if (!has) {
      prevRef.current = display;
    }
  }, [display, has]);

  return (
    <div
      key={flashKey}
      className={`rounded border border-border/40 bg-background/60 px-2 py-1.5 transition-colors ${
        flashKey > 0 ? "hud-flash" : ""
      }`}
    >
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div
        className={`truncate text-xs font-semibold ${
          has ? "text-foreground" : "text-muted-foreground/50"
        }`}
        title={display}
      >
        {display}
      </div>
    </div>
  );
}

function LeadCard({
  lead,
  senderName,
  tone,
  language,
  onUpdate,
  onRemove,
  onContacted,
  openExternal,
  onChangeTone,
}: {
  lead: Lead;
  senderName: string;
  tone: Tone;
  language: Language;
  onUpdate: (p: Partial<Lead>) => void;
  onRemove: () => void;
  onContacted: () => void;
  openExternal: (url: string) => void;
  onChangeTone: (t: Tone) => void;
}) {
  const [personalizeOpen, setPersonalizeOpen] = useState(false);
  const [closeModalOpen, setCloseModalOpen] = useState(false);
  const [closeValue, setCloseValue] = useState<string>(
    lead.contractValue ? String(lead.contractValue) : ""
  );
  const [closeService, setCloseService] = useState<string>(
    lead.contractService ?? SERVICES[0]
  );
  const { score, tier } = leadScore(lead);
  const tierLabel =
    tier === "hot" ? "APROVEITAR AGORA 🔥" : tier === "warm" ? "MORNO" : "FRIO ❄";
  const tierColor =
    tier === "hot"
      ? "bg-red-500/15 text-red-400 border-red-500/30"
      : tier === "warm"
        ? "bg-amber-500/15 text-amber-400 border-amber-500/30"
        : "bg-sky-500/15 text-sky-400 border-sky-500/30";

  const auditChecks = useMemo(() => {
    return [
      { ok: lead.hasWebsite, okLabel: "Tem site profissional", failLabel: "Sem site profissional" },
      { ok: lead.hasGbpOptimized, okLabel: "Perfil Google otimizado", failLabel: "Perfil Google sem otimização" },
      { ok: lead.hasInstagramLink, okLabel: "Instagram com link na bio", failLabel: "Instagram sem link na bio" },
      { ok: lead.hasProfessionalPhotos, okLabel: "Fotos profissionais", failLabel: "Fotos amadoras" },
      { ok: lead.respondsReviews, okLabel: "Responde avaliações", failLabel: "Não responde avaliações" },
    ];
  }, [lead.hasWebsite, lead.hasGbpOptimized, lead.hasInstagramLink, lead.hasProfessionalPhotos, lead.respondsReviews]);

  const dynamicMessage = useMemo(() => {
    const company = lead.name || "[nome da empresa]";
    const social = language === "pt" ? (lead.niche === "outros" ? "" : (nicheCopy[lead.niche] ?? "")) : "";
    const sender = senderName || (language === "en" ? "[your name]" : language === "es" ? "[tu nombre]" : "[seu nome]");
    const problem = lead.problem || (language === "en" ? "[main problem]" : language === "es" ? "[problema principal]" : "[problema principal]");
    const solution = lead.solution || (language === "en" ? "[your solution in one sentence]" : language === "es" ? "[tu solución en una frase]" : "[sua solução em uma frase]");
    const differential = lead.differential || (language === "en" ? "[your differential]" : language === "es" ? "[tu diferencial]" : "[seu diferencial]");
    const goal = lead.goal || (language === "en" ? "[goal / benefit]" : language === "es" ? "[beneficio / objetivo]" : "[benefício / objetivo]");

    const ratingNum = typeof lead.rating === "number" && lead.rating >= 4 ? lead.rating : null;
    const reviewsNum = typeof lead.reviews === "number" && lead.reviews > 0 ? lead.reviews : null;
    const noteLine = lead.notes ? `\n\n${lead.notes}` : "";

    // Pega APENAS a oportunidade mais relevante (não lista tudo de errado).
    // Ordem de prioridade = maior alavanca comercial.
    const opportunityPT = !lead.hasWebsite
      ? "ainda não vi um site profissional ativo — e isso normalmente é o ponto que mais segura conversão hoje em dia"
      : !lead.hasGbpOptimized
        ? "o perfil de vocês no Google ainda tem espaço pra subir bastante de posicionamento"
        : !lead.hasInstagramLink
          ? "o Instagram de vocês está sem link clicável na bio — e isso impede que o tráfego vire conversa"
          : !lead.hasProfessionalPhotos
            ? "as fotos do estabelecimento ainda não estão vendendo o nível real do trabalho"
            : !lead.respondsReviews
              ? "vi avaliações sem resposta — e o algoritmo do Google penaliza fortes por isso"
              : "tem uma oportunidade pontual de aumentar autoridade no Google que pode mudar o jogo no seu nicho";

    const opportunityEN = !lead.hasWebsite
      ? "I couldn't find an active professional website — usually the #1 thing holding conversion back today"
      : !lead.hasGbpOptimized
        ? "your Google profile still has a lot of room to climb in local ranking"
        : !lead.hasInstagramLink
          ? "your Instagram bio doesn't have a clickable link — that breaks the path from traffic to conversation"
          : !lead.hasProfessionalPhotos
            ? "the photos aren't yet selling the real level of your work"
            : !lead.respondsReviews
              ? "I noticed unanswered reviews — Google's algorithm quietly penalizes that"
              : "there's one specific lever to grow authority on Google that could move the needle in your niche";

    const opportunityES = !lead.hasWebsite
      ? "no encontré un sitio profesional activo — suele ser lo que más frena la conversión hoy"
      : !lead.hasGbpOptimized
        ? "el perfil en Google todavía tiene mucho espacio para subir en posicionamiento local"
        : !lead.hasInstagramLink
          ? "el Instagram no tiene link clicable en la bio — eso rompe el camino del tráfico hacia la conversación"
          : !lead.hasProfessionalPhotos
            ? "las fotos aún no venden el nivel real del trabajo"
            : !lead.respondsReviews
              ? "vi reseñas sin respuesta — el algoritmo de Google penaliza eso silenciosamente"
              : "hay una palanca específica para crecer autoridad en Google que podría mover la aguja en tu nicho";

    // ---------- ENGLISH ----------
    if (language === "en") {
      const hi = lead.contactName ? `Hi, ${lead.contactName}` : "Hi";
      const ratingLine = ratingNum
        ? ` (${ratingNum}★${reviewsNum ? ` from ${reviewsNum} reviews` : ""})`
        : "";
      const opening = openingByTone(tone, "en", sender, company, ratingLine, hi);
      const closing = closingByTone(tone, "en", sender);
      return `${opening}\n\nI took a look at ${company}'s Google Maps profile${ratingLine} and noticed something that caught my attention: ${opportunityEN}.\n\nThe reason I'm reaching out: I help businesses like yours ${solution}, focused on ${goal}. ${differential ? `What sets my work apart is ${differential}.` : ""}\n\n${closing}${noteLine}`.replace(/\n{3,}/g, "\n\n").trim();
    }

    // ---------- SPANISH ----------
    if (language === "es") {
      const hi = lead.contactName ? `Hola, ${lead.contactName}` : "Hola";
      const ratingLine = ratingNum
        ? ` (${ratingNum}★${reviewsNum ? ` en ${reviewsNum} reseñas` : ""})`
        : "";
      const opening = openingByTone(tone, "es", sender, company, ratingLine, hi);
      const closing = closingByTone(tone, "es", sender);
      return `${opening}\n\nMiré el perfil de ${company} en Google Maps${ratingLine} y noté algo que me llamó la atención: ${opportunityES}.\n\nPor qué te escribo: ayudo a negocios como el tuyo a ${solution}, con foco en ${goal}. ${differential ? `Lo que diferencia mi trabajo es ${differential}.` : ""}\n\n${closing}${noteLine}`.replace(/\n{3,}/g, "\n\n").trim();
    }

    // ---------- PORTUGUÊS (padrão) ----------
    const hi = lead.contactName ? `Olá, ${lead.contactName}` : "Olá";
    const ratingLine = ratingNum
      ? ` (${ratingNum}★${reviewsNum ? ` em ${reviewsNum} avaliações` : ""})`
      : "";
    const opening = openingByTone(tone, "pt", sender, company, ratingLine, hi);
    const closing = closingByTone(tone, "pt", sender);
    const socialLine = social ? ` ${social}` : "";

    return `${opening}\n\nDei uma olhada rápida no perfil da ${company} no Google Maps${ratingLine} e percebi algo que chamou minha atenção: ${opportunityPT}.\n\nPor que estou te escrevendo: hoje eu ajudo negócios como o de vocês a ${solution}, com foco em ${goal}.${socialLine} ${differential ? `O que diferencia meu trabalho é ${differential}.` : ""}\n\n${closing}${noteLine}`.replace(/\n{3,}/g, "\n\n").trim();
  }, [lead, senderName, tone, language]);

  const whatsappLink = useMemo(() => {
    const ddi = (lead.ddi || "").replace(/\D/g, "");
    const local = (lead.whatsapp || "").replace(/\D/g, "");
    const digits = `${ddi}${local}`;
    if (!local || local.length < 8) return null;
    return `https://wa.me/${digits}?text=${encodeURIComponent(dynamicMessage)}`;
  }, [lead.ddi, lead.whatsapp, dynamicMessage]);

  const copyMsg = async () => {
    try {
      await navigator.clipboard.writeText(dynamicMessage);
    } catch {
      /* ignore */
    }
  };

  return (
    <div
      className={`rounded-lg border p-4 ${
        lead.contacted ? "border-border/50 bg-background/60 opacity-75" : "border-border bg-background"
      }`}
    >
      {/* Header */}
      <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          {tier === "hot" ? (
            <Flame className="h-4 w-4 text-red-400" />
          ) : tier === "cold" ? (
            <Snowflake className="h-4 w-4 text-sky-400" />
          ) : (
            <TrendingUp className="h-4 w-4 text-amber-400" />
          )}
          <input
            value={lead.name}
            onChange={(e) => onUpdate({ name: e.target.value })}
            placeholder="Nome do estabelecimento"
            className="input h-8 max-w-xs"
          />
          <span className={`rounded border px-2 py-0.5 text-[10px] font-bold ${tierColor}`}>
            {tierLabel} · {score}
          </span>
          <span className={`inline-flex items-center gap-1 rounded border px-2 py-0.5 text-[10px] font-bold ${STATUS_META[lead.status].color}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${STATUS_META[lead.status].dot}`} />
            {STATUS_META[lead.status].label}
          </span>
          <select
            value={lead.status}
            onChange={(e) => {
              const next = e.target.value as LeadStatus;
              if (next === "fechado" && lead.status !== "fechado") {
                setCloseModalOpen(true);
              } else {
                onUpdate({ status: next });
              }
            }}
            className="h-6 rounded border border-border bg-background px-1 text-[10px] text-foreground"
            title="Status do lead"
          >
            <option value="novo">Nova consulta</option>
            <option value="andamento">Em andamento</option>
            <option value="fechado">Fechado ✓</option>
            <option value="perdido">Perdido</option>
          </select>
        </div>
        <div className="flex items-center gap-1">
          {lead.mapsUrl && (
            <button
              onClick={() => openExternal(lead.mapsUrl)}
              className="inline-flex items-center gap-1 rounded border border-border px-2 py-1 text-[10px] text-foreground hover:border-primary"
            >
              <ExternalLink className="h-3 w-3" /> Maps
            </button>
          )}
          <button
            onClick={onRemove}
            className="inline-flex items-center gap-1 rounded border border-border px-2 py-1 text-[10px] text-muted-foreground hover:border-destructive hover:text-destructive"
          >
            <Trash2 className="h-3 w-3" />
          </button>
        </div>
      </div>

      {/* Inputs grid */}
      <div className="mb-3 grid gap-2 md:grid-cols-4">
        <Mini label="Nicho">
          <div className="space-y-1">
            <select
              value={lead.niche}
              onChange={(e) => onUpdate({ niche: e.target.value })}
              className="input h-8"
            >
              {NICHES.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.label}
                </option>
              ))}
            </select>
            {lead.niche === "outros" && (
              <input
                value={lead.customNiche}
                onChange={(e) => onUpdate({ customNiche: e.target.value })}
                placeholder="Digite o nicho (ex: Pet Shop)"
                className="input h-8"
                aria-label="Nicho customizado"
              />
            )}
          </div>
        </Mini>
        <Mini label="Rating (★)">
          <input
            type="number"
            step="0.1"
            min={0}
            max={5}
            value={lead.rating}
            onChange={(e) =>
              onUpdate({ rating: e.target.value === "" ? "" : Number(e.target.value) })
            }
            className="input h-8"
          />
        </Mini>
        <Mini label="Nº avaliações">
          <input
            type="number"
            min={0}
            value={lead.reviews}
            onChange={(e) =>
              onUpdate({ reviews: e.target.value === "" ? "" : Number(e.target.value) })
            }
            className="input h-8"
          />
        </Mini>
        <Mini label="WhatsApp (DDI / número)">
          <div className="flex gap-1">
            <input
              value={lead.ddi}
              onChange={(e) => onUpdate({ ddi: e.target.value.replace(/\D/g, "").slice(0, 4) })}
              placeholder="55"
              className="input h-8 w-14 text-center"
            />
            <input
              value={lead.whatsapp}
              onChange={(e) => onUpdate({ whatsapp: e.target.value.replace(/\D/g, "") })}
              placeholder="11999998888"
              className="input h-8 flex-1"
            />
          </div>
        </Mini>
      </div>

      {/* Audit checklist */}
      <div className="mb-4 rounded-xl border border-border/60 bg-card/60 p-5 shadow-sm backdrop-blur-sm">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 border border-primary/20">
              <ClipboardCheck className="h-4 w-4 text-primary" />
            </div>
            <span className="text-sm font-bold uppercase tracking-wider text-foreground">
              Auditoria Rápida do Lead
            </span>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 md:grid-cols-3">
          <Check label="Tem site" checked={lead.hasWebsite} onChange={(v) => onUpdate({ hasWebsite: v })} />
          <Check label="GBP Otimizado" checked={lead.hasGbpOptimized} onChange={(v) => onUpdate({ hasGbpOptimized: v })} />
          <Check label="Insta c/ Link" checked={lead.hasInstagramLink} onChange={(v) => onUpdate({ hasInstagramLink: v })} />
          <Check label="Fotos Profissionais" checked={lead.hasProfessionalPhotos} onChange={(v) => onUpdate({ hasProfessionalPhotos: v })} />
          <Check label="Responde Reviews" checked={lead.respondsReviews} onChange={(v) => onUpdate({ respondsReviews: v })} />
        </div>
        
        {/* Visual summary of issues */}
        <div className="mt-4 rounded-lg bg-background/50 border border-border/50 p-3">
          <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            Diagnóstico Gerado
          </div>
          <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {auditChecks.map((c) => (
              <li
                key={c.okLabel}
                className={`flex items-center gap-2.5 rounded-md border px-3 py-2 text-xs font-medium transition-all ${
                  c.ok
                    ? "border-emerald-500/20 bg-emerald-500/5 text-emerald-400"
                    : "border-amber-500/20 bg-amber-500/5 text-amber-400"
                }`}
              >
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-background/50">
                  {c.ok ? "✓" : "⚠"}
                </span>
                <span>{c.ok ? c.okLabel : c.failLabel}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Personalização da abordagem — botão de destaque */}
      <div className="mb-3">
        <button
          type="button"
          onClick={() => setPersonalizeOpen((v) => !v)}
          className={`flex w-full items-center justify-between gap-2 rounded-md border-2 px-3 py-2.5 text-xs font-bold uppercase tracking-wider transition ${
            personalizeOpen
              ? "border-primary bg-primary/15 text-primary"
              : "border-primary/60 bg-primary/5 text-primary hover:bg-primary/10"
          }`}
        >
          <span className="flex items-center gap-2">
            ✏ Personalizar abordagem
            <span className="hidden text-[10px] font-medium normal-case tracking-normal opacity-80 sm:inline">
              (problema · solução · diferencial · objetivo · tom)
            </span>
          </span>
          {personalizeOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>

        {personalizeOpen && (
          <div className="mt-2 rounded-md border border-primary/30 bg-background/40 p-3">
            {/* Tom da abordagem (per-lead via global state) */}
            <div className="mb-3 rounded border border-border/50 bg-card/40 p-2">
              <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                🎯 Tom da abordagem (afeta a mensagem abaixo em tempo real)
              </label>
              <div className="mt-1.5 grid grid-cols-2 gap-1 sm:grid-cols-3">
                {TONE_LIST.map((t) => {
                  const meta = TONE_LABELS[t];
                  return (
                    <button
                      key={t}
                      type="button"
                      onClick={() => onChangeTone(t)}
                      title={meta.hint}
                      className={`rounded border px-2 py-1.5 text-[10px] font-semibold transition ${
                        tone === t
                          ? "border-primary bg-primary text-primary-foreground shadow-[0_0_8px_hsl(var(--primary)/0.5)]"
                          : "border-border bg-background text-foreground hover:border-primary"
                      }`}
                    >
                      <span className="mr-1">{meta.emoji}</span>
                      {meta.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid gap-2 md:grid-cols-2">
              <Mini label="Nome do contato">
                <input
                  value={lead.contactName}
                  onChange={(e) => onUpdate({ contactName: e.target.value })}
                  placeholder="Ex: Maria"
                  className="input h-8"
                />
              </Mini>
              <Mini label="Categoria detectada">
                <input
                  value={lead.category}
                  onChange={(e) => onUpdate({ category: e.target.value })}
                  placeholder="Ex: Salão de Beleza"
                  className="input h-8"
                />
              </Mini>
              <div className="md:col-span-2">
                <Mini label="Principal problema que você resolve">
                  <textarea
                    value={lead.problem}
                    onChange={(e) => onUpdate({ problem: e.target.value })}
                    placeholder="Ex: baixa conversão de visitantes em clientes"
                    className="input min-h-[50px] text-xs"
                  />
                </Mini>
              </div>
              <Mini label="Sua solução (em uma frase)">
                <input
                  value={lead.solution}
                  onChange={(e) => onUpdate({ solution: e.target.value })}
                  placeholder="Ex: criar páginas de venda otimizadas"
                  className="input h-8"
                />
              </Mini>
              <Mini label="Seu diferencial">
                <input
                  value={lead.differential}
                  onChange={(e) => onUpdate({ differential: e.target.value })}
                  placeholder="Ex: entrega em 72h com garantia"
                  className="input h-8"
                />
              </Mini>
              <div className="md:col-span-2">
                <Mini label="Seu objetivo / benefício para o cliente">
                  <input
                    value={lead.goal}
                    onChange={(e) => onUpdate({ goal: e.target.value })}
                    placeholder="Ex: dobrar agendamentos em 30 dias"
                    className="input h-8"
                  />
                </Mini>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Notes */}
      <textarea
        value={lead.notes}
        onChange={(e) => onUpdate({ notes: e.target.value })}
        placeholder="Anotações livres (entram automaticamente na mensagem)"
        className="input mb-3 min-h-[50px] text-xs"
      />

      {/* Generated message */}
      <pre className="mb-2 max-h-40 overflow-auto whitespace-pre-wrap rounded border border-border bg-background p-2 text-[11px] text-foreground">
        {dynamicMessage}
      </pre>

      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={copyMsg}
          className="inline-flex items-center gap-1 rounded border border-border bg-background px-3 py-1.5 text-xs font-semibold text-foreground hover:border-primary"
        >
          <Copy className="h-3 w-3" /> Copiar mensagem
        </button>
        {whatsappLink ? (
          <button
            onClick={() => {
              openExternal(whatsappLink);
              onContacted();
            }}
            className="inline-flex items-center gap-1 rounded bg-[#16a34a] px-3 py-1.5 text-xs font-semibold text-white hover:opacity-90"
          >
            <MessageSquare className="h-3 w-3" /> Abrir WhatsApp
          </button>
        ) : (
          <span className="text-[10px] text-muted-foreground">
            Informe o WhatsApp para liberar contato
          </span>
        )}
        {!lead.contacted && (
          <button
            onClick={onContacted}
            className="inline-flex items-center gap-1 rounded border border-border px-3 py-1.5 text-xs text-muted-foreground hover:border-primary hover:text-foreground"
          >
            Marcar como contatado
          </button>
        )}
        {lead.contacted && (
          <span className="rounded bg-primary/15 px-2 py-0.5 text-[10px] font-bold text-primary">
            ✓ Contatado
          </span>
        )}
      </div>

      {closeModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
          onClick={() => setCloseModalOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="hud-chamber w-[min(420px,92vw)] rounded-lg border border-primary/60 bg-card p-5 shadow-[0_0_30px_hsl(var(--primary)/0.4)]"
          >
            <h4
              className="mb-1 text-sm font-bold uppercase tracking-wider text-primary"
              style={{ fontFamily: '"Courier New", Menlo, ui-monospace, monospace' }}
            >
              💰 CONTRATO FECHADO
            </h4>
            <p className="mb-4 text-[11px] text-muted-foreground">
              Registre o valor e o serviço — entra direto no dashboard de Lucros & BI.
            </p>
            <div className="space-y-3">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Valor do contrato (R$)
                </label>
                <input
                  type="number"
                  min={0}
                  step="0.01"
                  autoFocus
                  value={closeValue}
                  onChange={(e) => setCloseValue(e.target.value)}
                  placeholder="Ex: 2500"
                  className="input mt-1 h-9"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Tipo de serviço
                </label>
                <select
                  value={closeService}
                  onChange={(e) => setCloseService(e.target.value)}
                  className="input mt-1 h-9"
                >
                  {SERVICES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                onClick={() => setCloseModalOpen(false)}
                className="rounded border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground hover:border-destructive hover:text-destructive"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  const v = parseFloat(closeValue.replace(",", "."));
                  onUpdate({
                    status: "fechado",
                    contractValue: Number.isFinite(v) && v >= 0 ? v : 0,
                    contractService: closeService,
                    closedAt: Date.now(),
                  });
                  setCloseModalOpen(false);
                }}
                className="rounded bg-primary px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_12px_hsl(var(--primary)/0.5)] hover:opacity-90"
              >
                ✓ Confirmar fechamento
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Mini({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1 text-[10px] uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      {children}
    </div>
  );
}

function Check({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className={`flex cursor-pointer items-center gap-3 rounded-lg border p-3 transition-all ${
      checked
        ? "border-emerald-500/40 bg-emerald-500/5 text-emerald-100 shadow-[0_0_10px_rgba(16,185,129,0.1)]"
        : "border-border/60 bg-background/50 hover:border-primary/50 text-muted-foreground"
    }`}>
      <div className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border transition-colors ${
        checked
          ? "border-emerald-500 bg-emerald-500 text-white"
          : "border-border bg-background"
      }`}>
        {checked && <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>}
      </div>
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="sr-only"
      />
      <span className="font-medium text-sm select-none">{label}</span>
    </label>
  );
}
