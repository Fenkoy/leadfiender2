import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Target } from "lucide-react";

export default function ResetPassword() {
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Supabase entrega o token via hash (#access_token=...&type=recovery)
    // O onAuthStateChange dispara PASSWORD_RECOVERY automaticamente.
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || (session && window.location.hash.includes("type=recovery"))) {
        setReady(true);
      }
    });
    // fallback: se já houver sessão de recovery
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session && (window.location.hash.includes("type=recovery") || window.location.hash.includes("access_token"))) {
        setReady(true);
      } else if (session) {
        setReady(true);
      }
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) {
      toast({ title: "Senha curta", description: "Use ao menos 6 caracteres.", variant: "destructive" });
      return;
    }
    if (password !== confirm) {
      toast({ title: "Senhas diferentes", description: "Confirme a mesma senha nos dois campos.", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      toast({ title: "Senha redefinida", description: "Você já está logado." });
      navigate("/", { replace: true });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erro inesperado";
      toast({ title: "Falha ao redefinir", description: msg, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4">
      <div aria-hidden className="neural-bg" />
      <div aria-hidden className="neural-vignette" />
      <div className="relative z-10 w-full max-w-sm rounded-lg border border-primary/30 bg-background/80 p-6 backdrop-blur-md">
        <Link to="/" className="mb-4 inline-flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-md border border-primary/50 bg-background/80">
            <Target className="h-4 w-4 text-primary" />
          </span>
          <span className="font-mono text-sm font-extrabold tracking-[0.18em]">
            LEAD<span className="text-primary">FINDER</span>
          </span>
        </Link>
        <h1 className="text-xl font-bold">Redefinir senha</h1>
        <p className="mt-1 text-xs text-muted-foreground">
          {ready ? "Digite sua nova senha duas vezes." : "Validando link de recuperação..."}
        </p>

        {ready && (
          <form onSubmit={submit} className="mt-5 space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="password">Nova senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="confirm">Confirmar nova senha</Label>
              <Input
                id="confirm"
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                required
                minLength={6}
              />
            </div>
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "Salvando..." : "Salvar nova senha"}
            </Button>
          </form>
        )}

        <Link to="/auth" className="mt-4 block text-center text-xs text-muted-foreground hover:text-foreground">
          Voltar para login
        </Link>
      </div>
    </div>
  );
}
