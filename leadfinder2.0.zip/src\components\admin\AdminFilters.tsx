import { Plan, UserStatus, PLAN_CONFIG, STATUS_CONFIG } from "@/lib/admin-types";
import { Input } from "@/components/ui/input";
import { Search, X } from "lucide-react";

type Props = {
  search: string;
  onSearchChange: (v: string) => void;
  planFilter: Plan | null;
  onPlanFilterChange: (v: Plan | null) => void;
  statusFilter: UserStatus | null;
  onStatusFilterChange: (v: UserStatus | null) => void;
};

export default function AdminFilters({
  search, onSearchChange,
  planFilter, onPlanFilterChange,
  statusFilter, onStatusFilterChange,
}: Props) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      {/* Search */}
      <div className="relative flex-1 min-w-[220px] max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Buscar por e-mail ou nome..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9 bg-card/50 border-border"
        />
        {search && (
          <button onClick={() => onSearchChange("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
            <X className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {/* Plan Filter */}
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground mr-1">Plano:</span>
        <button
          onClick={() => onPlanFilterChange(null)}
          className={`rounded-md px-2.5 py-1 text-xs font-medium border transition-colors ${
            planFilter === null ? "bg-primary/15 text-primary border-primary/30" : "border-border text-muted-foreground hover:text-foreground hover:border-border/80"
          }`}
        >
          Todos
        </button>
        {(Object.keys(PLAN_CONFIG) as Plan[]).map((p) => (
          <button
            key={p}
            onClick={() => onPlanFilterChange(planFilter === p ? null : p)}
            className={`rounded-md px-2.5 py-1 text-xs font-medium border transition-colors ${
              planFilter === p ? PLAN_CONFIG[p].bgClass : "border-border text-muted-foreground hover:text-foreground hover:border-border/80"
            }`}
          >
            {PLAN_CONFIG[p].label}
          </button>
        ))}
      </div>

      {/* Status Filter */}
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground mr-1">Status:</span>
        <button
          onClick={() => onStatusFilterChange(null)}
          className={`rounded-md px-2.5 py-1 text-xs font-medium border transition-colors ${
            statusFilter === null ? "bg-primary/15 text-primary border-primary/30" : "border-border text-muted-foreground hover:text-foreground hover:border-border/80"
          }`}
        >
          Todos
        </button>
        {(Object.keys(STATUS_CONFIG) as UserStatus[]).map((s) => (
          <button
            key={s}
            onClick={() => onStatusFilterChange(statusFilter === s ? null : s)}
            className={`rounded-md px-2.5 py-1 text-xs font-medium border transition-colors ${
              statusFilter === s ? STATUS_CONFIG[s].bgClass : "border-border text-muted-foreground hover:text-foreground hover:border-border/80"
            }`}
          >
            <span className={`inline-block h-1.5 w-1.5 rounded-full ${STATUS_CONFIG[s].dot} mr-1.5`} />
            {STATUS_CONFIG[s].label}
          </button>
        ))}
      </div>
    </div>
  );
}
