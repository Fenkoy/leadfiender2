// Country + state + city lookups using free public APIs (no key).

export interface Country {
  code: string; // ISO-3166-1 alpha-2 (e.g. "BR")
  name: string; // Localized PT-BR name when available
  englishName: string; // English name (used by countriesnow API for cities)
}

interface RawCountry {
  iso2: string;
  name: string; // English
  translations?: Record<string, string>;
}

let countriesCache: Country[] | null = null;

export async function fetchCountries(): Promise<Country[]> {
  if (countriesCache) return countriesCache;
  const res = await fetch(
    "https://raw.githubusercontent.com/dr5hn/countries-states-cities-database/master/json/countries.json"
  );
  if (!res.ok) throw new Error("Falha ao buscar países");
  const data = (await res.json()) as RawCountry[];
  const list: Country[] = data
    .map((c) => ({
      code: c.iso2,
      englishName: c.name,
      name: c.translations?.["pt-BR"] || c.translations?.pt || c.name,
    }))
    .filter((c) => c.code)
    .sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
  countriesCache = list;
  return list;
}

export interface State {
  name: string;
  code: string;
}

const statesCache = new Map<string, State[]>();

interface RawState {
  name: string;
  iso2: string;
  country_code: string;
}

export async function fetchStates(countryCode: string): Promise<State[]> {
  const key = countryCode.toUpperCase();
  if (statesCache.has(key)) return statesCache.get(key)!;
  const res = await fetch(
    `https://raw.githubusercontent.com/dr5hn/countries-states-cities-database/master/json/states.json`
  );
  if (!res.ok) throw new Error("Falha ao buscar estados");
  const all = (await res.json()) as RawState[];
  const list = all
    .filter((s) => s.country_code === key)
    .map((s) => ({ name: s.name, code: s.iso2 }))
    .sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
  statesCache.set(key, list);
  return list;
}

export interface City {
  name: string;
}

const citiesCache = new Map<string, City[]>();

/**
 * Fetch cities for (country english name, state name) via countriesnow.space.
 * The GET endpoint accepts the names directly; uses URL-encoded query params.
 */
/**
 * Some state names in the dr5hn database are localized (e.g. Brazil's
 * "Distrito Federal") while the countriesnow cities API expects the English
 * form ("Federal District"). Map known mismatches here.
 */
const STATE_NAME_ALIASES: Record<string, string[]> = {
  "Distrito Federal": ["Federal District", "Distrito Federal"],
};

async function tryFetchCities(country: string, state: string): Promise<string[] | null> {
  const url = `https://countriesnow.space/api/v0.1/countries/state/cities/q?country=${encodeURIComponent(
    country
  )}&state=${encodeURIComponent(state)}`;
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const json = (await res.json()) as { error?: boolean; data?: string[] };
    if (json.error || !Array.isArray(json.data)) return null;
    return json.data;
  } catch {
    return null;
  }
}

export async function fetchCities(
  countryEnglishName: string,
  stateName: string
): Promise<City[]> {
  const key = `${countryEnglishName}::${stateName}`.toLowerCase();
  if (citiesCache.has(key)) return citiesCache.get(key)!;

  const candidates = [stateName, ...(STATE_NAME_ALIASES[stateName] ?? [])];
  let data: string[] | null = null;
  for (const candidate of candidates) {
    data = await tryFetchCities(countryEnglishName, candidate);
    if (data && data.length > 0) break;
  }
  if (!data) return [];

  const list: City[] = data
    .map((name) => ({ name }))
    .sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
  citiesCache.set(key, list);
  return list;
}
