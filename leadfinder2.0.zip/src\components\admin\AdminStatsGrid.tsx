import { AdminStats } from "@/lib/admin-types";
import { Users, UserCheck, UserX, Ban, Zap, Crown, TrendingUp, AlertTriangle } from "lucide-react";

type Props = { stats: AdminStats | null; loading: boolean };

const cards = (s: AdminStats) => [
  { label: "Total Usuários", value: s.total_users, icon: Users, color: "text-primary", bg: "bg-primary/10" },
  { label: "Ativos", value: s.active_users, icon: UserCheck, color: "text-emerald-400", bg: "bg-emerald-500/10" },
  { label: "Em Trial", value: s.trial_users, icon: TrendingUp, color: "text-yellow-400", bg: "bg-yellow-500/10" },
  { label: "Suspensos", value: s.suspended_users, icon: UserX, color: "text-red-400", bg: "bg-red-500/10" },
  { label: "Banidos", value: s.banned_users, icon: Ban, color: "text-zinc-500", bg: "bg-zinc-600/10" },
  { label: "Plano Founder", value: s.founder_plans, icon: Crown, color: "text-amber-400", bg: "bg-amber-500/10" },
  { label: "Leads Hoje", value: s.total_leads_today, icon: Zap, color: "text-cyan-400", bg: "bg-cyan-500/10" },
  { label: "Inativos 7d+", value: s.inactive_7d, icon: AlertTriangle, color: "text-orange-400", bg: "bg-orange-500/10" },
];

export default function AdminStatsGrid({ stats, loading }: Props) {
  if (loading || !stats) {
    return (
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="animate-pulse rounded-xl border border-border bg-card/50 p-4">
            <div className="h-4 w-16 rounded bg-muted/50 mb-3" />
            <div className="h-8 w-12 rounded bg-muted/50" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {cards(stats).map((c) => (
        <div
          key={c.label}
          className="group relative overflow-hidden rounded-xl border border-border bg-card/50 p-4 transition-all hover:border-primary/30 hover:shadow-[0_0_20px_hsl(var(--primary)/0.1)]"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              {c.label}
            </span>
            <div className={`rounded-lg p-1.5 ${c.bg}`}>
              <c.icon className={`h-3.5 w-3.5 ${c.color}`} />
            </div>
          </div>
          <p className={`text-2xl font-bold tabular-nums ${c.color}`}>
            {c.value.toLocaleString("pt-BR")}
          </p>
        </div>
      ))}
    </div>
  );
}
