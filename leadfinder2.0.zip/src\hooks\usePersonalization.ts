// Hook that provides personalization based on onboarding profile data.
// Uses niche, goal, and experience from the user's profile to adapt the UI.

import { useMemo } from "react";
import { useAuth } from "@/hooks/useAuth";

export type Experience = "nunca" | "ja_tentei" | "ja_vendo";
export type Goal = "clientes_rapido" | "testar" | "renda_extra";

type PersonalizationContext = {
  /** User experience level */
  experience: Experience;
  /** User's primary goal */
  goal: Goal;
  /** User's niche */
  niche: string;
  /** Whether to show beginner tips */
  showTips: boolean;
  /** Whether to show advanced metrics */
  showAdvancedMetrics: boolean;
  /** Greeting message based on goal */
  greeting: string;
  /** Sub-message based on experience */
  subtitle: string;
  /** Suggested daily target */
  dailyTarget: number;
  /** Motivational nudge text */
  nudge: string;
  /** Priority CTA label */
  primaryCta: string;
};

export function usePersonalization(): PersonalizationContext {
  const { profile } = useAuth();

  return useMemo(() => {
    const experience = (profile?.experience as Experience) ?? "nunca";
    const goal = (profile?.goal as Goal) ?? "clientes_rapido";
    const niche = profile?.niche ?? "outros";
    const firstName = profile?.full_name?.split(" ")[0] || "por aqui";

    const showTips = experience === "nunca" || experience === "ja_tentei";
    const showAdvancedMetrics = experience === "ja_vendo";

    // Goal-based greeting
    const greeting = (() => {
      switch (goal) {
        case "clientes_rapido":
          return `Bora fechar clientes, ${firstName}! 🚀`;
        case "testar":
          return `Bem-vindo de volta, ${firstName} 👋`;
        case "renda_extra":
          return `Mais um dia de oportunidades, ${firstName} 💰`;
        default:
          return `Bem-vindo, ${firstName} 👋`;
      }
    })();

    // Experience-based subtitle
    const subtitle = (() => {
      switch (experience) {
        case "nunca":
          return "Siga o passo a passo abaixo para encontrar seus primeiros clientes. É mais simples do que parece!";
        case "ja_tentei":
          return "Dessa vez vai ser diferente. Use o sistema completo e acompanhe cada lead de perto.";
        case "ja_vendo":
          return "Pra quem já vende, aqui é escala. Foque nos leads com maior score.";
        default:
          return "Pra quem vamos vender hoje?";
      }
    })();

    // Daily target based on goal + experience
    const dailyTarget = (() => {
      if (goal === "clientes_rapido") return experience === "ja_vendo" ? 15 : 10;
      if (goal === "renda_extra") return experience === "ja_vendo" ? 10 : 5;
      return 3; // testar
    })();

    // Motivational nudge
    const nudge = (() => {
      switch (goal) {
        case "clientes_rapido":
          return `Meta: contate pelo menos ${dailyTarget} leads hoje para maximizar suas chances de fechar.`;
        case "renda_extra":
          return `Meta: ${dailyTarget} contatos por dia já geram renda consistente no fim do mês.`;
        case "testar":
          return "Explore o sistema, teste o fluxo, e quando estiver pronto, comece a contatar!";
        default:
          return "";
      }
    })();

    // Primary CTA text
    const primaryCta = (() => {
      switch (experience) {
        case "nunca":
          return "Buscar meus primeiros leads";
        case "ja_tentei":
          return "Buscar novos leads";
        case "ja_vendo":
          return "Prospectar agora";
        default:
          return "Buscar no Google Maps";
      }
    })();

    return {
      experience,
      goal,
      niche,
      showTips,
      showAdvancedMetrics,
      greeting,
      subtitle,
      dailyTarget,
      nudge,
      primaryCta,
    };
  }, [profile]);
}
