-- =============================================
-- STEP 2: Tables, Policies, Functions, Triggers
-- Run AFTER step1_enum_only.sql is committed
-- =============================================

-- =============================================
-- TABLES (safe for re-runs on existing databases)
-- =============================================

-- Profiles (extended user data)
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  email text,
  niche text,
  goal text,
  experience text,
  onboarding_completed boolean NOT NULL DEFAULT false,
  is_admin boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- Add new columns (safe if they already exist)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS status public.user_status NOT NULL DEFAULT 'active';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role public.user_role NOT NULL DEFAULT 'user';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_status ON public.profiles(status);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);

-- user_plans
CREATE TABLE IF NOT EXISTS public.user_plans (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  plan public.plan_type NOT NULL DEFAULT 'basic',
  status text NOT NULL DEFAULT 'active',
  current_period_end timestamptz,
  stripe_customer_id text,
  stripe_subscription_id text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.user_plans ADD COLUMN IF NOT EXISTS leads_limit integer NOT NULL DEFAULT 30;
ALTER TABLE public.user_plans ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_user_plans_plan ON public.user_plans(plan);

-- lead_usage
CREATE TABLE IF NOT EXISTS public.lead_usage (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  leads_used_today integer NOT NULL DEFAULT 0,
  last_reset_date date NOT NULL DEFAULT current_date,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.lead_usage ADD COLUMN IF NOT EXISTS leads_used_week integer NOT NULL DEFAULT 0;
ALTER TABLE public.lead_usage ADD COLUMN IF NOT EXISTS leads_used_month integer NOT NULL DEFAULT 0;
ALTER TABLE public.lead_usage ENABLE ROW LEVEL SECURITY;

-- upgrade_events
CREATE TABLE IF NOT EXISTS public.upgrade_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  feature text,
  from_plan public.plan_type,
  to_plan public.plan_type,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.upgrade_events ENABLE ROW LEVEL SECURITY;

DROP INDEX IF EXISTS upgrade_events_user_idx;
CREATE INDEX upgrade_events_user_idx ON public.upgrade_events(user_id, created_at DESC);

-- founder_slots
CREATE TABLE IF NOT EXISTS public.founder_slots (
  id integer PRIMARY KEY DEFAULT 1,
  total_slots integer NOT NULL DEFAULT 50,
  claimed integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT founder_slots_singleton CHECK (id = 1)
);
ALTER TABLE public.founder_slots ENABLE ROW LEVEL SECURITY;
INSERT INTO public.founder_slots (id, total_slots, claimed) VALUES (1, 50, 0) ON CONFLICT DO NOTHING;

-- user_tags
CREATE TABLE IF NOT EXISTS public.user_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tag text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, tag)
);
ALTER TABLE public.user_tags ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_user_tags_user ON public.user_tags(user_id);
CREATE INDEX IF NOT EXISTS idx_user_tags_tag ON public.user_tags(tag);

-- user_logs (audit trail)
CREATE TABLE IF NOT EXISTS public.user_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  action text NOT NULL,
  performed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.user_logs ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_user_logs_user ON public.user_logs(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_logs_action ON public.user_logs(action);

-- =============================================
-- RLS POLICIES
-- =============================================

-- Helper: is_admin function
CREATE OR REPLACE FUNCTION public.is_admin(_uid uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT coalesce((SELECT is_admin FROM public.profiles WHERE id = _uid), false); $$;

-- Profiles
DROP POLICY IF EXISTS "profiles_self_select" ON public.profiles;
DROP POLICY IF EXISTS "profiles_self_update" ON public.profiles;
DROP POLICY IF EXISTS "profiles_self_insert" ON public.profiles;
DROP POLICY IF EXISTS "profiles_admin_select" ON public.profiles;
DROP POLICY IF EXISTS "profiles_admin_update" ON public.profiles;

CREATE POLICY "profiles_self_select" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid());
CREATE POLICY "profiles_self_update" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid());
CREATE POLICY "profiles_self_insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_admin_select" ON public.profiles FOR SELECT TO authenticated USING (public.is_admin());
CREATE POLICY "profiles_admin_update" ON public.profiles FOR UPDATE TO authenticated USING (public.is_admin());

-- user_plans
DROP POLICY IF EXISTS "user_plans_self_select" ON public.user_plans;
DROP POLICY IF EXISTS "user_plans_admin_select" ON public.user_plans;
DROP POLICY IF EXISTS "user_plans_admin_update" ON public.user_plans;

CREATE POLICY "user_plans_self_select" ON public.user_plans FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "user_plans_admin_select" ON public.user_plans FOR SELECT TO authenticated USING (public.is_admin());
CREATE POLICY "user_plans_admin_update" ON public.user_plans FOR UPDATE TO authenticated USING (public.is_admin());

-- lead_usage
DROP POLICY IF EXISTS "lead_usage_self_select" ON public.lead_usage;
DROP POLICY IF EXISTS "lead_usage_admin_select" ON public.lead_usage;

CREATE POLICY "lead_usage_self_select" ON public.lead_usage FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "lead_usage_admin_select" ON public.lead_usage FOR SELECT TO authenticated USING (public.is_admin());

-- upgrade_events
DROP POLICY IF EXISTS "upgrade_events_self_select" ON public.upgrade_events;
DROP POLICY IF EXISTS "upgrade_events_self_insert" ON public.upgrade_events;

CREATE POLICY "upgrade_events_self_select" ON public.upgrade_events FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "upgrade_events_self_insert" ON public.upgrade_events FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

-- founder_slots
DROP POLICY IF EXISTS "founder_slots_public_read" ON public.founder_slots;
CREATE POLICY "founder_slots_public_read" ON public.founder_slots FOR SELECT TO anon, authenticated USING (true);

-- user_tags (admin only + self read)
DROP POLICY IF EXISTS "user_tags_self_select" ON public.user_tags;
DROP POLICY IF EXISTS "user_tags_admin_all" ON public.user_tags;
DROP POLICY IF EXISTS "user_tags_admin_insert" ON public.user_tags;
DROP POLICY IF EXISTS "user_tags_admin_delete" ON public.user_tags;

CREATE POLICY "user_tags_self_select" ON public.user_tags FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "user_tags_admin_all" ON public.user_tags FOR SELECT TO authenticated USING (public.is_admin());
CREATE POLICY "user_tags_admin_insert" ON public.user_tags FOR INSERT TO authenticated WITH CHECK (public.is_admin());
CREATE POLICY "user_tags_admin_delete" ON public.user_tags FOR DELETE TO authenticated USING (public.is_admin());

-- user_logs (admin only)
DROP POLICY IF EXISTS "user_logs_admin_select" ON public.user_logs;
DROP POLICY IF EXISTS "user_logs_admin_insert" ON public.user_logs;

CREATE POLICY "user_logs_admin_select" ON public.user_logs FOR SELECT TO authenticated USING (public.is_admin());
CREATE POLICY "user_logs_admin_insert" ON public.user_logs FOR INSERT TO authenticated WITH CHECK (public.is_admin());

-- =============================================
-- FUNCTIONS
-- =============================================

-- Trigger: handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _is_admin boolean := lower(new.email) = 'gabrieleitejesus@gmail.com';
BEGIN
  INSERT INTO public.profiles (id, full_name, email, is_admin, role, status)
  VALUES (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', ''),
    new.email,
    _is_admin,
    CASE WHEN _is_admin THEN 'root'::public.user_role ELSE 'user'::public.user_role END,
    'active'::public.user_status
  )
  ON CONFLICT (id) DO UPDATE SET is_admin = excluded.is_admin OR public.profiles.is_admin;

  INSERT INTO public.user_plans (user_id, plan, status, leads_limit)
  VALUES (
    new.id,
    CASE WHEN _is_admin THEN 'founder'::public.plan_type ELSE 'basic'::public.plan_type END,
    'active',
    CASE WHEN _is_admin THEN 999999 ELSE 30 END
  )
  ON CONFLICT (user_id) DO NOTHING;

  INSERT INTO public.lead_usage (user_id) VALUES (new.id)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- current_plan
CREATE OR REPLACE FUNCTION public.current_plan()
RETURNS public.plan_type LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce(
    (SELECT plan FROM public.user_plans
      WHERE user_id = auth.uid() AND status = 'active'
        AND (plan = 'founder' OR current_period_end IS NULL OR current_period_end > now())
      LIMIT 1),
    'basic'::public.plan_type
  );
$$;

-- has_feature
CREATE OR REPLACE FUNCTION public.has_feature(_feature text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE public.current_plan()
    WHEN 'founder' THEN true
    WHEN 'pro'     THEN true
    WHEN 'basic'   THEN _feature IN ('leads', 'workbench', 'scripts')
  END;
$$;

-- can_use_lead
CREATE OR REPLACE FUNCTION public.can_use_lead()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _plan public.plan_type; _used integer; _reset date;
BEGIN
  _plan := public.current_plan();
  IF _plan = 'founder' THEN RETURN true; END IF;
  SELECT leads_used_today, last_reset_date INTO _used, _reset FROM public.lead_usage WHERE user_id = auth.uid();
  IF _reset IS NULL OR _reset < current_date THEN RETURN true; END IF;
  IF _plan = 'pro'   AND _used >= 100 THEN RETURN false; END IF;
  IF _plan = 'basic' AND _used >= 30  THEN RETURN false; END IF;
  RETURN true;
END;
$$;

-- consume_lead
CREATE OR REPLACE FUNCTION public.consume_lead()
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _plan public.plan_type; _limit integer; _used integer; _reset date;
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  _plan := public.current_plan();
  INSERT INTO public.lead_usage (user_id) VALUES (auth.uid()) ON CONFLICT (user_id) DO NOTHING;
  SELECT leads_used_today, last_reset_date INTO _used, _reset FROM public.lead_usage WHERE user_id = auth.uid() FOR UPDATE;
  IF _reset < current_date THEN
    _used := 0;
    UPDATE public.lead_usage SET leads_used_today = 0, leads_used_week = 0, last_reset_date = current_date, updated_at = now() WHERE user_id = auth.uid();
  END IF;
  _limit := CASE _plan WHEN 'founder' THEN 2147483647 WHEN 'pro' THEN 100 WHEN 'basic' THEN 30 END;
  IF _used >= _limit THEN
    INSERT INTO public.upgrade_events (user_id, event_type, feature, from_plan, metadata)
    VALUES (auth.uid(), 'limit_reached', 'leads', _plan, jsonb_build_object('limit', _limit));
    RETURN false;
  END IF;
  UPDATE public.lead_usage SET leads_used_today = leads_used_today + 1, leads_used_week = leads_used_week + 1, leads_used_month = leads_used_month + 1, updated_at = now() WHERE user_id = auth.uid();
  RETURN true;
END;
$$;

-- claim_founder
CREATE OR REPLACE FUNCTION public.claim_founder()
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _claimed integer; _total integer;
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  SELECT claimed, total_slots INTO _claimed, _total FROM public.founder_slots WHERE id = 1 FOR UPDATE;
  IF _claimed >= _total THEN RETURN false; END IF;
  UPDATE public.founder_slots SET claimed = claimed + 1, updated_at = now() WHERE id = 1;
  UPDATE public.user_plans SET plan = 'founder', status = 'active', leads_limit = 999999, current_period_end = NULL, updated_at = now() WHERE user_id = auth.uid();
  RETURN true;
END;
$$;

-- =============================================
-- ADMIN RPCs
-- =============================================

-- admin_list_users (v2 — includes status, role, tags, last_login)
CREATE OR REPLACE FUNCTION public.admin_list_users(
  _search text DEFAULT NULL,
  _plan_filter public.plan_type DEFAULT NULL,
  _status_filter public.user_status DEFAULT NULL,
  _limit integer DEFAULT 50,
  _offset integer DEFAULT 0
)
RETURNS TABLE (
  user_id uuid,
  email text,
  full_name text,
  is_admin boolean,
  plan public.plan_type,
  status public.user_status,
  role public.user_role,
  leads_used_today integer,
  leads_used_week integer,
  leads_used_month integer,
  leads_limit integer,
  last_reset_date date,
  last_login_at timestamptz,
  tags text[],
  created_at timestamptz,
  total_count bigint
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  RETURN QUERY
    SELECT
      p.id,
      p.email,
      p.full_name,
      p.is_admin,
      coalesce(up.plan, 'basic'::public.plan_type),
      coalesce(p.status, 'active'::public.user_status),
      coalesce(p.role, 'user'::public.user_role),
      coalesce(CASE WHEN lu.last_reset_date = current_date THEN lu.leads_used_today ELSE 0 END, 0),
      coalesce(lu.leads_used_week, 0),
      coalesce(lu.leads_used_month, 0),
      coalesce(up.leads_limit, 30),
      coalesce(lu.last_reset_date, current_date),
      p.last_login_at,
      coalesce(ARRAY(SELECT ut.tag FROM public.user_tags ut WHERE ut.user_id = p.id ORDER BY ut.tag), ARRAY[]::text[]),
      p.created_at,
      count(*) OVER()
    FROM public.profiles p
    LEFT JOIN public.user_plans up ON up.user_id = p.id
    LEFT JOIN public.lead_usage lu ON lu.user_id = p.id
    WHERE (_search IS NULL OR (p.email ILIKE '%' || _search || '%' OR p.full_name ILIKE '%' || _search || '%'))
      AND (_plan_filter IS NULL OR up.plan = _plan_filter)
      AND (_status_filter IS NULL OR p.status = _status_filter)
    ORDER BY p.created_at DESC
    LIMIT _limit OFFSET _offset;
END;
$$;

-- admin_set_plan
CREATE OR REPLACE FUNCTION public.admin_set_plan(_user_id uuid, _plan public.plan_type)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _old_plan public.plan_type;
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  SELECT plan INTO _old_plan FROM public.user_plans WHERE user_id = _user_id;
  INSERT INTO public.user_plans (user_id, plan, status, leads_limit)
  VALUES (_user_id, _plan, 'active', CASE _plan WHEN 'founder' THEN 999999 WHEN 'pro' THEN 100 ELSE 30 END)
  ON CONFLICT (user_id) DO UPDATE
    SET plan = excluded.plan, status = 'active',
        leads_limit = CASE excluded.plan WHEN 'founder' THEN 999999 WHEN 'pro' THEN 100 ELSE 30 END,
        current_period_end = CASE WHEN excluded.plan = 'founder' THEN NULL ELSE public.user_plans.current_period_end END,
        updated_at = now();
  INSERT INTO public.user_logs (user_id, action, performed_by, metadata)
  VALUES (_user_id, 'PLAN_CHANGED', auth.uid(), jsonb_build_object('from', _old_plan, 'to', _plan));
  RETURN true;
END;
$$;

-- admin_set_status
CREATE OR REPLACE FUNCTION public.admin_set_status(_user_id uuid, _status public.user_status)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _old_status public.user_status;
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  SELECT status INTO _old_status FROM public.profiles WHERE id = _user_id;
  UPDATE public.profiles SET status = _status, updated_at = now() WHERE id = _user_id;
  INSERT INTO public.user_logs (user_id, action, performed_by, metadata)
  VALUES (_user_id, 'STATUS_CHANGED', auth.uid(), jsonb_build_object('from', _old_status, 'to', _status));
  RETURN true;
END;
$$;

-- admin_reset_leads
CREATE OR REPLACE FUNCTION public.admin_reset_leads(_user_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  INSERT INTO public.lead_usage (user_id, leads_used_today, leads_used_week, leads_used_month, last_reset_date, updated_at)
  VALUES (_user_id, 0, 0, 0, current_date, now())
  ON CONFLICT (user_id) DO UPDATE SET leads_used_today = 0, leads_used_week = 0, leads_used_month = 0, last_reset_date = current_date, updated_at = now();
  INSERT INTO public.user_logs (user_id, action, performed_by, metadata)
  VALUES (_user_id, 'LEADS_RESET', auth.uid(), '{}'::jsonb);
  RETURN true;
END;
$$;

-- admin_delete_user
CREATE OR REPLACE FUNCTION public.admin_delete_user(_user_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _user_id = auth.uid() THEN RAISE EXCEPTION 'cannot delete self'; END IF;
  INSERT INTO public.user_logs (user_id, action, performed_by, metadata)
  VALUES (_user_id, 'USER_DELETED', auth.uid(), jsonb_build_object('email', (SELECT email FROM public.profiles WHERE id = _user_id)));
  DELETE FROM auth.users WHERE id = _user_id;
  RETURN true;
END;
$$;

-- admin_get_user_logs
CREATE OR REPLACE FUNCTION public.admin_get_user_logs(_user_id uuid, _limit integer DEFAULT 20)
RETURNS TABLE (id uuid, action text, performed_by uuid, metadata jsonb, created_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  RETURN QUERY
    SELECT l.id, l.action, l.performed_by, l.metadata, l.created_at
    FROM public.user_logs l WHERE l.user_id = _user_id
    ORDER BY l.created_at DESC LIMIT _limit;
END;
$$;

-- admin_add_tag
CREATE OR REPLACE FUNCTION public.admin_add_tag(_user_id uuid, _tag text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  INSERT INTO public.user_tags (user_id, tag) VALUES (_user_id, _tag) ON CONFLICT DO NOTHING;
  INSERT INTO public.user_logs (user_id, action, performed_by, metadata)
  VALUES (_user_id, 'TAG_ADDED', auth.uid(), jsonb_build_object('tag', _tag));
  RETURN true;
END;
$$;

-- admin_remove_tag
CREATE OR REPLACE FUNCTION public.admin_remove_tag(_user_id uuid, _tag text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  DELETE FROM public.user_tags WHERE user_id = _user_id AND tag = _tag;
  INSERT INTO public.user_logs (user_id, action, performed_by, metadata)
  VALUES (_user_id, 'TAG_REMOVED', auth.uid(), jsonb_build_object('tag', _tag));
  RETURN true;
END;
$$;

-- admin_update_user (general update)
CREATE OR REPLACE FUNCTION public.admin_update_user(
  _user_id uuid,
  _full_name text DEFAULT NULL,
  _status public.user_status DEFAULT NULL,
  _role public.user_role DEFAULT NULL,
  _leads_limit integer DEFAULT NULL
)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _full_name IS NOT NULL THEN
    UPDATE public.profiles SET full_name = _full_name, updated_at = now() WHERE id = _user_id;
  END IF;
  IF _status IS NOT NULL THEN
    UPDATE public.profiles SET status = _status, updated_at = now() WHERE id = _user_id;
  END IF;
  IF _role IS NOT NULL THEN
    UPDATE public.profiles SET role = _role, updated_at = now() WHERE id = _user_id;
  END IF;
  IF _leads_limit IS NOT NULL THEN
    UPDATE public.user_plans SET leads_limit = _leads_limit, updated_at = now() WHERE user_id = _user_id;
  END IF;
  INSERT INTO public.user_logs (user_id, action, performed_by, metadata)
  VALUES (_user_id, 'USER_UPDATED', auth.uid(), jsonb_build_object('name', _full_name, 'status', _status, 'role', _role, 'leads_limit', _leads_limit));
  RETURN true;
END;
$$;

-- admin_get_stats (dashboard stats)
CREATE OR REPLACE FUNCTION public.admin_get_stats()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE result jsonb;
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  SELECT jsonb_build_object(
    'total_users', (SELECT count(*) FROM public.profiles),
    'active_users', (SELECT count(*) FROM public.profiles WHERE status = 'active'),
    'trial_users', (SELECT count(*) FROM public.profiles WHERE status = 'trial'),
    'suspended_users', (SELECT count(*) FROM public.profiles WHERE status = 'suspended'),
    'banned_users', (SELECT count(*) FROM public.profiles WHERE status = 'banned'),
    'basic_plans', (SELECT count(*) FROM public.user_plans WHERE plan = 'basic'),
    'pro_plans', (SELECT count(*) FROM public.user_plans WHERE plan = 'pro'),
    'founder_plans', (SELECT count(*) FROM public.user_plans WHERE plan = 'founder'),
    'total_leads_today', (SELECT coalesce(sum(CASE WHEN last_reset_date = current_date THEN leads_used_today ELSE 0 END), 0) FROM public.lead_usage),
    'inactive_7d', (SELECT count(*) FROM public.profiles WHERE last_login_at < now() - interval '7 days' OR (last_login_at IS NULL AND created_at < now() - interval '7 days'))
  ) INTO result;
  RETURN result;
END;
$$;
